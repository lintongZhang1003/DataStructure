﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DS_CS
{
    public partial class Form_GenList : Form
    {
        private CGenList m_genlist1, m_genlist2;
        public Form_GenList()
        {
            InitializeComponent();
        }

        private void bt_create_Click(object sender, EventArgs e)
        {
            m_genlist1 = new CGenList();
            string strout = "";
            string strin = tb_strin.Text;
            m_genlist1.CreateGL(strin, out strout);
            tb_strout.Text = strout;

        }

        private void bt_print_Click(object sender, EventArgs e)
        {
            string strout = "";
            if ((rb_gl1.Checked)&&(m_genlist1 != null))
            {
                m_genlist1.PrintGL(out strout);
                tb_strprint.Text = strout;
            }
            else if ((rb_gl2.Checked) && (m_genlist2 != null))
            {
                m_genlist2.PrintGL(out strout);
                tb_strprint.Text = strout;
            }
        }

        private void bt_copyt_Click(object sender, EventArgs e)
        {
            string strout = "";
            m_genlist2 = new CGenList();
            m_genlist2.CopytGL(m_genlist1);
            m_genlist2.PrintGL(out strout);
            tb_strprint.Text = strout;
            rb_gl2.Checked = true;
        }


        private void bt_Traversal_Click(object sender, EventArgs e)
        {
            string strout = "";
            if ((rb_gl1.Checked) && (m_genlist1 != null))
            {
                m_genlist1.Traversal(out strout);
                tb_strout.Text = strout;
            }
            else if ((rb_gl2.Checked) && (m_genlist2 != null))
            {
                m_genlist2.Traversal(out strout);
                tb_strout.Text = strout;
            }
        }
    }
}