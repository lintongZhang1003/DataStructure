﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DS_CS
{

    class CSeqList<Type>//顺序表结点类
    {
        private Type[] data;
        private int MaxSize;
        private int datasize;


        public CSeqList(int MaxSize)
        {
            this.MaxSize = MaxSize;
            data = new Type[MaxSize];
            datasize = 0;
        }
        public CSeqList(int MaxSize, Type[] data, int n)
        {
            this.MaxSize = MaxSize;
            if (n > MaxSize)
                n = MaxSize;
            this.data = new Type[MaxSize];
            for (int i = 0; i < n; i++)
                this.data[i] = data[i];
            datasize = n;
        }
        public int DataSize
        {
            get
            {
                return datasize;
            }
        }
        public void MakeEmpty()
        {
            datasize = 0;
        }
        public bool Update(int k, Type dt)
        {
            if (k < 1 || k > datasize)
                return false;
            data[k - 1] = dt;
            return true;
        }
        public bool Delete(int k)
        {
            if (k < 1 || k > datasize)
                return false;
            for (int i = k - 1; i < datasize - 1; i++)
                data[i] = data[i + 1];
            datasize--;
            return true;
        }
        public bool Inset(int k, Type dt)
        {
            if (k < 1 || k > datasize+1)
                return false;
            if (datasize == MaxSize)
                return false;
            for (int i = datasize - 1; i >= k - 1; i--)
                data[i + 1] = data[i];
            data[k - 1] = dt;
            datasize++;
            return true;
        }
        public string MyPrint()
        {
            string strout = "";
            for (int i = 0; i < MaxSize; i++)
            {
                if (i < datasize)
                    strout += "\t" + (i + 1) + "\t【\t" + this.data[i] + "\t】\n";
                else
                    strout += "\t" + (i + 1) + "\t【\t  \t】\n";
            }
            return strout;
        }

    }

}
