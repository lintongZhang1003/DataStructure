﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;//读取文件所需的

namespace DS_CS
{
    public partial class Form_Progrom : Form
    {
        public Form_Progrom()
        {
            InitializeComponent();
        }

        private void bt_openfile_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            //string str1 = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string str = "..\\..\\";
            dlg.InitialDirectory = str;
            dlg.Filter = "程序文件（*.cs）|*.cs|文本文件（*.txt）|*.txt";
            dlg.Title = "打开源程序数据文件";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                tb_fname.Text = dlg.FileName;
                StreamReader sr = new StreamReader(tb_fname.Text);
                rtb_progrom_s.Text = sr.ReadToEnd();
                sr.Close();
            }
        }

        private void bt_do1_Click(object sender, EventArgs e)
        {
            rtb_progrom_d.Text = trans1_string(rtb_progrom_s.Text);
            double a=123456789012345678901f;
            rtb_progrom_d.Text = "" + a;
        }

        public string trans1_string(string m_input)
        {
            int ks = 0;
            int len = m_input.Length;
            string str = "";
            string m_outstr = "";
            bool isb = true;
            while(ks<len)
            {
                if (isb == true)
                    str = "";
                while ((isb == true) && (ks < len) && ((m_input[ks] == ' ') || (m_input[ks] == '\t')))
                    ks++;
                isb = false;
                while ((isb == false) && (ks < len) && (m_input[ks] != '\r') && (m_input[ks] != '\n'))
                    str = str + m_input[ks++];
                if ((m_input[ks] == '\r') || (m_input[ks] == '\n'))
                {
                    m_outstr += str;
                    m_outstr += "\r\n";
                    str = "";
                    isb = true;
                }
                ks++;
            }
            return m_outstr;
        }
        public string trans2_string(string m_input)
        {
            CLinkStack<int> degree = new CLinkStack<int>();
            int de,ks = 0;
            int len = m_input.Length;
            string str = "";
            string m_outstr = "";
            bool isb = true;
            while (ks < len)
            {
                if (isb == true)
                    str = "";
                while ((isb == true) && (ks < len) && ((m_input[ks] == ' ') || (m_input[ks] == '\t')))
                    ks++;
                isb = false;
                while ((isb == false) && (ks < len) 
                    && (m_input[ks] != '\r') && (m_input[ks] != '\n') 
                    && (m_input[ks] != '{') && (m_input[ks] != '}'))
                {
                    str = str + m_input[ks++];
                }
                if ((m_input[ks] == '\r') || (m_input[ks] == '\n') || (m_input[ks] == '{') || (m_input[ks] == '}'))
                {
                    if (degree.IsEmpty())
                        de = 0;
                    else
                        de = degree.Gettop();
                    if (m_input[ks] == '{')
                    {
                        de++;
                        degree.Push(de);
                        m_outstr += str;
                        m_outstr += "\r\n";
                        for (int i = 0; i < de; i++)
                            m_outstr += "    ";
                        m_outstr += "{";
                    }
                    else if (m_input[ks] == '}')
                    {
                        degree.Pop();
                        m_outstr += str;
                        m_outstr += "\r\n";
                        for (int i = 0; i < de; i++)
                            m_outstr += "    ";
                        m_outstr += "}";
                    }
                    else
                    {
                        if (degree.IsEmpty())
                            de = 0;
                        else
                            de = degree.Gettop();
                        m_outstr += str;
                        m_outstr += "\r\n";
                        for (int i = 0; i < de; i++)
                            m_outstr += "    ";
                    }
                    str = "";
                    isb = true;
                }
                ks++;
            }
            return m_outstr;
        }

        private void bt_do2_Click(object sender, EventArgs e)
        {
            rtb_progrom0.Text = trans1_string(rtb_progrom_s.Text);
            rtb_progrom_d.Text = trans2_string(rtb_progrom0.Text);
        }

        private void bt_sxh_Click(object sender, EventArgs e)
        {
            int dm = Convert.ToInt16(tb_fname.Text);
            rtb_progrom_d.Text = Get_sxh(dm);
        }

        public string Get_sxh(int dn)
        {
            string strout = "";
            int da=1;
            for (int i = 1; i <= dn - 1; i++)
                da *= 10;
            int db = da * 10 - 1;
            for (int dm=da; dm <= db; dm++)
            { 
                int sum=0;
                for(int k=1;k<=dn;k++)
                {
                    int dm1 = dm;
                    for (int i = 1; i <= k - 1; i++)
                        dm1 /= 10;
                    int dk = dm1 % 10;
                    int dk_dn = 1;
                    for (int i = 1; i <= dn; i++)
                        dk_dn *= dk;
                    sum+=dk_dn;
                    if (sum>dm)
                        break;
                }
                if (sum == dm)
                {
                    strout += dm+"\r\n";
                }
            }
            return strout;
        }
    }
}