﻿namespace DS_CS
{
    partial class Form_SList
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tb_next = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_data = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_address = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.bt_find = new System.Windows.Forms.Button();
            this.rb_insertn = new System.Windows.Forms.RadioButton();
            this.rb_insert0 = new System.Windows.Forms.RadioButton();
            this.rb_insert2 = new System.Windows.Forms.RadioButton();
            this.rb_insert1 = new System.Windows.Forms.RadioButton();
            this.tb_modify = new System.Windows.Forms.TextBox();
            this.bt_temp = new System.Windows.Forms.Button();
            this.bt_convers = new System.Windows.Forms.Button();
            this.bt_insert = new System.Windows.Forms.Button();
            this.bt_update = new System.Windows.Forms.Button();
            this.bt_delete = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bt_next = new System.Windows.Forms.Button();
            this.bt_head = new System.Windows.Forms.Button();
            this.bt_close = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_slistcount = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rb_head2 = new System.Windows.Forms.RadioButton();
            this.rb_head1 = new System.Windows.Forms.RadioButton();
            this.bt_create = new System.Windows.Forms.Button();
            this.bt_empty = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pBox_slist = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_slist)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.bt_close);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(1008, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(248, 850);
            this.panel1.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tb_next);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.tb_data);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.tb_address);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(0, 594);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(244, 150);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "显示";
            // 
            // tb_next
            // 
            this.tb_next.Location = new System.Drawing.Point(86, 108);
            this.tb_next.Margin = new System.Windows.Forms.Padding(4);
            this.tb_next.Name = "tb_next";
            this.tb_next.ReadOnly = true;
            this.tb_next.Size = new System.Drawing.Size(110, 28);
            this.tb_next.TabIndex = 6;
            this.tb_next.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 114);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 18);
            this.label5.TabIndex = 5;
            this.label5.Text = "next";
            // 
            // tb_data
            // 
            this.tb_data.Location = new System.Drawing.Point(86, 70);
            this.tb_data.Margin = new System.Windows.Forms.Padding(4);
            this.tb_data.Name = "tb_data";
            this.tb_data.ReadOnly = true;
            this.tb_data.Size = new System.Drawing.Size(110, 28);
            this.tb_data.TabIndex = 6;
            this.tb_data.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 76);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "data";
            // 
            // tb_address
            // 
            this.tb_address.Location = new System.Drawing.Point(86, 30);
            this.tb_address.Margin = new System.Windows.Forms.Padding(4);
            this.tb_address.Name = "tb_address";
            this.tb_address.ReadOnly = true;
            this.tb_address.Size = new System.Drawing.Size(110, 28);
            this.tb_address.TabIndex = 6;
            this.tb_address.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 36);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "地址";
            // 
            // panel5
            // 
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 582);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(244, 12);
            this.panel5.TabIndex = 13;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.bt_find);
            this.groupBox3.Controls.Add(this.rb_insertn);
            this.groupBox3.Controls.Add(this.rb_insert0);
            this.groupBox3.Controls.Add(this.rb_insert2);
            this.groupBox3.Controls.Add(this.rb_insert1);
            this.groupBox3.Controls.Add(this.tb_modify);
            this.groupBox3.Controls.Add(this.bt_temp);
            this.groupBox3.Controls.Add(this.bt_convers);
            this.groupBox3.Controls.Add(this.bt_insert);
            this.groupBox3.Controls.Add(this.bt_update);
            this.groupBox3.Controls.Add(this.bt_delete);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 309);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(244, 273);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "结点操作";
            // 
            // bt_find
            // 
            this.bt_find.Location = new System.Drawing.Point(132, 33);
            this.bt_find.Margin = new System.Windows.Forms.Padding(4);
            this.bt_find.Name = "bt_find";
            this.bt_find.Size = new System.Drawing.Size(98, 38);
            this.bt_find.TabIndex = 10;
            this.bt_find.Text = "查找";
            this.bt_find.UseVisualStyleBackColor = true;
            this.bt_find.Click += new System.EventHandler(this.bt_find_Click);
            // 
            // rb_insertn
            // 
            this.rb_insertn.AutoSize = true;
            this.rb_insertn.Location = new System.Drawing.Point(176, 117);
            this.rb_insertn.Margin = new System.Windows.Forms.Padding(4);
            this.rb_insertn.Name = "rb_insertn";
            this.rb_insertn.Size = new System.Drawing.Size(51, 22);
            this.rb_insertn.TabIndex = 9;
            this.rb_insertn.Text = "尾";
            this.rb_insertn.UseVisualStyleBackColor = true;
            // 
            // rb_insert0
            // 
            this.rb_insert0.AutoSize = true;
            this.rb_insert0.Checked = true;
            this.rb_insert0.Location = new System.Drawing.Point(32, 117);
            this.rb_insert0.Margin = new System.Windows.Forms.Padding(4);
            this.rb_insert0.Name = "rb_insert0";
            this.rb_insert0.Size = new System.Drawing.Size(51, 22);
            this.rb_insert0.TabIndex = 8;
            this.rb_insert0.TabStop = true;
            this.rb_insert0.Text = "头";
            this.rb_insert0.UseVisualStyleBackColor = true;
            // 
            // rb_insert2
            // 
            this.rb_insert2.AutoSize = true;
            this.rb_insert2.Location = new System.Drawing.Point(176, 84);
            this.rb_insert2.Margin = new System.Windows.Forms.Padding(4);
            this.rb_insert2.Name = "rb_insert2";
            this.rb_insert2.Size = new System.Drawing.Size(51, 22);
            this.rb_insert2.TabIndex = 7;
            this.rb_insert2.Text = "后";
            this.rb_insert2.UseVisualStyleBackColor = true;
            // 
            // rb_insert1
            // 
            this.rb_insert1.AutoSize = true;
            this.rb_insert1.Location = new System.Drawing.Point(32, 84);
            this.rb_insert1.Margin = new System.Windows.Forms.Padding(4);
            this.rb_insert1.Name = "rb_insert1";
            this.rb_insert1.Size = new System.Drawing.Size(51, 22);
            this.rb_insert1.TabIndex = 6;
            this.rb_insert1.Text = "前";
            this.rb_insert1.UseVisualStyleBackColor = true;
            // 
            // tb_modify
            // 
            this.tb_modify.Location = new System.Drawing.Point(86, 98);
            this.tb_modify.Margin = new System.Windows.Forms.Padding(4);
            this.tb_modify.Name = "tb_modify";
            this.tb_modify.Size = new System.Drawing.Size(76, 28);
            this.tb_modify.TabIndex = 5;
            this.tb_modify.Text = "100";
            this.tb_modify.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bt_temp
            // 
            this.bt_temp.Location = new System.Drawing.Point(130, 196);
            this.bt_temp.Margin = new System.Windows.Forms.Padding(4);
            this.bt_temp.Name = "bt_temp";
            this.bt_temp.Size = new System.Drawing.Size(99, 45);
            this.bt_temp.TabIndex = 0;
            this.bt_temp.Text = "临时";
            this.bt_temp.UseVisualStyleBackColor = true;
            this.bt_temp.Click += new System.EventHandler(this.bt_temp_Click);
            // 
            // bt_convers
            // 
            this.bt_convers.Location = new System.Drawing.Point(21, 196);
            this.bt_convers.Margin = new System.Windows.Forms.Padding(4);
            this.bt_convers.Name = "bt_convers";
            this.bt_convers.Size = new System.Drawing.Size(99, 45);
            this.bt_convers.TabIndex = 0;
            this.bt_convers.Text = "倒置";
            this.bt_convers.UseVisualStyleBackColor = true;
            this.bt_convers.Click += new System.EventHandler(this.bt_convers_Click);
            // 
            // bt_insert
            // 
            this.bt_insert.Location = new System.Drawing.Point(132, 150);
            this.bt_insert.Margin = new System.Windows.Forms.Padding(4);
            this.bt_insert.Name = "bt_insert";
            this.bt_insert.Size = new System.Drawing.Size(98, 38);
            this.bt_insert.TabIndex = 0;
            this.bt_insert.Text = "插入";
            this.bt_insert.UseVisualStyleBackColor = true;
            this.bt_insert.Click += new System.EventHandler(this.bt_insert_Click);
            // 
            // bt_update
            // 
            this.bt_update.Location = new System.Drawing.Point(22, 33);
            this.bt_update.Margin = new System.Windows.Forms.Padding(4);
            this.bt_update.Name = "bt_update";
            this.bt_update.Size = new System.Drawing.Size(98, 38);
            this.bt_update.TabIndex = 0;
            this.bt_update.Text = "修改";
            this.bt_update.UseVisualStyleBackColor = true;
            this.bt_update.Click += new System.EventHandler(this.bt_update_Click);
            // 
            // bt_delete
            // 
            this.bt_delete.Location = new System.Drawing.Point(22, 150);
            this.bt_delete.Margin = new System.Windows.Forms.Padding(4);
            this.bt_delete.Name = "bt_delete";
            this.bt_delete.Size = new System.Drawing.Size(98, 38);
            this.bt_delete.TabIndex = 0;
            this.bt_delete.Text = "删除";
            this.bt_delete.UseVisualStyleBackColor = true;
            this.bt_delete.Click += new System.EventHandler(this.bt_delete_Click);
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 297);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(244, 12);
            this.panel4.TabIndex = 11;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.bt_next);
            this.groupBox2.Controls.Add(this.bt_head);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 210);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(244, 87);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "结点移动";
            // 
            // bt_next
            // 
            this.bt_next.Location = new System.Drawing.Point(132, 34);
            this.bt_next.Margin = new System.Windows.Forms.Padding(4);
            this.bt_next.Name = "bt_next";
            this.bt_next.Size = new System.Drawing.Size(98, 38);
            this.bt_next.TabIndex = 0;
            this.bt_next.Text = "下一节点";
            this.bt_next.UseVisualStyleBackColor = true;
            this.bt_next.Click += new System.EventHandler(this.bt_next_Click);
            // 
            // bt_head
            // 
            this.bt_head.Location = new System.Drawing.Point(22, 34);
            this.bt_head.Margin = new System.Windows.Forms.Padding(4);
            this.bt_head.Name = "bt_head";
            this.bt_head.Size = new System.Drawing.Size(98, 38);
            this.bt_head.TabIndex = 0;
            this.bt_head.Text = "头结点";
            this.bt_head.UseVisualStyleBackColor = true;
            this.bt_head.Click += new System.EventHandler(this.bt_head_Click);
            // 
            // bt_close
            // 
            this.bt_close.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_close.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_close.Location = new System.Drawing.Point(27, 748);
            this.bt_close.Margin = new System.Windows.Forms.Padding(4);
            this.bt_close.Name = "bt_close";
            this.bt_close.Size = new System.Drawing.Size(201, 60);
            this.bt_close.TabIndex = 9;
            this.bt_close.Text = "退出";
            this.bt_close.UseVisualStyleBackColor = true;
            this.bt_close.Click += new System.EventHandler(this.bt_close_Click);
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 198);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(244, 12);
            this.panel3.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tb_slistcount);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.rb_head2);
            this.groupBox1.Controls.Add(this.rb_head1);
            this.groupBox1.Controls.Add(this.bt_create);
            this.groupBox1.Controls.Add(this.bt_empty);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(0, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(244, 186);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "初始化";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(159, 82);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 18);
            this.label2.TabIndex = 5;
            this.label2.Text = "(1～99)";
            // 
            // tb_slistcount
            // 
            this.tb_slistcount.Location = new System.Drawing.Point(72, 76);
            this.tb_slistcount.Margin = new System.Windows.Forms.Padding(4);
            this.tb_slistcount.Name = "tb_slistcount";
            this.tb_slistcount.Size = new System.Drawing.Size(76, 28);
            this.tb_slistcount.TabIndex = 4;
            this.tb_slistcount.Text = "30";
            this.tb_slistcount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 82);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "个数";
            // 
            // rb_head2
            // 
            this.rb_head2.AutoSize = true;
            this.rb_head2.Location = new System.Drawing.Point(141, 36);
            this.rb_head2.Margin = new System.Windows.Forms.Padding(4);
            this.rb_head2.Name = "rb_head2";
            this.rb_head2.Size = new System.Drawing.Size(87, 22);
            this.rb_head2.TabIndex = 2;
            this.rb_head2.Text = "尾插法";
            this.rb_head2.UseVisualStyleBackColor = true;
            // 
            // rb_head1
            // 
            this.rb_head1.AutoSize = true;
            this.rb_head1.Checked = true;
            this.rb_head1.Location = new System.Drawing.Point(28, 36);
            this.rb_head1.Margin = new System.Windows.Forms.Padding(4);
            this.rb_head1.Name = "rb_head1";
            this.rb_head1.Size = new System.Drawing.Size(87, 22);
            this.rb_head1.TabIndex = 1;
            this.rb_head1.TabStop = true;
            this.rb_head1.Text = "头插法";
            this.rb_head1.UseVisualStyleBackColor = true;
            // 
            // bt_create
            // 
            this.bt_create.Location = new System.Drawing.Point(22, 126);
            this.bt_create.Margin = new System.Windows.Forms.Padding(4);
            this.bt_create.Name = "bt_create";
            this.bt_create.Size = new System.Drawing.Size(98, 45);
            this.bt_create.TabIndex = 0;
            this.bt_create.Text = "初始化";
            this.bt_create.UseVisualStyleBackColor = true;
            this.bt_create.Click += new System.EventHandler(this.bt_create_Click);
            // 
            // bt_empty
            // 
            this.bt_empty.Location = new System.Drawing.Point(132, 126);
            this.bt_empty.Margin = new System.Windows.Forms.Padding(4);
            this.bt_empty.Name = "bt_empty";
            this.bt_empty.Size = new System.Drawing.Size(98, 45);
            this.bt_empty.TabIndex = 0;
            this.bt_empty.Text = "清空";
            this.bt_empty.UseVisualStyleBackColor = true;
            this.bt_empty.Click += new System.EventHandler(this.bt_empty_Click);
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(244, 12);
            this.panel2.TabIndex = 1;
            // 
            // pBox_slist
            // 
            this.pBox_slist.BackColor = System.Drawing.SystemColors.Control;
            this.pBox_slist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pBox_slist.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pBox_slist.Location = new System.Drawing.Point(0, 0);
            this.pBox_slist.Margin = new System.Windows.Forms.Padding(4);
            this.pBox_slist.Name = "pBox_slist";
            this.pBox_slist.Size = new System.Drawing.Size(1008, 850);
            this.pBox_slist.TabIndex = 1;
            this.pBox_slist.TabStop = false;
            // 
            // Form_SList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1256, 850);
            this.Controls.Add(this.pBox_slist);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form_SList";
            this.Text = "单链表的运算";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form_SList_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_slist)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pBox_slist;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button bt_create;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_slistcount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rb_head2;
        private System.Windows.Forms.RadioButton rb_head1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button bt_close;
        private System.Windows.Forms.Button bt_convers;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox tb_next;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_data;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_address;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rb_insert2;
        private System.Windows.Forms.RadioButton rb_insert1;
        private System.Windows.Forms.TextBox tb_modify;
        private System.Windows.Forms.Button bt_insert;
        private System.Windows.Forms.Button bt_update;
        private System.Windows.Forms.Button bt_delete;
        private System.Windows.Forms.Button bt_empty;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button bt_next;
        private System.Windows.Forms.Button bt_head;
        private System.Windows.Forms.RadioButton rb_insertn;
        private System.Windows.Forms.RadioButton rb_insert0;
        private System.Windows.Forms.Button bt_find;
        private System.Windows.Forms.Button bt_temp;
    }
}