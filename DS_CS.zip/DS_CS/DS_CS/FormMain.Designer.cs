﻿namespace DS_CS
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.线性表运算ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_SeqList = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_SList = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MenuItem_PerCom = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.MenuItem_express = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_Maze = new System.Windows.Forms.ToolStripMenuItem();
            this.递归运算ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_Queens = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_Form_Progrom = new System.Windows.Forms.ToolStripMenuItem();
            this.非线性表运算ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_GenList = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_BinTree = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.线性表运算ToolStripMenuItem,
            this.递归运算ToolStripMenuItem,
            this.非线性表运算ToolStripMenuItem,
            this.MenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(9, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(750, 34);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 线性表运算ToolStripMenuItem
            // 
            this.线性表运算ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_SeqList,
            this.MenuItem_SList,
            this.toolStripSeparator1,
            this.MenuItem_PerCom,
            this.toolStripSeparator2,
            this.MenuItem_express,
            this.MenuItem_Maze});
            this.线性表运算ToolStripMenuItem.Name = "线性表运算ToolStripMenuItem";
            this.线性表运算ToolStripMenuItem.Size = new System.Drawing.Size(112, 28);
            this.线性表运算ToolStripMenuItem.Text = "线性表运算";
            // 
            // MenuItem_SeqList
            // 
            this.MenuItem_SeqList.Name = "MenuItem_SeqList";
            this.MenuItem_SeqList.Size = new System.Drawing.Size(210, 30);
            this.MenuItem_SeqList.Text = "顺序表运算";
            this.MenuItem_SeqList.Click += new System.EventHandler(this.MenuItem_SeqList_Click);
            // 
            // MenuItem_SList
            // 
            this.MenuItem_SList.Name = "MenuItem_SList";
            this.MenuItem_SList.Size = new System.Drawing.Size(210, 30);
            this.MenuItem_SList.Text = "单链表运算";
            this.MenuItem_SList.Click += new System.EventHandler(this.MenuItem_SList_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(207, 6);
            this.toolStripSeparator1.Visible = false;
            // 
            // MenuItem_PerCom
            // 
            this.MenuItem_PerCom.Name = "MenuItem_PerCom";
            this.MenuItem_PerCom.Size = new System.Drawing.Size(210, 30);
            this.MenuItem_PerCom.Text = "排列组合";
            this.MenuItem_PerCom.Click += new System.EventHandler(this.MenuItem_PerCom_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(207, 6);
            this.toolStripSeparator2.Visible = false;
            // 
            // MenuItem_express
            // 
            this.MenuItem_express.Name = "MenuItem_express";
            this.MenuItem_express.Size = new System.Drawing.Size(210, 30);
            this.MenuItem_express.Text = "表达式运算";
            this.MenuItem_express.Click += new System.EventHandler(this.MenuItem_express_Click);
            // 
            // MenuItem_Maze
            // 
            this.MenuItem_Maze.Name = "MenuItem_Maze";
            this.MenuItem_Maze.Size = new System.Drawing.Size(210, 30);
            this.MenuItem_Maze.Text = "迷宫演示";
            this.MenuItem_Maze.Click += new System.EventHandler(this.MenuItem_Maze_Click);
            // 
            // 递归运算ToolStripMenuItem
            // 
            this.递归运算ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_Queens,
            this.MenuItem_Form_Progrom});
            this.递归运算ToolStripMenuItem.Name = "递归运算ToolStripMenuItem";
            this.递归运算ToolStripMenuItem.Size = new System.Drawing.Size(94, 28);
            this.递归运算ToolStripMenuItem.Text = "上机练习";
            this.递归运算ToolStripMenuItem.Visible = false;
            // 
            // MenuItem_Queens
            // 
            this.MenuItem_Queens.Name = "MenuItem_Queens";
            this.MenuItem_Queens.Size = new System.Drawing.Size(216, 30);
            this.MenuItem_Queens.Text = "1．  8皇后问题";
            this.MenuItem_Queens.Click += new System.EventHandler(this.MenuItem_Queens_Click);
            // 
            // MenuItem_Form_Progrom
            // 
            this.MenuItem_Form_Progrom.Name = "MenuItem_Form_Progrom";
            this.MenuItem_Form_Progrom.Size = new System.Drawing.Size(216, 30);
            this.MenuItem_Form_Progrom.Text = "2． 源程序规范";
            this.MenuItem_Form_Progrom.Visible = false;
            this.MenuItem_Form_Progrom.Click += new System.EventHandler(this.MenuItem_Form_Progrom_Click);
            // 
            // 非线性表运算ToolStripMenuItem
            // 
            this.非线性表运算ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_GenList,
            this.MenuItem_BinTree});
            this.非线性表运算ToolStripMenuItem.Name = "非线性表运算ToolStripMenuItem";
            this.非线性表运算ToolStripMenuItem.Size = new System.Drawing.Size(130, 28);
            this.非线性表运算ToolStripMenuItem.Text = "非线性表运算";
            // 
            // MenuItem_GenList
            // 
            this.MenuItem_GenList.Name = "MenuItem_GenList";
            this.MenuItem_GenList.Size = new System.Drawing.Size(200, 30);
            this.MenuItem_GenList.Text = "广义表的运算";
            this.MenuItem_GenList.Click += new System.EventHandler(this.MenuItem_GenList_Click);
            // 
            // MenuItem_BinTree
            // 
            this.MenuItem_BinTree.Name = "MenuItem_BinTree";
            this.MenuItem_BinTree.Size = new System.Drawing.Size(200, 30);
            this.MenuItem_BinTree.Text = "二叉树的运算";
            this.MenuItem_BinTree.Click += new System.EventHandler(this.MenuItem_BinTree_Click);
            // 
            // MenuItem1
            // 
            this.MenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem11,
            this.MenuItem12,
            this.MenuItem13});
            this.MenuItem1.Name = "MenuItem1";
            this.MenuItem1.Size = new System.Drawing.Size(94, 28);
            this.MenuItem1.Text = "运行程序";
            // 
            // MenuItem11
            // 
            this.MenuItem11.Name = "MenuItem11";
            this.MenuItem11.Size = new System.Drawing.Size(210, 30);
            this.MenuItem11.Text = "有理数的运算";
            this.MenuItem11.Click += new System.EventHandler(this.MenuItem11_Click);
            // 
            // MenuItem12
            // 
            this.MenuItem12.Name = "MenuItem12";
            this.MenuItem12.Size = new System.Drawing.Size(210, 30);
            this.MenuItem12.Text = "矩阵的运算";
            this.MenuItem12.Visible = false;
            this.MenuItem12.Click += new System.EventHandler(this.MenuItem12_Click);
            // 
            // MenuItem13
            // 
            this.MenuItem13.Name = "MenuItem13";
            this.MenuItem13.Size = new System.Drawing.Size(210, 30);
            this.MenuItem13.Text = "单链表运算";
            this.MenuItem13.Visible = false;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 399);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormMain";
            this.Text = "数据结构应用程序";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MenuItem11;
        private System.Windows.Forms.ToolStripMenuItem MenuItem12;
        private System.Windows.Forms.ToolStripMenuItem MenuItem13;
        private System.Windows.Forms.ToolStripMenuItem 线性表运算ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_SList;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_Maze;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_express;
        private System.Windows.Forms.ToolStripMenuItem 递归运算ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_Queens;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_Form_Progrom;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_SeqList;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_PerCom;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem 非线性表运算ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_GenList;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_BinTree;
    }
}

