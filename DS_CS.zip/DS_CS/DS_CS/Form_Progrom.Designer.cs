﻿namespace DS_CS
{
    partial class Form_Progrom
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.rtb_progrom_d = new System.Windows.Forms.RichTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rtb_progrom_s = new System.Windows.Forms.RichTextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bt_do2 = new System.Windows.Forms.Button();
            this.rtb_progrom0 = new System.Windows.Forms.TextBox();
            this.bt_do1 = new System.Windows.Forms.Button();
            this.tb_fname = new System.Windows.Forms.TextBox();
            this.bt_openfile = new System.Windows.Forms.Button();
            this.bt_sxh = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rtb_progrom_d);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(394, 538);
            this.panel1.TabIndex = 0;
            // 
            // rtb_progrom_d
            // 
            this.rtb_progrom_d.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb_progrom_d.Location = new System.Drawing.Point(0, 0);
            this.rtb_progrom_d.Name = "rtb_progrom_d";
            this.rtb_progrom_d.Size = new System.Drawing.Size(394, 538);
            this.rtb_progrom_d.TabIndex = 8;
            this.rtb_progrom_d.Text = "";
            this.rtb_progrom_d.WordWrap = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rtb_progrom_s);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(394, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(378, 538);
            this.panel2.TabIndex = 1;
            // 
            // rtb_progrom_s
            // 
            this.rtb_progrom_s.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb_progrom_s.Location = new System.Drawing.Point(0, 0);
            this.rtb_progrom_s.Name = "rtb_progrom_s";
            this.rtb_progrom_s.Size = new System.Drawing.Size(378, 359);
            this.rtb_progrom_s.TabIndex = 7;
            this.rtb_progrom_s.Text = "";
            this.rtb_progrom_s.WordWrap = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.bt_sxh);
            this.panel3.Controls.Add(this.bt_do2);
            this.panel3.Controls.Add(this.rtb_progrom0);
            this.panel3.Controls.Add(this.bt_do1);
            this.panel3.Controls.Add(this.tb_fname);
            this.panel3.Controls.Add(this.bt_openfile);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 359);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(378, 179);
            this.panel3.TabIndex = 0;
            // 
            // bt_do2
            // 
            this.bt_do2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_do2.Location = new System.Drawing.Point(111, 132);
            this.bt_do2.Name = "bt_do2";
            this.bt_do2.Size = new System.Drawing.Size(99, 44);
            this.bt_do2.TabIndex = 7;
            this.bt_do2.Text = "规范文档";
            this.bt_do2.UseVisualStyleBackColor = true;
            this.bt_do2.Click += new System.EventHandler(this.bt_do2_Click);
            // 
            // rtb_progrom0
            // 
            this.rtb_progrom0.Location = new System.Drawing.Point(24, 81);
            this.rtb_progrom0.Multiline = true;
            this.rtb_progrom0.Name = "rtb_progrom0";
            this.rtb_progrom0.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.rtb_progrom0.Size = new System.Drawing.Size(342, 45);
            this.rtb_progrom0.TabIndex = 6;
            this.rtb_progrom0.WordWrap = false;
            // 
            // bt_do1
            // 
            this.bt_do1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_do1.Location = new System.Drawing.Point(24, 132);
            this.bt_do1.Name = "bt_do1";
            this.bt_do1.Size = new System.Drawing.Size(81, 44);
            this.bt_do1.TabIndex = 5;
            this.bt_do1.Text = "清除空格";
            this.bt_do1.UseVisualStyleBackColor = true;
            this.bt_do1.Click += new System.EventHandler(this.bt_do1_Click);
            // 
            // tb_fname
            // 
            this.tb_fname.Location = new System.Drawing.Point(24, 56);
            this.tb_fname.Name = "tb_fname";
            this.tb_fname.Size = new System.Drawing.Size(342, 21);
            this.tb_fname.TabIndex = 4;
            // 
            // bt_openfile
            // 
            this.bt_openfile.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_openfile.Location = new System.Drawing.Point(24, 6);
            this.bt_openfile.Name = "bt_openfile";
            this.bt_openfile.Size = new System.Drawing.Size(342, 44);
            this.bt_openfile.TabIndex = 2;
            this.bt_openfile.Text = "选择源程序文件";
            this.bt_openfile.UseVisualStyleBackColor = true;
            this.bt_openfile.Click += new System.EventHandler(this.bt_openfile_Click);
            // 
            // bt_sxh
            // 
            this.bt_sxh.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_sxh.Location = new System.Drawing.Point(285, 132);
            this.bt_sxh.Name = "bt_sxh";
            this.bt_sxh.Size = new System.Drawing.Size(81, 44);
            this.bt_sxh.TabIndex = 8;
            this.bt_sxh.Text = "水仙花数";
            this.bt_sxh.UseVisualStyleBackColor = true;
            this.bt_sxh.Click += new System.EventHandler(this.bt_sxh_Click);
            // 
            // Form_Progrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 538);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form_Progrom";
            this.Text = "Form_Progrom";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button bt_openfile;
        private System.Windows.Forms.TextBox tb_fname;
        private System.Windows.Forms.RichTextBox rtb_progrom_s;
        private System.Windows.Forms.RichTextBox rtb_progrom_d;
        private System.Windows.Forms.Button bt_do1;
        private System.Windows.Forms.TextBox rtb_progrom0;
        private System.Windows.Forms.Button bt_do2;
        private System.Windows.Forms.Button bt_sxh;
    }
}