﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DS_CS
{
    class Calculator
    {
        //private int Maxsize;
        private CLinkStack<Rational> data;//操作数栈
        private CLinkStack<char> oper;//操作符栈
        private CLinkStack<int> degree;  //操作符优先级栈
		private void AddOperand(Rational value)
        { 
	        data.Push(value); 
        }
        private bool Get2Operands(out Rational left,out Rational right)
        {
            left = right = new Rational();
            if (data.IsEmpty())
                return (false);
            right=data.Pop();
            if (data.IsEmpty())
                return (false);
            left=data.Pop();
            return (true);
        }
		private void DoOperator(char op)
        {
            Rational left,right,ling=new Rational();
            if(Get2Operands(out left,out right))
	        switch(op)
	        {
		        case'+':
			    {
		            data.Push(left+right);
			        break;
			    }
	            case'-': 
		        {
		            data.Push(left-right);
			        break;
		        }
	            case'*': 
		        {
			        data.Push(left*right);
			        break;
		        }
	            case'/':
		        {
			        if(right==ling)
			            data.MakeEmpty();
	                else  
				        data.Push(left/right);
	                break;
		        }
	            case'^':
		        {
			        if(right==ling)
			            data.MakeEmpty();
	                else  
				        data.Push(left^right.Num);
	                break;
		        }
	        }
            else  
		        data.MakeEmpty();
        }
        public Calculator(int sz)
        {
            //Maxsize = sz;
            data = new CLinkStack<Rational>();
            oper = new CLinkStack<char>();
            degree = new CLinkStack<int>();
        }
		public void Clear()
        { 
	        data.MakeEmpty();
        }
    ///////////////////////////////////////////////////////////
        public Rational Run(string pc,out string strout)
        {
            int de;//输入字符的优先级
            char c;//输入的字符
	        int i=0,n=pc.Length;
        //  pc//存放输入的全部字符
            char op;
            c=pc[i++];
	        Rational ling=new Rational();
            strout = "";
            while (c != 0)
            {
                string strt,strd;
                while (c == ' ')
                    c = pc[i++];
                strt = "+-*/^()[]0123456789.";
		        if(strt.IndexOf(c)>=0)
		        {
                    strt="+-*/^()[]";
			        if(strt.IndexOf(c)>=0)//输入的是运算符
			        {
				        switch(c)//求运算符的优先级
				        {
					        case'+': de=1;break;
					        case'-': de=1;break;
					        case'*': de=2;break;
					        case'/': de=2;break;
					        case'^': de=3;break;
					        case'(': de=4;break;
					        case')': de=0;break;
                            case '[': de = 4; break;
                            case ']': de = 0; break;
                            default: de = 10; break;
				        }
				        while(!degree.IsEmpty()&&de<=degree.Gettop())
				        {
					        switch(op=oper.Gettop())
					        {
					            case'+':case'-':case'*':case'/':case'^':
						            DoOperator(op);break;
					            case'(':break;
					        }
					        oper.Pop();
                            degree.Pop();
                            strout = strout + oper.GetStackALLDate("oper");
                            strout = strout + data.GetStackALLDate("data");
					        if((op=='(') || (op=='['))  break;
				        }
				        if((c!=')')&&(c!=']'))  //运算符入栈
				        {
					        oper.Push(c);
                            strout = strout + oper.GetStackALLDate("oper");
                            if ((c == '(') || (c == '['))
                                degree.Push(0);
                            else  
                                degree.Push(de);//运算符的优先级入栈
				        }
			            if(i<n)
					        c=pc[i++];
				        else
					        c=(char)0;
			        }
			        else  //输入的是数字
			        {
                        strd = "";
                        if (c != 0)
                            strd = strd + c;
                        if (i < n)
					        c=pc[i++];
                        else
					        c=(char)0;
                        strt = "0123456789.";
         		        while((c!=0)&&(strt.IndexOf(c)>=0))//输入的还是数字
				        { 
                            if(c!=0)
                                strd = strd + c;
					        if(i<n)
						        c=pc[i++];
					        else
						        c=(char)0;
				        }
                        data.Push(new Rational(Convert.ToDouble(strd)));//数字(实数)入栈;
                        strout = strout + data.GetStackALLDate("data");
                    }
		        }
		        else return ling;
            }
            while(!oper.IsEmpty())//处理剩余运算符
            {
		        switch(op=oper.Gettop())
		        {
			        case'+':case'-':case'*':case'/':case'^':
			            DoOperator(op);break;
			        case'(':break;
                    case '[': break;
                }
		        oper.Pop();
                degree.Pop();
                strout = strout + oper.GetStackALLDate("oper");
                strout = strout + data.GetStackALLDate("data");
            }
            return data.Gettop();
        }
    }
}
