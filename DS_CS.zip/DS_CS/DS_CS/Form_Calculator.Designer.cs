﻿namespace DS_CS
{
    partial class Form_Calculator
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_strout = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tb_express = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bt_close = new System.Windows.Forms.Button();
            this.tb_result = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_calculat = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_strout
            // 
            this.tb_strout.BackColor = System.Drawing.SystemColors.Window;
            this.tb_strout.Dock = System.Windows.Forms.DockStyle.Left;
            this.tb_strout.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_strout.Location = new System.Drawing.Point(0, 0);
            this.tb_strout.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_strout.Multiline = true;
            this.tb_strout.Name = "tb_strout";
            this.tb_strout.ReadOnly = true;
            this.tb_strout.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tb_strout.Size = new System.Drawing.Size(625, 754);
            this.tb_strout.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(625, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(541, 754);
            this.panel3.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tb_express);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 27);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(541, 727);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "请输入一个正确的表达式！";
            // 
            // tb_express
            // 
            this.tb_express.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_express.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_express.Location = new System.Drawing.Point(4, 25);
            this.tb_express.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_express.Name = "tb_express";
            this.tb_express.Size = new System.Drawing.Size(533, 35);
            this.tb_express.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.bt_close);
            this.panel2.Controls.Add(this.tb_result);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.bt_calculat);
            this.panel2.Location = new System.Drawing.Point(27, 93);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(490, 616);
            this.panel2.TabIndex = 1;
            // 
            // bt_close
            // 
            this.bt_close.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_close.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_close.Location = new System.Drawing.Point(285, 552);
            this.bt_close.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bt_close.Name = "bt_close";
            this.bt_close.Size = new System.Drawing.Size(201, 60);
            this.bt_close.TabIndex = 10;
            this.bt_close.Text = "退出";
            this.bt_close.UseVisualStyleBackColor = true;
            this.bt_close.Click += new System.EventHandler(this.bt_close_Click);
            // 
            // tb_result
            // 
            this.tb_result.BackColor = System.Drawing.SystemColors.Window;
            this.tb_result.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_result.Location = new System.Drawing.Point(234, 48);
            this.tb_result.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_result.Name = "tb_result";
            this.tb_result.ReadOnly = true;
            this.tb_result.Size = new System.Drawing.Size(200, 35);
            this.tb_result.TabIndex = 2;
            this.tb_result.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(93, 228);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(315, 116);
            this.label2.TabIndex = 1;
            this.label2.Text = "表达式的运算可以\r\n实现“+-*/”，\r\n并能使用“()[]”\r\n";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(33, 58);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "表达式的运算结果";
            // 
            // bt_calculat
            // 
            this.bt_calculat.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_calculat.ForeColor = System.Drawing.Color.Red;
            this.bt_calculat.Location = new System.Drawing.Point(38, 105);
            this.bt_calculat.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bt_calculat.Name = "bt_calculat";
            this.bt_calculat.Size = new System.Drawing.Size(408, 60);
            this.bt_calculat.TabIndex = 0;
            this.bt_calculat.Text = "计算结果";
            this.bt_calculat.UseVisualStyleBackColor = true;
            this.bt_calculat.Click += new System.EventHandler(this.bt_calculat_Click);
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(541, 27);
            this.panel1.TabIndex = 1;
            // 
            // Form_Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1166, 754);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.tb_strout);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form_Calculator";
            this.Text = "表达式的运算";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_Calculator_FormClosed);
            this.panel3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_strout;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tb_express;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button bt_close;
        private System.Windows.Forms.TextBox tb_result;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_calculat;
        private System.Windows.Forms.Label label2;
    }
}