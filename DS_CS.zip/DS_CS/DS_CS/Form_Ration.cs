﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DS_CS
{
    public partial class Form_Ration : Form
    {
        public Form_Ration()
        {
            InitializeComponent();
        }
    }
}