﻿namespace DS_CS
{
    partial class Form_BinTree
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel0 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.bt_mr = new System.Windows.Forms.Button();
            this.bt_drawf2 = new System.Windows.Forms.Button();
            this.bt_drawf1 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.tb_llen = new System.Windows.Forms.TextBox();
            this.tb_rangle = new System.Windows.Forms.TextBox();
            this.tb_rlen = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_langle = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tb_zby = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_level = new System.Windows.Forms.TextBox();
            this.tb_angle = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_length = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tb_penwidth = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.tb_strin2 = new System.Windows.Forms.TextBox();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.tb_strin1 = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.tb_Traversalpp = new System.Windows.Forms.Button();
            this.bt_create2 = new System.Windows.Forms.Button();
            this.tb_T0_Draw = new System.Windows.Forms.Button();
            this.tb_Traversal = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.rb_tr0 = new System.Windows.Forms.RadioButton();
            this.rb_tr3 = new System.Windows.Forms.RadioButton();
            this.rb_tr2 = new System.Windows.Forms.RadioButton();
            this.rb_tr1 = new System.Windows.Forms.RadioButton();
            this.bt_create = new System.Windows.Forms.Button();
            this.panel0.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel11.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel15.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel0
            // 
            this.panel0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel0.Controls.Add(this.panel4);
            this.panel0.Controls.Add(this.panel9);
            this.panel0.Controls.Add(this.panel8);
            this.panel0.Controls.Add(this.panel7);
            this.panel0.Controls.Add(this.panel6);
            this.panel0.Controls.Add(this.panel1);
            this.panel0.Controls.Add(this.panel5);
            this.panel0.Controls.Add(this.panel3);
            this.panel0.Controls.Add(this.panel2);
            this.panel0.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel0.Location = new System.Drawing.Point(1503, 0);
            this.panel0.Margin = new System.Windows.Forms.Padding(4);
            this.panel0.Name = "panel0";
            this.panel0.Size = new System.Drawing.Size(253, 864);
            this.panel0.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 749);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(249, 111);
            this.panel4.TabIndex = 12;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Gainsboro;
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 733);
            this.panel9.Margin = new System.Windows.Forms.Padding(4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(249, 16);
            this.panel9.TabIndex = 11;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.bt_mr);
            this.panel8.Controls.Add(this.bt_drawf2);
            this.panel8.Controls.Add(this.bt_drawf1);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 527);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(249, 206);
            this.panel8.TabIndex = 10;
            // 
            // bt_mr
            // 
            this.bt_mr.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_mr.ForeColor = System.Drawing.Color.Red;
            this.bt_mr.Location = new System.Drawing.Point(30, 9);
            this.bt_mr.Margin = new System.Windows.Forms.Padding(4);
            this.bt_mr.Name = "bt_mr";
            this.bt_mr.Size = new System.Drawing.Size(180, 45);
            this.bt_mr.TabIndex = 2;
            this.bt_mr.Text = "默认值";
            this.bt_mr.UseVisualStyleBackColor = true;
            this.bt_mr.Click += new System.EventHandler(this.bt_mr_Click);
            // 
            // bt_drawf2
            // 
            this.bt_drawf2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_drawf2.ForeColor = System.Drawing.Color.Red;
            this.bt_drawf2.Location = new System.Drawing.Point(30, 134);
            this.bt_drawf2.Margin = new System.Windows.Forms.Padding(4);
            this.bt_drawf2.Name = "bt_drawf2";
            this.bt_drawf2.Size = new System.Drawing.Size(180, 52);
            this.bt_drawf2.TabIndex = 2;
            this.bt_drawf2.Text = "分形树二";
            this.bt_drawf2.UseVisualStyleBackColor = true;
            this.bt_drawf2.Click += new System.EventHandler(this.bt_drawf2_Click);
            // 
            // bt_drawf1
            // 
            this.bt_drawf1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_drawf1.ForeColor = System.Drawing.Color.Red;
            this.bt_drawf1.Location = new System.Drawing.Point(30, 72);
            this.bt_drawf1.Margin = new System.Windows.Forms.Padding(4);
            this.bt_drawf1.Name = "bt_drawf1";
            this.bt_drawf1.Size = new System.Drawing.Size(180, 52);
            this.bt_drawf1.TabIndex = 2;
            this.bt_drawf1.Text = "分形树一";
            this.bt_drawf1.UseVisualStyleBackColor = true;
            this.bt_drawf1.Click += new System.EventHandler(this.bt_drawf1_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Gainsboro;
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 511);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(249, 16);
            this.panel7.TabIndex = 9;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.tb_llen);
            this.panel6.Controls.Add(this.tb_rangle);
            this.panel6.Controls.Add(this.tb_rlen);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.tb_langle);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 305);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(249, 206);
            this.panel6.TabIndex = 8;
            // 
            // tb_llen
            // 
            this.tb_llen.Location = new System.Drawing.Point(110, 27);
            this.tb_llen.Margin = new System.Windows.Forms.Padding(4);
            this.tb_llen.Name = "tb_llen";
            this.tb_llen.Size = new System.Drawing.Size(120, 28);
            this.tb_llen.TabIndex = 4;
            this.tb_llen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_rangle
            // 
            this.tb_rangle.Location = new System.Drawing.Point(110, 156);
            this.tb_rangle.Margin = new System.Windows.Forms.Padding(4);
            this.tb_rangle.Name = "tb_rangle";
            this.tb_rangle.Size = new System.Drawing.Size(120, 28);
            this.tb_rangle.TabIndex = 2;
            this.tb_rangle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_rlen
            // 
            this.tb_rlen.Location = new System.Drawing.Point(110, 114);
            this.tb_rlen.Margin = new System.Windows.Forms.Padding(4);
            this.tb_rlen.Name = "tb_rlen";
            this.tb_rlen.Size = new System.Drawing.Size(120, 28);
            this.tb_rlen.TabIndex = 2;
            this.tb_rlen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 160);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 18);
            this.label8.TabIndex = 3;
            this.label8.Text = "右枝倾角";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 118);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 18);
            this.label5.TabIndex = 3;
            this.label5.Text = "右长度比";
            // 
            // tb_langle
            // 
            this.tb_langle.Location = new System.Drawing.Point(110, 70);
            this.tb_langle.Margin = new System.Windows.Forms.Padding(4);
            this.tb_langle.Name = "tb_langle";
            this.tb_langle.Size = new System.Drawing.Size(120, 28);
            this.tb_langle.TabIndex = 2;
            this.tb_langle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 75);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 18);
            this.label6.TabIndex = 3;
            this.label6.Text = "左枝倾角";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 32);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 18);
            this.label7.TabIndex = 5;
            this.label7.Text = "左长度比";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 289);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(249, 16);
            this.panel1.TabIndex = 7;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.tb_zby);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.tb_level);
            this.panel5.Controls.Add(this.tb_angle);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.tb_length);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 71);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(249, 218);
            this.panel5.TabIndex = 6;
            // 
            // tb_zby
            // 
            this.tb_zby.Location = new System.Drawing.Point(110, 159);
            this.tb_zby.Margin = new System.Windows.Forms.Padding(4);
            this.tb_zby.Name = "tb_zby";
            this.tb_zby.Size = new System.Drawing.Size(120, 28);
            this.tb_zby.TabIndex = 6;
            this.tb_zby.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 164);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 18);
            this.label9.TabIndex = 7;
            this.label9.Text = "树起点Ｙ";
            // 
            // tb_level
            // 
            this.tb_level.Location = new System.Drawing.Point(110, 20);
            this.tb_level.Margin = new System.Windows.Forms.Padding(4);
            this.tb_level.Name = "tb_level";
            this.tb_level.Size = new System.Drawing.Size(120, 28);
            this.tb_level.TabIndex = 4;
            this.tb_level.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_angle
            // 
            this.tb_angle.Location = new System.Drawing.Point(110, 112);
            this.tb_angle.Margin = new System.Windows.Forms.Padding(4);
            this.tb_angle.Name = "tb_angle";
            this.tb_angle.Size = new System.Drawing.Size(120, 28);
            this.tb_angle.TabIndex = 2;
            this.tb_angle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 117);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "树干倾角";
            // 
            // tb_length
            // 
            this.tb_length.Location = new System.Drawing.Point(110, 66);
            this.tb_length.Margin = new System.Windows.Forms.Padding(4);
            this.tb_length.Name = "tb_length";
            this.tb_length.Size = new System.Drawing.Size(120, 28);
            this.tb_length.TabIndex = 2;
            this.tb_length.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 70);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "树干长度";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 24);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "树的层数";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 56);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(249, 15);
            this.panel3.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.tb_penwidth);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(249, 56);
            this.panel2.TabIndex = 3;
            // 
            // tb_penwidth
            // 
            this.tb_penwidth.Location = new System.Drawing.Point(110, 12);
            this.tb_penwidth.Margin = new System.Windows.Forms.Padding(4);
            this.tb_penwidth.Name = "tb_penwidth";
            this.tb_penwidth.Size = new System.Drawing.Size(120, 28);
            this.tb_penwidth.TabIndex = 4;
            this.tb_penwidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 16);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 18);
            this.label2.TabIndex = 5;
            this.label2.Text = "树线宽度";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.panel12);
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Margin = new System.Windows.Forms.Padding(4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1503, 864);
            this.panel10.TabIndex = 2;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.pictureBox1);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(0, 82);
            this.panel12.Margin = new System.Windows.Forms.Padding(4);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(1503, 782);
            this.panel12.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1503, 782);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.panel14);
            this.panel11.Controls.Add(this.panel13);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Margin = new System.Windows.Forms.Padding(4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1503, 82);
            this.panel11.TabIndex = 0;
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel14.Controls.Add(this.tb_strin2);
            this.panel14.Controls.Add(this.splitter1);
            this.panel14.Controls.Add(this.tb_strin1);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Margin = new System.Windows.Forms.Padding(4);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(929, 80);
            this.panel14.TabIndex = 1;
            // 
            // tb_strin2
            // 
            this.tb_strin2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_strin2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_strin2.Location = new System.Drawing.Point(0, 35);
            this.tb_strin2.Margin = new System.Windows.Forms.Padding(4);
            this.tb_strin2.Name = "tb_strin2";
            this.tb_strin2.Size = new System.Drawing.Size(925, 31);
            this.tb_strin2.TabIndex = 2;
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter1.Location = new System.Drawing.Point(0, 31);
            this.splitter1.Margin = new System.Windows.Forms.Padding(4);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(925, 4);
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            // 
            // tb_strin1
            // 
            this.tb_strin1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_strin1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_strin1.Location = new System.Drawing.Point(0, 0);
            this.tb_strin1.Margin = new System.Windows.Forms.Padding(4);
            this.tb_strin1.Name = "tb_strin1";
            this.tb_strin1.Size = new System.Drawing.Size(925, 31);
            this.tb_strin1.TabIndex = 0;
            this.tb_strin1.Text = "A(B(C,D(E(F),G(,H))),I(,J(K)))";
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.tb_Traversalpp);
            this.panel13.Controls.Add(this.bt_create2);
            this.panel13.Controls.Add(this.tb_T0_Draw);
            this.panel13.Controls.Add(this.tb_Traversal);
            this.panel13.Controls.Add(this.panel15);
            this.panel13.Controls.Add(this.bt_create);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel13.Location = new System.Drawing.Point(929, 0);
            this.panel13.Margin = new System.Windows.Forms.Padding(4);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(572, 80);
            this.panel13.TabIndex = 0;
            // 
            // tb_Traversalpp
            // 
            this.tb_Traversalpp.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Traversalpp.ForeColor = System.Drawing.Color.Blue;
            this.tb_Traversalpp.Location = new System.Drawing.Point(322, 44);
            this.tb_Traversalpp.Margin = new System.Windows.Forms.Padding(4);
            this.tb_Traversalpp.Name = "tb_Traversalpp";
            this.tb_Traversalpp.Size = new System.Drawing.Size(75, 30);
            this.tb_Traversalpp.TabIndex = 6;
            this.tb_Traversalpp.Text = "+";
            this.tb_Traversalpp.UseVisualStyleBackColor = true;
            this.tb_Traversalpp.Click += new System.EventHandler(this.tb_Traversalpp_Click);
            // 
            // bt_create2
            // 
            this.bt_create2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_create2.ForeColor = System.Drawing.Color.Blue;
            this.bt_create2.Location = new System.Drawing.Point(7, 42);
            this.bt_create2.Margin = new System.Windows.Forms.Padding(4);
            this.bt_create2.Name = "bt_create2";
            this.bt_create2.Size = new System.Drawing.Size(150, 35);
            this.bt_create2.TabIndex = 3;
            this.bt_create2.Text = "生成二叉树2";
            this.bt_create2.UseVisualStyleBackColor = true;
            this.bt_create2.Click += new System.EventHandler(this.bt_create2_Click);
            // 
            // tb_T0_Draw
            // 
            this.tb_T0_Draw.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_T0_Draw.ForeColor = System.Drawing.Color.Blue;
            this.tb_T0_Draw.Location = new System.Drawing.Point(204, 9);
            this.tb_T0_Draw.Margin = new System.Windows.Forms.Padding(4);
            this.tb_T0_Draw.Name = "tb_T0_Draw";
            this.tb_T0_Draw.Size = new System.Drawing.Size(110, 35);
            this.tb_T0_Draw.TabIndex = 5;
            this.tb_T0_Draw.Text = "层次画图";
            this.tb_T0_Draw.UseVisualStyleBackColor = true;
            this.tb_T0_Draw.Click += new System.EventHandler(this.tb_T0_Draw_Click);
            // 
            // tb_Traversal
            // 
            this.tb_Traversal.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_Traversal.ForeColor = System.Drawing.Color.Blue;
            this.tb_Traversal.Location = new System.Drawing.Point(322, 6);
            this.tb_Traversal.Margin = new System.Windows.Forms.Padding(4);
            this.tb_Traversal.Name = "tb_Traversal";
            this.tb_Traversal.Size = new System.Drawing.Size(75, 38);
            this.tb_Traversal.TabIndex = 5;
            this.tb_Traversal.Text = "遍历";
            this.tb_Traversal.UseVisualStyleBackColor = true;
            this.tb_Traversal.Click += new System.EventHandler(this.tb_Traversal_Click);
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.rb_tr0);
            this.panel15.Controls.Add(this.rb_tr3);
            this.panel15.Controls.Add(this.rb_tr2);
            this.panel15.Controls.Add(this.rb_tr1);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel15.Location = new System.Drawing.Point(407, 0);
            this.panel15.Margin = new System.Windows.Forms.Padding(4);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(165, 80);
            this.panel15.TabIndex = 4;
            // 
            // rb_tr0
            // 
            this.rb_tr0.AutoSize = true;
            this.rb_tr0.Checked = true;
            this.rb_tr0.Location = new System.Drawing.Point(9, 8);
            this.rb_tr0.Margin = new System.Windows.Forms.Padding(4);
            this.rb_tr0.Name = "rb_tr0";
            this.rb_tr0.Size = new System.Drawing.Size(69, 22);
            this.rb_tr0.TabIndex = 3;
            this.rb_tr0.TabStop = true;
            this.rb_tr0.Text = "层次";
            this.rb_tr0.UseVisualStyleBackColor = true;
            // 
            // rb_tr3
            // 
            this.rb_tr3.AutoSize = true;
            this.rb_tr3.Location = new System.Drawing.Point(87, 40);
            this.rb_tr3.Margin = new System.Windows.Forms.Padding(4);
            this.rb_tr3.Name = "rb_tr3";
            this.rb_tr3.Size = new System.Drawing.Size(69, 22);
            this.rb_tr3.TabIndex = 2;
            this.rb_tr3.Text = "后序";
            this.rb_tr3.UseVisualStyleBackColor = true;
            // 
            // rb_tr2
            // 
            this.rb_tr2.AutoSize = true;
            this.rb_tr2.Location = new System.Drawing.Point(87, 8);
            this.rb_tr2.Margin = new System.Windows.Forms.Padding(4);
            this.rb_tr2.Name = "rb_tr2";
            this.rb_tr2.Size = new System.Drawing.Size(69, 22);
            this.rb_tr2.TabIndex = 1;
            this.rb_tr2.Text = "中序";
            this.rb_tr2.UseVisualStyleBackColor = true;
            // 
            // rb_tr1
            // 
            this.rb_tr1.AutoSize = true;
            this.rb_tr1.Location = new System.Drawing.Point(9, 40);
            this.rb_tr1.Margin = new System.Windows.Forms.Padding(4);
            this.rb_tr1.Name = "rb_tr1";
            this.rb_tr1.Size = new System.Drawing.Size(69, 22);
            this.rb_tr1.TabIndex = 0;
            this.rb_tr1.Text = "先序";
            this.rb_tr1.UseVisualStyleBackColor = true;
            // 
            // bt_create
            // 
            this.bt_create.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_create.ForeColor = System.Drawing.Color.Blue;
            this.bt_create.Location = new System.Drawing.Point(6, 4);
            this.bt_create.Margin = new System.Windows.Forms.Padding(4);
            this.bt_create.Name = "bt_create";
            this.bt_create.Size = new System.Drawing.Size(150, 35);
            this.bt_create.TabIndex = 3;
            this.bt_create.Text = "生成二叉树1";
            this.bt_create.UseVisualStyleBackColor = true;
            this.bt_create.Click += new System.EventHandler(this.bt_create_Click);
            // 
            // Form_BinTree
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1756, 864);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel0);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form_BinTree";
            this.Text = "二叉树的运算";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form_BinTree_Load);
            this.panel0.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel0;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button bt_mr;
        private System.Windows.Forms.Button bt_drawf2;
        private System.Windows.Forms.Button bt_drawf1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox tb_llen;
        private System.Windows.Forms.TextBox tb_rangle;
        private System.Windows.Forms.TextBox tb_rlen;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_langle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox tb_zby;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb_level;
        private System.Windows.Forms.TextBox tb_angle;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_length;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tb_penwidth;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox tb_strin2;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.TextBox tb_strin1;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button bt_create;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.RadioButton rb_tr2;
        private System.Windows.Forms.RadioButton rb_tr1;
        private System.Windows.Forms.RadioButton rb_tr0;
        private System.Windows.Forms.RadioButton rb_tr3;
        private System.Windows.Forms.Button tb_Traversal;
        private System.Windows.Forms.Button bt_create2;
        private System.Windows.Forms.Button tb_Traversalpp;
        private System.Windows.Forms.Button tb_T0_Draw;
    }
}