﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;//读取文件所需的

namespace DS_CS
{
    public partial class Form_Graph : Form
    {
        private CGraphM m_graph;
        private string graph_matrix="";
        public Form_Graph()
        {
            InitializeComponent();
        }

        private void bt_openfile_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            //string str1 = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string str = "..\\..\\data\\";
            dlg.InitialDirectory = str;
            dlg.Filter = "数据文件（*.dat）|*.dat|文本文件（*.txt）|*.txt";
            dlg.Title = "打开迷宫数据文件";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                tb_fname.Text = dlg.FileName;
                StreamReader sr = new StreamReader(tb_fname.Text);
                graph_matrix = sr.ReadToEnd();
                sr.Close();
                bt_creategraph.Enabled = true;
            }
            else
                bt_creategraph.Enabled = false;
        }

        private void bt_creategraph_Click(object sender, EventArgs e)
        {
            if (graph_matrix != "")
            {
                m_graph.Read(graph_matrix);
                tb_graph_matrix.Text = m_graph.Write_graph_matrix();
            }
                m_graph.DrawMaze(pb_graph);



        }

        private void Form_Graph_Load(object sender, EventArgs e)
        {
            m_graph = new CGraphM();
        }

        private void bt_createmaze_Click(object sender, EventArgs e)
        {

        }
    }
}