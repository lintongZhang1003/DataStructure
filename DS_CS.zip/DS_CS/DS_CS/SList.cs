﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DS_CS
{
    class SListnode<Type>//单链表结点类
    {
        public Type data;
        public SListnode<Type> next;
        //--------------------------------------------------------------------------------
        public SListnode()
        {
            //data=0;
            next = null;
        }
        public SListnode(Type data)
		{
            this.data=data;
            next = null; 
        }
        public SListnode(Type data, SListnode<Type> next)
        { 
            this.data=data;
            this.next=next; 
        }
    }
    //================================================================================
    class CSList<Type>
    {
        private SListnode<Type> head;
        private SListnode<Type> current;//指向当前节点的指针
        //--------------------------------------------------------------------------------
        public CSList()
        {
            head = new SListnode<Type>();
	        current=head;
        }
        public void SetCurrent(SListnode<Type> cp) { current = cp; }//设置当前指针
        public SListnode<Type> GetCurrent() { return current; }//返回当前指针
        public Type GetCurrentData() { return current.data; }//返回当前数据
        public SListnode<Type> Getnext() { return current.next; }//返回下一结点地址
        public SListnode<Type> Gethead() { return head; }//返回头结点地址
        public void Modifydata(Type value) { current.data = value; }//修改当前结点数据
        public int Length() //求单链表长度
        {
            SListnode<Type> p = head.next;
            int count=0;
            while(p!=null)
            {
                p = p.next;
		        count++;
	        }
            return count;
        }
        public Type First()//设置头结点为当前结点
        {
            current = head;
            return current.data;
        }
        public Type Next()//设置下一结点为当前结点
        {
            if(current.next!= null)
                current = current.next;
            return current.data;
        }
        public void Create(int n, bool InsertInHead)//生成n个结点
        { 
	        MakeEmpty();
	        /*if(InsertInHead)
	        {
		        for(int i=1;i<=n;i++)
                    Insert(i,1);	
	        }
	        else
	        {
		        for(int i=1;i<=n;i++)
			        Insert(i,i);	
	        }*/
            First();
        }
        public void MakeEmpty()//清空单链表
        {
            head.next = null;
	        current=head;
        }
        public SListnode<Type> Find(Type value)//按给定值查找单链表
        {
            SListnode<Type> p = head.next;
            while (p != null && !p.next.data.Equals(value))//EqualityComparer<Type>.Default.Equals(
		        p=p.next;
            return p;
        }
        public SListnode<Type> Getnode(int i)//返回第i个结点的地址
        {
            if(i<0)  return null;
            if(i==0)  return head;
            SListnode<Type> p = head;
            for(int j=1;p!=null&&j<=i;j++)
		        p=p.next;
            return p;
        }
        public Type Getdata(int i)//返回第i个结点的数据
        {
            SListnode<Type> p = Getnode(i);
            if(p==null||p==head)
                return (p.data);
            else
		        return (p.data);
        }
        public void Insert(Type value, int i)//在第i个结点处插入结点
        {
            if(i<1)  i=1;
            if(i>Length()+1) i=Length()+1;
            SListnode<Type> p = Getnode(i - 1);
            SListnode<Type> newnode = new SListnode<Type>(value, p.next);
            p.next=newnode;
        }
        public void Insert(Type value, bool before)//在当前结点处插入结点
        {
	        if(current==head)
		        before=false;
            SListnode<Type> newnode;
            if(before)
	        {
                SListnode<Type> p = head;
		        while(p.next!=current)
			        p=p.next;
                newnode = new SListnode<Type>(value, p.next);
                p.next=newnode;
	        }
	        else
	        {
                newnode = new SListnode<Type>(value, current.next);
                current.next=newnode;
	        }
            current=newnode;
        }
        public void Delete(int i)//删除第i个结点
        {
            SListnode<Type> p = Getnode(i - 1), q;
            q=p.next;
            p.next=q.next;
        }
        ///////////////////////////////////////////////////////////
        public void Delete()//删除当前结点
        {
	        if(current==head)
		        return;
            SListnode<Type> p = head;
            while(p.next!=current)
		        p=p.next;
            p.next=current.next;
	        if(p.next!=null)
		        current=p.next;
	        else
		        current=p;
        }
        public void Remove(Type value)//删除给定值的结点
        {
            SListnode<Type> p = head, q = p.next;
            while(q!=null&&!q.data.Equals(value))
            { 
		        p=p.next;
		        q=p.next;
	        }
            if(q!=null)
            { 
		        p.next=q.next;
	        }
        }

        public void convers1()
        {
            SListnode<Type> p, q;
            p = head.next;
            head.next = null;
            while (p != null)
            {
              q = p;
              p = p.next;
              q.next = head.next;
              head.next = q;
            }
        }
    }
}
