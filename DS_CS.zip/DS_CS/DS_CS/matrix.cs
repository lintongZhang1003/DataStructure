﻿using System;




namespace DS_CS
{
    class matrix//矩阵类
    {
        private int rows, cols;//矩阵的行,列
        private Rational[,] elems;//矩阵的元素


        //---------------------------------------------------------------------------
        public matrix(int rows, int cols) //创建单位阵
        {
            this.rows = rows;
            this.cols = cols;
            this.elems = new Rational[rows , cols];
            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= cols; j++)
                {
                    if (i == j)
                        elems[i-1,j-1] = new Rational(1,1);
                    else
                        elems[i-1,j-1] = new Rational(0,1);
                }
            }
        }
        public matrix(matrix ob)//拷贝构造函数
        {
            this.rows = ob.rows;
            this.cols = ob.cols;
            this.elems = new Rational[ob.rows, ob.cols];
            for (int i = 1; i <= ob.rows; i++)
            {
                for (int j = 1; j <= ob.cols; j++)
                {
                    this.elems[i - 1, j - 1] = ob.elems[i - 1, j - 1];
                }
            }
        }
        public matrix(int rows, int cols, Rational[] elem) 
        {
            this.rows = rows;
            this.cols = cols;
            this.elems = new Rational[rows , cols];
            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= cols; j++)
                {
                    int k = (i-1) * cols + (j-1);
                    elems[i-1,j-1] = elem[k];
                }
            }
        }
        public matrix(int m_rows, int m_cols, string m_input) //根据给定的字符串创建矩阵
        {
            int i, j, ks = 0;
            int num = 0, den = 1;
            int len = m_input.Length;
            string str = "";
            this.rows = m_rows;
            this.cols = m_cols;
            this.elems = new Rational[m_rows, m_cols];

            for (i = 1; i <= m_rows; i++)
            {
                if (ks >= len)
                    return ;
                for (j = 1; j <= m_cols; j++)
                {
                    str = "";
                    while ((ks < len) && ((m_input[ks] < '0') || (m_input[ks] > '9')) && m_input[ks] != '-')
                        ks++;
                    while ((ks < len) && ((m_input[ks] >= '0') && (m_input[ks] <= '9') || (m_input[ks] == '-')))
                        str = str + m_input[ks++];
                    if (str != "")
                        num = Convert.ToInt32(str);
                    else
                        num = 0;
                    while ((ks < len) && (m_input[ks] == ' '))
                        ks++;
                    if ((ks < len) && (m_input[ks] == '/'))
                    {
                        str = ""; ks++;
                        while ((ks < len) && (m_input[ks] == ' '))
                            ks++;
                        while ((ks < len) && (m_input[ks] >= '0') && (m_input[ks] <= '9'))
                            str = str + m_input[ks++];
                        if (str != "")
                            den = Convert.ToInt32(str);
                        else
                            den = 1;
                        while ((ks < len) && (m_input[ks] == ' '))
                            ks++;
                    }
                    else
                    {
                        den = 1;
                    }
                    Rational rat = new Rational(num, den);
                    setelems(i, j, rat);
                    if ((ks < len) && ((m_input[ks] == '\r') || (m_input[ks] == '\n')))
                    {
                        break;
                    }
                    else if (ks >= len)
                        return;
                }
            }
            return;

        }
        //---------------------------------------------------------------------------
        public override string ToString()
        {
            int i, j;
            string m_output = "";
            string str;
            for (i = 1; i <= rows; i++)
            {
                for (j = 1; j <= cols; j++)
                {
                    if (elems[i - 1, j - 1].Den == 1)
                        str = "\t " + elems[i - 1, j - 1].Num;
                    else
                        str = "\t" + elems[i - 1, j - 1].Num + "/" + elems[i - 1, j - 1].Den;
                    m_output += str;
                }
                m_output += "\r\n";
            }
            return m_output;
        }
        public string ToString1()
        {
            int i, j;
            string m_output = "";
            string str;
            for (i = 1; i <= rows; i++)
            {
                for (j = 1; j <= cols; j++)
                {
                    if(j==cols)
                        m_output += "\t |";
                    if (elems[i - 1, j - 1].Den == 1)
                        str = "\t " + elems[i - 1, j - 1].Num;
                    else
                        str = "\t" + elems[i - 1, j - 1].Num + "/" + elems[i - 1, j - 1].Den;
                    m_output += str;
                }
                m_output += "\r\n";
            }
            return m_output;
        }
        //---------------------------------------------------------------------------
        public int getrows() { return rows; }             //取行数
        public int getcols() { return cols; }             //取列数
        //---------------------------------------------------------------------------
        public void setelems(int row, int col, Rational value)
        {
            if (1 <= row && row <= rows && 1 <= col && col <= cols)
                elems[row-1,col-1] = value;
            else
                elems[0,0] = value;

        }
        //---------------------------------------------------------------------------
        public Rational getelems(int row, int col)
        {
            if (1 <= row && row <= rows && 1 <= col && col <= cols)
                return elems[row-1,col-1];
            else
                return elems[0,0];

        }
        //---------------------------------------------------------------------------
        public static matrix operator +(matrix m1, matrix m2)
        {
            if(m1.rows!=m2.rows||m1.cols!=m2.cols)
                return m1;
            matrix mt = new matrix(m1.rows, m1.cols);
            for (int i = 1; i <= m1.rows; i++)
            {
                for (int j = 1; j <= m1.cols; j++)
                {
                    mt.elems[i-1,j-1] = m1.elems[i-1,j-1]+ m2.elems[i-1,j-1];
                }
            }
            return mt;
        }
        //---------------------------------------------------------------------------
        public static matrix operator -(matrix m1, matrix m2)
        {
            if (m1.rows != m2.rows || m1.cols != m2.cols)
                return null;
            matrix mt = new matrix(m1.rows, m1.cols);
            for (int i = 1; i <= m1.rows; i++)
            {
                for (int j = 1; j <= m1.cols; j++)
                {
                    mt.elems[i - 1, j - 1] = m1.elems[i - 1, j - 1] - m2.elems[i - 1, j - 1];
                }
            }
            return mt;
        }
        //---------------------------------------------------------------------------
        public static matrix operator *(matrix m1, matrix m2)
        {
            if (m1.cols != m2.rows)
                return null;
            matrix mt = new matrix(m1.rows, m2.cols);
            for (int i = 1; i <= m1.rows; i++)
            {
                for (int j = 1; j <= m2.cols; j++)
                {
                    mt.elems[i-1,j-1] = new Rational(0,1);
                    for (int k = 1; k <= m1.cols; k++)
                    {
                        mt.elems[i-1,j-1] = mt.elems[i-1,j-1] + m1.elems[i-1,k-1] * m2.elems[k-1,j-1];
                    }
                }
            }
            return mt;
        }
        //---------------------------------------------------------------------------
        public matrix rowt(out int rm,out string strout)
        {
            //返回的矩阵“matrix rowt”为原矩阵的行标准型矩阵
            //返回整数值“out int rm”为原矩阵的秩
            //返回的字符串“out string strout ”为行标准型变换过程字符串
            int i, j, i1, j1, k;
            bool b;
            Rational tem = new Rational(0, 1);
            matrix mt = new matrix(this.rows, this.cols);
            strout = "";
            String strt = "";

            for (i = 1; i <= this.rows; i++)//把当前矩阵this赋给临时矩阵mt
            {
                for (j = 1; j <= this.cols; j++)
                {
                    mt.elems[i - 1, j - 1] = this.elems[i - 1, j - 1] ;
                }
            }


            i = 1; j = 1; rm = 0;
            while (i <= mt.rows && j <= mt.cols)
            {
                strout += (j - 1) + "----------------------------------------------------------------------\r\n";
                strt = mt.ToString();
                strout += strt;

                b = false;
                for (k = i; k <= mt.rows; k++)//找元素(i,j)下不为0的元素
		        {
                    if (mt.elems[k - 1, j - 1].Num != 0)//在第k行找到了非零元素
			        {
    			        b=true;
                        if (k != i)
                        {
                            for (j1 = j; j1 <= mt.cols; j1++)//第k行与第i行交换
                            {

                                tem = mt.elems[k - 1, j1 - 1];
                                mt.elems[k - 1, j1 - 1] = mt.elems[i - 1, j1 - 1];
                                mt.elems[i - 1, j1 - 1] = tem;
                            }
                        }
    			        break;
			        }
		        }
		        if(b==true)//找到了元素(i,j)下不为0的元素
		        {
                    rm++;
                    for (j1 = j + 1; j1 <= mt.cols; j1++)//第i行的主元素化为1
                    {
                        mt.elems[i - 1, j1 - 1] = mt.elems[i - 1, j1 - 1] / mt.elems[i - 1, j - 1];
                    }
                    mt.elems[i - 1, j - 1] = new Rational(1, 1);
                    for (i1 = 1; i1 <= mt.rows; i1++)//将元素(i,j)上下的元素全化为0
			        {
				        if(i1==i)  continue;
                        tem = mt.elems[i1 - 1, j - 1];
                        for (j1 = j; j1 <= mt.cols; j1++)
                        {
                            mt.elems[i1 - 1, j1 - 1] = mt.elems[i1 - 1, j1 - 1] - tem * mt.elems[i - 1, j1 - 1];
                        }
			        }
                    i++; j++;//本列有秩
		        }
		        else  j++;//本列无秩
            }
            strout += (j - 1) + "----------------------------------------------------------------------\r\n";
            strt = mt.ToString();
            strout += strt;
            strout += "End--------------------------------------------------------------------\r\n\r\n";
            return mt;
        }
        //---------------------------------------------------------------------------
        public matrix rowt_rank(out int rm0, out int rm1,int[] rv)//行标准型，并返回矩阵的秩和秩向量
            //返回向量rv存放每一列是否有秩，无秩为0，有秩的主元素所处的行
        {
            int i, j, i1, j1, k;
            bool b;
            Rational tem = new Rational(0, 1);
            matrix mt = new matrix(this.rows, this.cols);

            for (i = 1; i <= this.rows; i++)//把当前矩阵this赋给临时矩阵mt
            {
                for (j = 1; j <= this.cols; j++)
                {
                    mt.elems[i - 1, j - 1] = this.elems[i - 1, j - 1];
                }
            }


            i = 1; j = 1; rm0 = 0; rm1 = 0;
            while (i <= mt.rows && j <= mt.cols)
            {
                b = false;
                for (k = i; k <= mt.rows; k++)//找元素(i,j)下不为0的元素
                {
                    if (mt.elems[k - 1, j - 1].Num != 0)//在第k行找到了非零元素
                    {
                        b = true;
                        if (k != i)
                        {
                            for (j1 = j; j1 <= mt.cols; j1++)//第k行与第i行交换
                            {

                                tem = mt.elems[k - 1, j1 - 1];
                                mt.elems[k - 1, j1 - 1] = mt.elems[i - 1, j1 - 1];
                                mt.elems[i - 1, j1 - 1] = tem;
                            }
                        }
                        break;
                    }
                }
                if (b == true)//找到了元素(i,j)下不为0的元素
                {
                    if(j < mt.cols)
                        rm0++;
                    rm1++;
                    for (j1 = j + 1; j1 <= mt.cols; j1++)//第i行的主元素化为1
                        mt.elems[i - 1, j1 - 1] = mt.elems[i - 1, j1 - 1] / mt.elems[i - 1, j - 1];
                    mt.elems[i - 1, j - 1] = new Rational(1, 1);
                    for (i1 = 1; i1 <= mt.rows; i1++)//将元素(i,j)上下的元素全化为0
                    {
                        if (i1 == i) continue;
                        tem = mt.elems[i1 - 1, j - 1];
                        for (j1 = j; j1 <= mt.cols; j1++)
                            mt.elems[i1 - 1, j1 - 1] = mt.elems[i1 - 1, j1 - 1] - tem * mt.elems[i - 1, j1 - 1];
                    }
                    rv[j-1] = i;//主元素所在的行
                    i++; j++;
                }
                else
                {
                    rv[j-1] = 0;
                    j++;//本列无秩
                }
            }
            return mt;
        }
        //---------------------------------------------------------------------------
        public Rational det()
        {
            int i, j, i1, j1, k;
            int sign=1;
            Rational det=new Rational(1,1);
            Rational ling=new Rational(0,1);
            bool b;
            Rational tem = new Rational(0, 1);
            matrix mt = new matrix(this.rows, this.cols);
            for (i = 1; i <= this.rows; i++)
            {
                for (j = 1; j <= this.cols; j++)
                {
                    mt.elems[i - 1, j - 1] = this.elems[i - 1, j - 1];
                }
            }

            i = 1; j = 1;
            while (i <= this.rows && j <= this.cols)
            {
                b = false;
                for (k = i; k <= this.rows; k++)//找元素(i,j)下不为0的元素
                {
                    if (mt.elems[k - 1, j - 1].Num != 0)
                    {
                        b = true;
                        if (k != i)
                        {
                            sign=-sign;
                            for (j1 = j; j1 <= this.cols; j1++)
                            {
                                tem = mt.elems[k - 1, j1 - 1];
                                mt.elems[k - 1, j1 - 1] = mt.elems[i - 1, j1 - 1];
                                mt.elems[i - 1, j1 - 1] = tem;
                            }
                        }
                        break;
                    }
                }
                if (b == true)//找到了元素(i,j)下不为0的元素
                {
                    det=det*mt.elems[i - 1, j - 1];
                    for (j1 = j + 1; j1 <= this.cols; j1++)
                        mt.elems[i - 1, j1 - 1] = mt.elems[i - 1, j1 - 1] / mt.elems[i - 1, j - 1];
                    mt.elems[i - 1, j - 1] = new Rational(1, 1);
                    mt.elems[i - 1, j - 1].Num = 1;
                    mt.elems[i - 1, j - 1].Den = 1;
                    for (i1 = 1; i1 <= this.rows; i1++)//将元素(i,j)上下的元素全化为0
                    {
                        if (i1 == i) continue;
                        tem = mt.elems[i1 - 1, j - 1];
                        for (j1 = j; j1 <= this.cols; j1++)
                            mt.elems[i1 - 1, j1 - 1] = mt.elems[i1 - 1, j1 - 1] - tem * mt.elems[i - 1, j1 - 1];
                    }
                    i++; j++;
                }
                else 
                    return ling;//本列无秩
            }
            det = new Rational(det.Num * sign, det.Den);
            return det;
        }
        //---------------------------------------------------------------------------
        public matrix mat_unite(matrix ob1, matrix ob2)//两个方阵合并
        {
            matrix mt = new matrix(ob1.rows, ob1.rows * 2);
            for (int i = 1; i <= ob1.rows; i++)
            {
                for (int j = 1; j <= ob1.rows; j++)
                {
                    mt.elems[i - 1, j - 1] = ob1.elems[i - 1, j - 1];
                    mt.elems[i - 1, ob1.rows + j - 1] = ob2.elems[i - 1, j - 1];
                }
            }
            return mt;
        }
        //---------------------------------------------------------------------------
        public matrix mat_inv(out string strout)//求矩阵的逆
        {
            int rm,rm1;
            strout = "";
            if (rows != cols)
                return this;
            matrix mr = new matrix(rows, rows);
            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= rows; j++)
                {
                    mr.elems[i - 1, j - 1] = this.elems[i - 1, j - 1];
                }
            }
            mr = mr.rowt(out rm, out strout);
            matrix mt = new matrix(rows, rows * 2);
            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= rows; j++)
                {
                    mt.elems[i - 1, j - 1] = this.elems[i - 1, j - 1];
                    if(i==j)
                        mt.elems[i - 1, rows + j - 1] = new Rational(1, 1);
                    else
                        mt.elems[i - 1, rows + j - 1] = new Rational(0, 1);
                }
            }
            strout = "";
            mt = mt.rowt(out rm1, out strout);
            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= rows; j++)
                {
                    if(rm<rows)
                        mr.elems[i - 1, j - 1] = new Rational(0,1);
                    else
                        mr.elems[i - 1, j - 1] = mt.elems[i - 1, rows + j - 1];
                }
            }
            return mr;
        }
        //---------------------------------------------------------------------------
        public matrix mat_solve(bool le,out string strout)//解线性方程组,返回行标准型，输出解的字符串
        {
            int rm0,rm1;//系数矩阵的秩和增广矩阵的秩
            int[] rv = new int[this.cols];
            strout = "";
            matrix mt = this.rowt_rank(out rm0,out rm1,rv);
            if (le == true)//齐次线性方程组
            {
                int n = mt.cols;//未知数的个数
                if (rm1 == n)
                {
                    strout = "齐次线性方程组只有零解";
                }
                else//有非零解
                {
                    matrix msolve = new matrix(n, n - rm1);//解空间矩阵，线性无关个数为n-r
                    for (int j = 1; j <= n - rm1; j++)
                    {
                        int k = 1;//记录第几个无秩的列
                        int ik = 0;//记录列向量中赋值1的位置
                        for (int i = 1; i <= n; i++)//给自由变量（无秩的变量）赋值
                        {
                            if (rv[i - 1] == 0)//无秩的列
                            {
                                if (j == k)
                                {
                                    msolve.elems[i - 1, j - 1] = new Rational(1, 1);
                                    ik = i;
                                }
                                else
                                    msolve.elems[i - 1, j - 1] = new Rational(0, 1);
                                k++;
                            }
                        }
                        for (int i = 1; i <= n; i++)
                        {
                            if (rv[i - 1] != 0)//有秩的列
                            {
                                msolve.elems[i - 1, j - 1] = new Rational(-mt.elems[rv[i - 1] - 1, ik - 1]);
                            }
                        }
                    }
                    strout = "齐次线性方程组有非零解\r\n\r\n";
                    strout += msolve.ToString();
                }
            }
            else//非线性方程组
            { 
                int n = mt.cols-1;//未知数的个数
                if (rm0 < rm1)
                {
                    strout = "非齐次线性方程组无解";
                }
                else if(rm1 == n)
                {
                    matrix msolve = new matrix(n, 1);//唯一解
                    for (int i = 1; i <= n; i++)
                    {
                        if (rv[i - 1] != 0)//有秩的列
                        {
                            msolve.elems[i - 1, 0] = new Rational(mt.elems[rv[i - 1] - 1, n]);
                        }
                    }
                    strout = "非齐次线性方程组有唯一解\r\n\r\n";
                    strout += msolve.ToString();
                }
                else//有无穷解
                {
                    matrix msolve = new matrix(n, n - rm1+1);//解空间矩阵，齐次解空间无关个数为n-r
                    for (int j = 1; j <= n - rm1; j++)//齐次解空间
                    {
                        int k = 1;//记录第几个无秩的列
                        int ik = 0;//记录列向量中赋值1的位置
                        for (int i = 1; i <= n; i++)//给自由变量（无秩的变量）赋值
                        {
                            if (rv[i - 1] == 0)//无秩的列
                            {
                                if (j == k)
                                {
                                    msolve.elems[i - 1, j - 1] = new Rational(1, 1);
                                    ik = i;
                                }
                                else
                                    msolve.elems[i - 1, j - 1] = new Rational(0, 1);
                                k++;
                            }
                        }
                        for (int i = 1; i <= n; i++)
                        {
                            if (rv[i - 1] != 0)//有秩的列
                            {
                                msolve.elems[i - 1, j - 1] = new Rational(-mt.elems[rv[i - 1] - 1, ik - 1]);
                            }
                        }
                    }
                    for (int i = 1; i <= n; i++)//非齐次特解
                    {
                        if (rv[i - 1] != 0)//有秩的列
                        {
                            msolve.elems[i - 1, n - rm1] = new Rational(mt.elems[rv[i - 1] - 1, n]);
                        }
                        else
                        {
                            msolve.elems[i - 1, n - rm1] = new Rational(0,1);
                        }
                    }
                    strout = "非齐次线性方程组有无穷解\r\n\r\n";
                    strout += msolve.ToString1();
                }
            }
            return mt;
        }
        //---------------------------------------------------------------------------
    }

}
