﻿namespace DS_CS
{
    partial class Form_SeqList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bt_delete = new System.Windows.Forms.Button();
            this.bt_update = new System.Windows.Forms.Button();
            this.bt_insert = new System.Windows.Forms.Button();
            this.tb_modify_no = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_modify_dt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.rb_datano1 = new System.Windows.Forms.RadioButton();
            this.rb_datano3 = new System.Windows.Forms.RadioButton();
            this.rb_datano2 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.bt_close = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bt_empty = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_scount = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_maxcount = new System.Windows.Forms.TextBox();
            this.rb_datasx1 = new System.Windows.Forms.RadioButton();
            this.rb_datasx2 = new System.Windows.Forms.RadioButton();
            this.bt_Fib = new System.Windows.Forms.Button();
            this.bt_ss = new System.Windows.Forms.Button();
            this.bt_create = new System.Windows.Forms.Button();
            this.panel6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(524, 645);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.richTextBox1);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(524, 645);
            this.panel6.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.bt_close);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(524, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(248, 645);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(244, 12);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 276);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(244, 12);
            this.panel3.TabIndex = 3;
            // 
            // bt_delete
            // 
            this.bt_delete.Location = new System.Drawing.Point(20, 48);
            this.bt_delete.Margin = new System.Windows.Forms.Padding(4);
            this.bt_delete.Name = "bt_delete";
            this.bt_delete.Size = new System.Drawing.Size(98, 45);
            this.bt_delete.TabIndex = 0;
            this.bt_delete.Text = "删除";
            this.bt_delete.UseVisualStyleBackColor = true;
            this.bt_delete.Click += new System.EventHandler(this.bt_delete_Click);
            // 
            // bt_update
            // 
            this.bt_update.Location = new System.Drawing.Point(20, 118);
            this.bt_update.Margin = new System.Windows.Forms.Padding(4);
            this.bt_update.Name = "bt_update";
            this.bt_update.Size = new System.Drawing.Size(98, 45);
            this.bt_update.TabIndex = 0;
            this.bt_update.Text = "修改";
            this.bt_update.UseVisualStyleBackColor = true;
            this.bt_update.Click += new System.EventHandler(this.bt_update_Click);
            // 
            // bt_insert
            // 
            this.bt_insert.Location = new System.Drawing.Point(20, 189);
            this.bt_insert.Margin = new System.Windows.Forms.Padding(4);
            this.bt_insert.Name = "bt_insert";
            this.bt_insert.Size = new System.Drawing.Size(98, 45);
            this.bt_insert.TabIndex = 0;
            this.bt_insert.Text = "插入";
            this.bt_insert.UseVisualStyleBackColor = true;
            this.bt_insert.Click += new System.EventHandler(this.bt_insert_Click);
            // 
            // tb_modify_no
            // 
            this.tb_modify_no.Location = new System.Drawing.Point(172, 92);
            this.tb_modify_no.Margin = new System.Windows.Forms.Padding(4);
            this.tb_modify_no.Name = "tb_modify_no";
            this.tb_modify_no.Size = new System.Drawing.Size(50, 28);
            this.tb_modify_no.TabIndex = 5;
            this.tb_modify_no.Text = "10";
            this.tb_modify_no.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(140, 26);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 18);
            this.label2.TabIndex = 6;
            this.label2.Text = "操作位置";
            // 
            // tb_modify_dt
            // 
            this.tb_modify_dt.Location = new System.Drawing.Point(147, 204);
            this.tb_modify_dt.Margin = new System.Windows.Forms.Padding(4);
            this.tb_modify_dt.Name = "tb_modify_dt";
            this.tb_modify_dt.Size = new System.Drawing.Size(76, 28);
            this.tb_modify_dt.TabIndex = 7;
            this.tb_modify_dt.Text = "1000";
            this.tb_modify_dt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(144, 171);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 8;
            this.label3.Text = "操作数据";
            // 
            // rb_datano1
            // 
            this.rb_datano1.AutoSize = true;
            this.rb_datano1.Location = new System.Drawing.Point(142, 58);
            this.rb_datano1.Margin = new System.Windows.Forms.Padding(4);
            this.rb_datano1.Name = "rb_datano1";
            this.rb_datano1.Size = new System.Drawing.Size(69, 22);
            this.rb_datano1.TabIndex = 9;
            this.rb_datano1.Text = "  首";
            this.rb_datano1.UseVisualStyleBackColor = true;
            // 
            // rb_datano3
            // 
            this.rb_datano3.AutoSize = true;
            this.rb_datano3.Location = new System.Drawing.Point(142, 132);
            this.rb_datano3.Margin = new System.Windows.Forms.Padding(4);
            this.rb_datano3.Name = "rb_datano3";
            this.rb_datano3.Size = new System.Drawing.Size(69, 22);
            this.rb_datano3.TabIndex = 10;
            this.rb_datano3.Text = "  尾";
            this.rb_datano3.UseVisualStyleBackColor = true;
            // 
            // rb_datano2
            // 
            this.rb_datano2.AutoSize = true;
            this.rb_datano2.Checked = true;
            this.rb_datano2.Location = new System.Drawing.Point(142, 96);
            this.rb_datano2.Margin = new System.Windows.Forms.Padding(4);
            this.rb_datano2.Name = "rb_datano2";
            this.rb_datano2.Size = new System.Drawing.Size(21, 20);
            this.rb_datano2.TabIndex = 11;
            this.rb_datano2.TabStop = true;
            this.rb_datano2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rb_datano2);
            this.groupBox3.Controls.Add(this.rb_datano3);
            this.groupBox3.Controls.Add(this.rb_datano1);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.tb_modify_dt);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.tb_modify_no);
            this.groupBox3.Controls.Add(this.bt_insert);
            this.groupBox3.Controls.Add(this.bt_update);
            this.groupBox3.Controls.Add(this.bt_delete);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 288);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(244, 268);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "结点移动";
            // 
            // panel5
            // 
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 556);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(244, 12);
            this.panel5.TabIndex = 7;
            // 
            // bt_close
            // 
            this.bt_close.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_close.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_close.Location = new System.Drawing.Point(24, 574);
            this.bt_close.Margin = new System.Windows.Forms.Padding(4);
            this.bt_close.Name = "bt_close";
            this.bt_close.Size = new System.Drawing.Size(201, 60);
            this.bt_close.TabIndex = 9;
            this.bt_close.Text = "退出";
            this.bt_close.UseVisualStyleBackColor = true;
            this.bt_close.Click += new System.EventHandler(this.bt_close_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bt_ss);
            this.groupBox1.Controls.Add(this.bt_Fib);
            this.groupBox1.Controls.Add(this.rb_datasx2);
            this.groupBox1.Controls.Add(this.rb_datasx1);
            this.groupBox1.Controls.Add(this.tb_maxcount);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tb_scount);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.bt_create);
            this.groupBox1.Controls.Add(this.bt_empty);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(0, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(244, 264);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "初始化";
            // 
            // bt_empty
            // 
            this.bt_empty.Location = new System.Drawing.Point(128, 159);
            this.bt_empty.Margin = new System.Windows.Forms.Padding(4);
            this.bt_empty.Name = "bt_empty";
            this.bt_empty.Size = new System.Drawing.Size(98, 45);
            this.bt_empty.TabIndex = 0;
            this.bt_empty.Text = "清空";
            this.bt_empty.UseVisualStyleBackColor = true;
            this.bt_empty.Click += new System.EventHandler(this.bt_empty_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 86);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "数据个数";
            // 
            // tb_scount
            // 
            this.tb_scount.Location = new System.Drawing.Point(132, 80);
            this.tb_scount.Margin = new System.Windows.Forms.Padding(4);
            this.tb_scount.Name = "tb_scount";
            this.tb_scount.Size = new System.Drawing.Size(76, 28);
            this.tb_scount.TabIndex = 4;
            this.tb_scount.Text = "20";
            this.tb_scount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 39);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "最大个数";
            // 
            // tb_maxcount
            // 
            this.tb_maxcount.Location = new System.Drawing.Point(132, 33);
            this.tb_maxcount.Margin = new System.Windows.Forms.Padding(4);
            this.tb_maxcount.Name = "tb_maxcount";
            this.tb_maxcount.Size = new System.Drawing.Size(76, 28);
            this.tb_maxcount.TabIndex = 7;
            this.tb_maxcount.Text = "100";
            this.tb_maxcount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rb_datasx1
            // 
            this.rb_datasx1.AutoSize = true;
            this.rb_datasx1.Checked = true;
            this.rb_datasx1.Location = new System.Drawing.Point(24, 126);
            this.rb_datasx1.Margin = new System.Windows.Forms.Padding(4);
            this.rb_datasx1.Name = "rb_datasx1";
            this.rb_datasx1.Size = new System.Drawing.Size(87, 22);
            this.rb_datasx1.TabIndex = 8;
            this.rb_datasx1.TabStop = true;
            this.rb_datasx1.Text = "顺序数";
            this.rb_datasx1.UseVisualStyleBackColor = true;
            // 
            // rb_datasx2
            // 
            this.rb_datasx2.AutoSize = true;
            this.rb_datasx2.Location = new System.Drawing.Point(136, 126);
            this.rb_datasx2.Margin = new System.Windows.Forms.Padding(4);
            this.rb_datasx2.Name = "rb_datasx2";
            this.rb_datasx2.Size = new System.Drawing.Size(87, 22);
            this.rb_datasx2.TabIndex = 9;
            this.rb_datasx2.Text = "随机数";
            this.rb_datasx2.UseVisualStyleBackColor = true;
            // 
            // bt_Fib
            // 
            this.bt_Fib.Location = new System.Drawing.Point(20, 212);
            this.bt_Fib.Margin = new System.Windows.Forms.Padding(4);
            this.bt_Fib.Name = "bt_Fib";
            this.bt_Fib.Size = new System.Drawing.Size(98, 45);
            this.bt_Fib.TabIndex = 10;
            this.bt_Fib.Text = "斐波那契";
            this.bt_Fib.UseVisualStyleBackColor = true;
            this.bt_Fib.Click += new System.EventHandler(this.bt_Fib_Click);
            // 
            // bt_ss
            // 
            this.bt_ss.Location = new System.Drawing.Point(128, 210);
            this.bt_ss.Margin = new System.Windows.Forms.Padding(4);
            this.bt_ss.Name = "bt_ss";
            this.bt_ss.Size = new System.Drawing.Size(98, 45);
            this.bt_ss.TabIndex = 10;
            this.bt_ss.Text = "素数";
            this.bt_ss.UseVisualStyleBackColor = true;
            this.bt_ss.Click += new System.EventHandler(this.bt_ss_Click);
            // 
            // bt_create
            // 
            this.bt_create.Location = new System.Drawing.Point(20, 159);
            this.bt_create.Margin = new System.Windows.Forms.Padding(4);
            this.bt_create.Name = "bt_create";
            this.bt_create.Size = new System.Drawing.Size(98, 45);
            this.bt_create.TabIndex = 0;
            this.bt_create.Text = "初始化";
            this.bt_create.UseVisualStyleBackColor = true;
            this.bt_create.Click += new System.EventHandler(this.bt_create_Click);
            // 
            // Form_SeqList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 645);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form_SeqList";
            this.Text = "顺序表操作演示";
            this.Load += new System.EventHandler(this.Form_SeqList_Load);
            this.panel6.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bt_close;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rb_datano2;
        private System.Windows.Forms.RadioButton rb_datano3;
        private System.Windows.Forms.RadioButton rb_datano1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_modify_dt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_modify_no;
        private System.Windows.Forms.Button bt_insert;
        private System.Windows.Forms.Button bt_update;
        private System.Windows.Forms.Button bt_delete;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bt_ss;
        private System.Windows.Forms.Button bt_Fib;
        private System.Windows.Forms.RadioButton rb_datasx2;
        private System.Windows.Forms.RadioButton rb_datasx1;
        private System.Windows.Forms.TextBox tb_maxcount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_scount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_create;
        private System.Windows.Forms.Button bt_empty;
        private System.Windows.Forms.Panel panel2;
    }
}