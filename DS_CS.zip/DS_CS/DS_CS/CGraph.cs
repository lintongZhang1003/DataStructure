﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Drawing;
using System.Windows.Forms;

namespace DS_CS
{
    public struct vtype//存放点的结构
    {
        public int no;//点的序号
        public string name;//存放点图的名字
        public int x, y;//点的坐标
        public vtype(int no, int x, int y, string name)
		{
		    this.no=no;
            this.x=x;
			this.y=y;
			this.name=name;
		}
    }
    public struct EL
    { 
        //int e;         //最早开始时间
        // int l;         //最迟开始时间
    }
    public class CGraph
    {
    
		protected int directed;//图的类型(0:无向图,1:有向图)
		protected int vertexno;//顶点个数
		protected string fname;//创建图的文件名
		protected int currentID;//当前点的序号
		protected int[] visited;//存放某种顺序遍历时的顶点序列,visited[0]为遍历序列个数
		protected int[] treeparent;//存放生成树边的数组(存放双亲的顶点号)
		protected EL[] vertexc;//图的关键路径的顶点存放的e,l值
		protected EL[] edgec;//图的关键路径的边存放的e,l值
//---------------------------------------------------------------------------------------------------
        public CGraph()
        { vertexno = 0; }
        public CGraph(int ver)
        {vertexno=ver;}
		public bool IsDirected()
		{ return directed==1; }
		public int Getvertexno()//取顶点个数
		{ return vertexno; }
		public int GetCurrentID()//取当前顶点的序号
		{ return currentID; }
		public void SetCurrentID(int k)//设置当前顶点的序号
		{ currentID=k; }
		public int Visited(int vi)
		{ return visited[vi]; }
        //public int TreeParent(int vi)//取顶点vi在生成树中双亲的顶点号
        //{ return treeparent[vi]; }
        //public EL Vertexc(int vi)//顶点vi的e,l值
        //{ return vertexc[vi]; }
        //public EL Edgec(int vi, int vj)//取边<vi,vj>的e,l值
        //{ return edgec[(vi-1)*vertexno+(vj-1)]; }
        public void GetArrow(int x1,int y1,int x2,int y2,int R,int d,Point[] arrow)
        //求箭头的坐标,点(x1,y1)到(x2,y2)的有向边,R:点圈的半径,d:箭头半长
        //arrow:返回箭头三角形的三个顶点
        {

	        double k;//直线的斜率
	        int x0=0,y0=0;//箭头的对边中点
	        int b=3;
            //arrow = new Point[3];
            for (int i = 0; i < 3; i++)
            {
                arrow[0].X = 0;
                arrow[0].Y = 0;
            }

	        if(x1!=x2)
	        {
	            k=1.0*(y2-y1)/(x2-x1);
		        if(x1<x2)
		        {
                    arrow[0].X = (int)(Math.Round(x2 - Math.Sqrt(1 + k * k), 0));//直线(x1,y1)(x2,y2)与圆(x2,y2,R)的交点
                    arrow[0].Y = (int)(Math.Round(y2 - k * R / Math.Sqrt(1 + k * k), 0));
                    x0 = (int)(Math.Round(x2 - (R + b * d)*1.0 / Math.Sqrt(1 + k * k), 0));//直线(x1,y1)(x2,y2)与圆(x2,y2,R+2*d)的交点
                    y0 = (int)(Math.Round(y2 - k * (R + b * d) / Math.Sqrt(1 + k * k), 0));
		        }
		        else //x1>x2
		        {
                    arrow[0].X = (int)(Math.Round(x2 + R*1.0 / Math.Sqrt(1 + k * k) , 0));
                    arrow[0].Y = (int)(Math.Round(y2 + k * R / Math.Sqrt(1 + k * k) , 0));
                    x0 = (int)(Math.Round(x2 + (R + b * d)*1.0 / Math.Sqrt(1 + k * k) , 0));
                    y0 = (int)(Math.Round(y2 + k * (R + b * d) / Math.Sqrt(1 + k * k) , 0));
		        }
                arrow[1].X = (int)(Math.Round(x0 - k * d / Math.Sqrt(1 + k * k) , 0));
                arrow[1].Y = (int)(Math.Round(y0 + d *1.0 / Math.Sqrt(1 + k * k) , 0));
                arrow[2].X = (int)(Math.Round(x0 + k * d / Math.Sqrt(1 + k * k) , 0));
                arrow[2].Y = (int)(Math.Round(y0 - d *1.0/ Math.Sqrt(1 + k * k), 0));
	        }
	        else//x1==x2
	        {
		        if(y1<y2)
		        {
                    arrow[0].X=x1; 
			        arrow[0].Y=y2-R;
			        x0=x1;
			        y0=y2-(R+b*d);
		        }
		        else if(y1>y2)
		        {
                    arrow[0].X=x1; 
			        arrow[0].Y=y2+R;
			        x0=x1;
			        y0=y2+(R+b*d);
		        }
		        arrow[1].X=x0-d;
		        arrow[1].Y=y0;
		        arrow[2].X=x0+d;
		        arrow[2].Y=y0;
	        }
        }



    }
        
        ////////////////////////////////////////////////////////////
    public class CGraphM : CGraph
    {//用邻接矩阵表示的图
        private vtype[] vertex;//存放顶点的数组
        private int[,] edge;//存放边的矩阵

        public CGraphM()
        {
            directed = 0;
            vertexno = 0;
            fname = "";
            currentID = 0;
            vertex = null;
            edge = null;
            treeparent = null;
            visited = null;
            vertexc = null;
            edgec = null;
        }
        public int GetIntData(string strdata, int k, out int outk)
        {
            int len = strdata.Length;
            int ks = k, data;
            string str;
            while ((ks < len) && ((strdata[ks] < '0') || (strdata[ks] > '9')))
                ks++;
            str = "";
            while ((ks < len) && ((strdata[ks] >= '0') && (strdata[ks] <= '9')))
                str = str + strdata[ks++];
            if (str != "")
                data = Convert.ToInt32(str);
            else
                data = 0;
            outk = ks;
            return (data);
        }
        public string GetStrData(string strdata, int k, out int outk)
        {
            int len = strdata.Length;
            int ks = k;
            string str;
            while ((ks < len) && ((strdata[ks] == '\n') || (strdata[ks] == '\r') || (strdata[ks] == ' ')))
                ks++;
            str = "";
            while ((ks < len) && ((strdata[ks] != '\n') || (strdata[ks] != '\r') && (strdata[ks] != ' ')))
                str = str + strdata[ks++];
            outk = ks;
            return (str);
        }
        public void Read(string strgraphdata)
        {
            int i, j, know;
            know = 0;
            if (strgraphdata == "")
            {
                vertexno = 0;
                return;
            }
            directed = GetIntData(strgraphdata, know, out know);
            vertexno = GetIntData(strgraphdata, know, out know);
            vertex = new vtype[vertexno + 1];
            edge = new int[(vertexno + 1), (vertexno + 1)];
            visited = new int[vertexno + 1];
            treeparent = new int[vertexno + 1];
            vertexc = new EL[vertexno + 1];
            edgec = new EL[vertexno * vertexno];
            for (i = 1; i <= vertexno; i++)
            {
                vertex[i].no = GetIntData(strgraphdata, know, out know);
                vertex[i].x = GetIntData(strgraphdata, know, out know);
                vertex[i].y = GetIntData(strgraphdata, know, out know);
                //TreeParent(i) = 0;
                //Vertexc(i).e = Vertexc(i).l = -1;
            }
            for (i = 1; i <= vertexno; i++)
            {
                for (j = 1; j <= vertexno; j++)
                {
                    edge[i, j] = GetIntData(strgraphdata, know, out know);
                    //Edgec[i, j].e = Edgec(i, j).l = -1;
                }
            }
            currentID = 1;
            visited[0] = 0;//遍历序列个数为0
        }
        public string Write_graph_matrix()
        {
            string graph_matrix = "";
            for (int i = 1; i <= vertexno; i++)
            {
                for (int j = 1; j <= vertexno; j++)
                {
                    graph_matrix = graph_matrix + edge[i, j] +" ";
                }
                graph_matrix = graph_matrix + "\r\n";
            }
            return (graph_matrix);
        }
        //public VType Vertex(int vi)//顶点vi的值
        //{ return vertex[vi]; }
        //public EType Edge(int vi,int vj)//取边<vi,vj>的值
        //{ return edge[(vi-1)*vertexno+(vj-1)]; }
        //public int GetFirstV(int vi);//取顶点vi的第一个邻接点
        //public int GetNextV(int vi,int vk)//取顶点vi的从顶点vk后的第一个邻接点
        //public void print(string strout)
        public void DrawMaze(PictureBox pb_graph)
        {
            Graphics myg;
            int xmin = 0;
            int ymin = 0;
            int xmax, ymax;
            int n = vertexno;//定点数
            if (n == 0)
                return;


            myg = pb_graph.CreateGraphics();
            xmax = pb_graph.Width;
            ymax = pb_graph.Height;



            Color bkColor0, bkColor1, ArrowColor, TreeColor;
            Brush bkBrush0, bkBrush1, ArrowBrush;
            Brush bkbrush = new SolidBrush(Color.White);//背景色
            bkColor0 = Color.FromArgb(255, 255, 255, 0);//节点颜色
            bkBrush0 = new SolidBrush(bkColor0);
            bkColor1 = Color.FromArgb(255, 125, 125, 125);//当前节点颜色
            bkBrush1 = new SolidBrush(bkColor1);
            ArrowColor = Color.FromArgb(255, 255, 50, 50);//箭头颜色
            ArrowBrush = new SolidBrush(ArrowColor);
            TreeColor = Color.FromArgb(255, 255, 0, 255);//生成树的边的颜色

            Pen Pen0 = new Pen(Color.FromArgb(255, 255, 0, 255), 0);//点的圆圈
            Pen PenLine = new Pen(ArrowColor, 1);//边
            Pen Pentree = new Pen(TreeColor, 5);//生成树的边
            //画背景
            myg.FillRectangle(bkbrush, xmin, ymin, xmax - xmin, ymax - ymin);

            string str;
            int i, j, x1, y1, x2, y2;
            int R = 12;//点圈的半径
            int d1 = 6;//普通线的箭头长
            Point[] arrow = new Point[3];

            if (directed == 1)//有向图
            {
                for (i = 1; i <= n; i++)//画线
                {
                    for (j = i + 1; j <= n; j++)
                    {
                        x1 = vertex[i].x;
                        y1 = vertex[i].y;
                        x2 = vertex[j].x;
                        y2 = vertex[j].y;
                        if ((edge[i, j] != 0) && (edge[j, i] == 0))
                        {//只有小点到大点的边
                            str = "" + edge[i, j];
                            GetArrow(x1, y1, x2, y2, R, d1, arrow);
                            myg.FillPolygon(ArrowBrush, arrow);
                        }
                        else if ((edge[i, j] == 0) && (edge[j, i] != 0))
                        {//只有大点到小点的边
                            str = "" + edge[j, i];
                            GetArrow(x2, y2, x1, y1, R, d1, arrow);
                            myg.FillPolygon(ArrowBrush, arrow);
                        }
                        else if ((edge[i, j] != 0) && (edge[j, i] != 0))
                        {//有双向边
                            str = "" + edge[i, j];
                            GetArrow(x1, y1, x2, y2, R, d1, arrow);
                            GetArrow(x2, y2, x1, y1, R, d1, arrow);
                            myg.FillPolygon(ArrowBrush, arrow);
                        }
                        else
                        {//无边
                            continue;
                        }
                        x1 = vertex[i].x;
                        y1 = vertex[i].y;
                        x2 = vertex[j].x;
                        y2 = vertex[j].y;
                        myg.DrawLine(PenLine, x1, y1, x2, y2);
                    }
                }
            }
            else//无向图
            {
                for (i = 1; i <= n; i++)//画线
                {
                    for (j = 1; j <= n; j++)
                    {
                        if ((edge[i, j] != 0) && (edge[j, i] != 0))
                        {
                            x1 = vertex[i].x;
                            y1 = vertex[i].y;
                            x2 = vertex[j].x;
                            y2 = vertex[j].y;
                            myg.DrawLine(PenLine, x1, y1, x2, y2);
                            //str.Format("%2d", m_graph->Edge(i, j));
                        }
                    }
                }
            }

            for (i = 1; i <= n; i++)//画点
            {
                //if (i == GetCurrentID())
                //{
                //    pDC->SelectObject(&BKBrush1);
                //    pDC->SetBkColor(BKColor1);
                //    pDC->SetTextColor(RGB(0, 0, 0));
                //}
                //else
                //{
                //    pDC->SelectObject(&BKBrush0);
                //    pDC->SetBkColor(BKColor0);
                //    pDC->SetTextColor(RGB(255, 255, 255));
                //}
                x1 = vertex[i].x;
                y1 = vertex[i].y;
                //myg.FillEllipse(bkBrush0, x1 - R, y1 - R, 2 * R, 2 * R);
                //str.Format("%2d", m_graph->Vertex(i).no);//点的序号
                //pDC->TextOut(x1 - 8, y1 - 8, str);
            }
        }
    }
}
