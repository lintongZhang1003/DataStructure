﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DS_CS
{
    public partial class Form_SeqList : Form
    {
        private CSeqList<int> m_seqlist;
        public Form_SeqList()
        {
            InitializeComponent();
        }

        private void Form_SeqList_Load(object sender, EventArgs e)
        {
            //m_seqlist = new CSeqList<int>();
        }

        private void bt_create_Click(object sender, EventArgs e)
        {
            int m_createmaxno = Convert.ToInt16(tb_maxcount.Text);
            int m_createno = Convert.ToInt16(tb_scount.Text);
            int[] dt = new int[m_createno];
            Random ran = new Random();
            for (int i = 0; i < m_createno; i++)
            {
                if (rb_datasx1.Checked == true)
                    dt[i] = i+1;
                else
                    dt[i] = ran.Next(m_createno)+1;
            }
            if (m_createno <= m_createmaxno && m_createno >= 1)
            {
                m_seqlist = new CSeqList<int>(m_createmaxno, dt, m_createno);
                string str = m_seqlist.MyPrint();
                richTextBox1.Text = str;
            }
            else
            {
                MessageBox.Show("对不起了您，顺序表演示节点个数为：1～"+m_createmaxno+" !");
            }
        }

        private void bt_empty_Click(object sender, EventArgs e)
        {
            m_seqlist.MakeEmpty();
            string str = m_seqlist.MyPrint();
            richTextBox1.Text = str;
        }

        private void bt_delete_Click(object sender, EventArgs e)
        {
            int k;
            if (rb_datano1.Checked)
                k = 1;
            else if (rb_datano2.Checked)
                k = Convert.ToInt16(tb_modify_no.Text);
            else
                k = m_seqlist.DataSize;
            if (m_seqlist.Delete(k))
            {
                string str = m_seqlist.MyPrint();
                richTextBox1.Text = str;
            }
            else
            {
                MessageBox.Show("对不起了您，顺序表删除的节点位置错误 !");
            }
        }

        private void bt_update_Click(object sender, EventArgs e)
        {
            int k;
            if (rb_datano1.Checked)
                k = 1;
            else if (rb_datano2.Checked)
                k = Convert.ToInt16(tb_modify_no.Text);
            else
                k = m_seqlist.DataSize;
            int dt = Convert.ToInt16(tb_modify_dt.Text);
            if (m_seqlist.Update(k,dt))
            {
                string str = m_seqlist.MyPrint();
                richTextBox1.Text = str;
            }
            else
            {
                MessageBox.Show("对不起了您，顺序表修改的节点位置错误或者可用空间已满 !");
            }
        }

        private void bt_insert_Click(object sender, EventArgs e)
        {
            int k;
            if (rb_datano1.Checked)
                k = 1;
            else if (rb_datano2.Checked)
                k = Convert.ToInt16(tb_modify_no.Text);
            else
                k = m_seqlist.DataSize+1;
            int dt = Convert.ToInt16(tb_modify_dt.Text);
            if (m_seqlist.Inset(k, dt))
            {
                string str = m_seqlist.MyPrint();
                richTextBox1.Text = str;
            }
            else
            {
                MessageBox.Show("对不起了您，顺序表插入的节点位置错误 !");
            }
        }

        private void bt_Fib_Click(object sender, EventArgs e)
        {
            int m_createmaxno = Convert.ToInt16(tb_maxcount.Text);
            int m_createno = Convert.ToInt16(tb_scount.Text);
            int[] dt = new int[m_createno];
            dt[0] = 1; dt[1] = 1;
            for (int i = 2; i < m_createno; i++)
            {
                dt[i] = dt[i - 1] + dt[i - 2];
            }
            if (m_createno <= m_createmaxno && m_createno >= 1)
            {
                m_seqlist = new CSeqList<int>(m_createmaxno, dt, m_createno);
                string str = m_seqlist.MyPrint();
                richTextBox1.Text = str;
            }
            else
            {
                MessageBox.Show("对不起了您，顺序表演示节点个数为：1～" + m_createmaxno + " !");
            }
        }
        private bool ss(int k)
        {
            for (int i = 2; i <= k / 2; i++)
            {
                if (k % i == 0)
                    return false;//不是素数
            }
            return true;//是素数
        }

        private void bt_ss_Click(object sender, EventArgs e)
        {
            int m_createmaxno = Convert.ToInt16(tb_maxcount.Text);
            int m_createno = Convert.ToInt16(tb_scount.Text);
            int[] dt = new int[m_createno];
            int k = 0;
            int i = 2;
            while (k < m_createno )
            {
                if (ss(i))
                {
                    dt[k++] = i;
                }
                i++;
            }
            if (m_createno <= m_createmaxno && m_createno >= 1)
            {
                m_seqlist = new CSeqList<int>(m_createmaxno, dt, m_createno);
                string str = m_seqlist.MyPrint();
                richTextBox1.Text = str;
            }
            else
            {
                MessageBox.Show("对不起了您，顺序表演示节点个数为：1～" + m_createmaxno + " !");
            }

        }

        private void bt_close_Click(object sender, EventArgs e)
        {
           // this.Close();
        }
    }
}
