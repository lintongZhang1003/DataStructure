﻿namespace DS_CS
{
    partial class Form_Matrix
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Matrix));
            this.axMSFlexGrid1 = new AxMSFlexGridLib.AxMSFlexGrid();
            this.axMSFlexGrid2 = new AxMSFlexGridLib.AxMSFlexGrid();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bt_mul = new System.Windows.Forms.Button();
            this.text_rm = new System.Windows.Forms.TextBox();
            this.text_det = new System.Windows.Forms.TextBox();
            this.bt_minus = new System.Windows.Forms.Button();
            this.bt_mat_contra = new System.Windows.Forms.Button();
            this.bt_mat_unite = new System.Windows.Forms.Button();
            this.bt_rowt = new System.Windows.Forms.Button();
            this.bt_det = new System.Windows.Forms.Button();
            this.bt_plus = new System.Windows.Forms.Button();
            this.axMSFlexGrid0 = new AxMSFlexGridLib.AxMSFlexGrid();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rb_mat2 = new System.Windows.Forms.RadioButton();
            this.rb_mat1 = new System.Windows.Forms.RadioButton();
            this.bt_Resulttomatrix = new System.Windows.Forms.Button();
            this.bt_Matrixtoedit = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.text_cols = new System.Windows.Forms.TextBox();
            this.text_rows = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_creatematrix = new System.Windows.Forms.Button();
            this.bt_creatematrix1 = new System.Windows.Forms.Button();
            this.bt_Solve = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rb_nhle = new System.Windows.Forms.RadioButton();
            this.rb_hle = new System.Windows.Forms.RadioButton();
            this.bt_defaultmatrix = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.axMSFlexGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axMSFlexGrid2)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axMSFlexGrid0)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // axMSFlexGrid1
            // 
            this.axMSFlexGrid1.Location = new System.Drawing.Point(12, 12);
            this.axMSFlexGrid1.Name = "axMSFlexGrid1";
            this.axMSFlexGrid1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMSFlexGrid1.OcxState")));
            this.axMSFlexGrid1.Size = new System.Drawing.Size(331, 159);
            this.axMSFlexGrid1.TabIndex = 2;
            // 
            // axMSFlexGrid2
            // 
            this.axMSFlexGrid2.Location = new System.Drawing.Point(459, 12);
            this.axMSFlexGrid2.Name = "axMSFlexGrid2";
            this.axMSFlexGrid2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMSFlexGrid2.OcxState")));
            this.axMSFlexGrid2.Size = new System.Drawing.Size(331, 159);
            this.axMSFlexGrid2.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bt_mul);
            this.groupBox1.Controls.Add(this.text_rm);
            this.groupBox1.Controls.Add(this.text_det);
            this.groupBox1.Controls.Add(this.bt_minus);
            this.groupBox1.Controls.Add(this.bt_mat_contra);
            this.groupBox1.Controls.Add(this.bt_mat_unite);
            this.groupBox1.Controls.Add(this.bt_rowt);
            this.groupBox1.Controls.Add(this.bt_det);
            this.groupBox1.Controls.Add(this.bt_plus);
            this.groupBox1.Location = new System.Drawing.Point(351, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(99, 158);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "运算";
            // 
            // bt_mul
            // 
            this.bt_mul.Location = new System.Drawing.Point(68, 20);
            this.bt_mul.Name = "bt_mul";
            this.bt_mul.Size = new System.Drawing.Size(25, 23);
            this.bt_mul.TabIndex = 2;
            this.bt_mul.Text = "*";
            this.bt_mul.UseVisualStyleBackColor = true;
            this.bt_mul.Click += new System.EventHandler(this.bt_mul_Click);
            // 
            // text_rm
            // 
            this.text_rm.Location = new System.Drawing.Point(61, 51);
            this.text_rm.Name = "text_rm";
            this.text_rm.Size = new System.Drawing.Size(30, 21);
            this.text_rm.TabIndex = 2;
            this.text_rm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // text_det
            // 
            this.text_det.Location = new System.Drawing.Point(37, 78);
            this.text_det.Name = "text_det";
            this.text_det.Size = new System.Drawing.Size(55, 21);
            this.text_det.TabIndex = 2;
            this.text_det.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bt_minus
            // 
            this.bt_minus.Location = new System.Drawing.Point(37, 20);
            this.bt_minus.Name = "bt_minus";
            this.bt_minus.Size = new System.Drawing.Size(25, 23);
            this.bt_minus.TabIndex = 1;
            this.bt_minus.Text = "-";
            this.bt_minus.UseVisualStyleBackColor = true;
            this.bt_minus.Click += new System.EventHandler(this.bt_minus_Click);
            // 
            // bt_mat_contra
            // 
            this.bt_mat_contra.Location = new System.Drawing.Point(6, 129);
            this.bt_mat_contra.Name = "bt_mat_contra";
            this.bt_mat_contra.Size = new System.Drawing.Size(87, 23);
            this.bt_mat_contra.TabIndex = 0;
            this.bt_mat_contra.Text = "方阵求逆";
            this.bt_mat_contra.UseVisualStyleBackColor = true;
            this.bt_mat_contra.Click += new System.EventHandler(this.bt_mat_contra_Click);
            // 
            // bt_mat_unite
            // 
            this.bt_mat_unite.Location = new System.Drawing.Point(6, 105);
            this.bt_mat_unite.Name = "bt_mat_unite";
            this.bt_mat_unite.Size = new System.Drawing.Size(87, 23);
            this.bt_mat_unite.TabIndex = 0;
            this.bt_mat_unite.Text = "方阵合并";
            this.bt_mat_unite.UseVisualStyleBackColor = true;
            this.bt_mat_unite.Click += new System.EventHandler(this.bt_mat_unite_Click);
            // 
            // bt_rowt
            // 
            this.bt_rowt.Location = new System.Drawing.Point(6, 49);
            this.bt_rowt.Name = "bt_rowt";
            this.bt_rowt.Size = new System.Drawing.Size(51, 23);
            this.bt_rowt.TabIndex = 0;
            this.bt_rowt.Text = "行标准";
            this.bt_rowt.UseVisualStyleBackColor = true;
            this.bt_rowt.Click += new System.EventHandler(this.bt_rowt_Click);
            // 
            // bt_det
            // 
            this.bt_det.Location = new System.Drawing.Point(6, 78);
            this.bt_det.Name = "bt_det";
            this.bt_det.Size = new System.Drawing.Size(25, 23);
            this.bt_det.TabIndex = 0;
            this.bt_det.Text = "||";
            this.bt_det.UseVisualStyleBackColor = true;
            this.bt_det.Click += new System.EventHandler(this.bt_det_Click);
            // 
            // bt_plus
            // 
            this.bt_plus.Location = new System.Drawing.Point(6, 20);
            this.bt_plus.Name = "bt_plus";
            this.bt_plus.Size = new System.Drawing.Size(25, 23);
            this.bt_plus.TabIndex = 0;
            this.bt_plus.Text = "+";
            this.bt_plus.UseVisualStyleBackColor = true;
            this.bt_plus.Click += new System.EventHandler(this.bt_plus_Click);
            // 
            // axMSFlexGrid0
            // 
            this.axMSFlexGrid0.Location = new System.Drawing.Point(12, 264);
            this.axMSFlexGrid0.Name = "axMSFlexGrid0";
            this.axMSFlexGrid0.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMSFlexGrid0.OcxState")));
            this.axMSFlexGrid0.Size = new System.Drawing.Size(331, 199);
            this.axMSFlexGrid0.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.rb_mat2);
            this.panel1.Controls.Add(this.rb_mat1);
            this.panel1.Location = new System.Drawing.Point(349, 172);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(100, 51);
            this.panel1.TabIndex = 4;
            // 
            // rb_mat2
            // 
            this.rb_mat2.AutoSize = true;
            this.rb_mat2.Location = new System.Drawing.Point(24, 29);
            this.rb_mat2.Name = "rb_mat2";
            this.rb_mat2.Size = new System.Drawing.Size(53, 16);
            this.rb_mat2.TabIndex = 0;
            this.rb_mat2.Text = "矩阵2";
            this.rb_mat2.UseVisualStyleBackColor = true;
            // 
            // rb_mat1
            // 
            this.rb_mat1.AutoSize = true;
            this.rb_mat1.Checked = true;
            this.rb_mat1.Location = new System.Drawing.Point(24, 7);
            this.rb_mat1.Name = "rb_mat1";
            this.rb_mat1.Size = new System.Drawing.Size(53, 16);
            this.rb_mat1.TabIndex = 0;
            this.rb_mat1.TabStop = true;
            this.rb_mat1.Text = "矩阵1";
            this.rb_mat1.UseVisualStyleBackColor = true;
            // 
            // bt_Resulttomatrix
            // 
            this.bt_Resulttomatrix.Location = new System.Drawing.Point(12, 182);
            this.bt_Resulttomatrix.Name = "bt_Resulttomatrix";
            this.bt_Resulttomatrix.Size = new System.Drawing.Size(155, 35);
            this.bt_Resulttomatrix.TabIndex = 5;
            this.bt_Resulttomatrix.Text = "将运算结果传给矩阵";
            this.bt_Resulttomatrix.UseVisualStyleBackColor = true;
            this.bt_Resulttomatrix.Click += new System.EventHandler(this.bt_Resulttomatrix_Click);
            // 
            // bt_Matrixtoedit
            // 
            this.bt_Matrixtoedit.Location = new System.Drawing.Point(173, 181);
            this.bt_Matrixtoedit.Name = "bt_Matrixtoedit";
            this.bt_Matrixtoedit.Size = new System.Drawing.Size(155, 35);
            this.bt_Matrixtoedit.TabIndex = 5;
            this.bt_Matrixtoedit.Text = "将矩阵传给编辑框";
            this.bt_Matrixtoedit.UseVisualStyleBackColor = true;
            this.bt_Matrixtoedit.Click += new System.EventHandler(this.bt_Matrixtoedit_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(351, 247);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(438, 216);
            this.richTextBox1.TabIndex = 6;
            this.richTextBox1.Text = "";
            this.richTextBox1.WordWrap = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.text_cols);
            this.groupBox2.Controls.Add(this.text_rows);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(462, 173);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(243, 49);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "输入矩阵的行列数";
            // 
            // text_cols
            // 
            this.text_cols.Location = new System.Drawing.Point(171, 21);
            this.text_cols.Name = "text_cols";
            this.text_cols.Size = new System.Drawing.Size(55, 21);
            this.text_cols.TabIndex = 3;
            this.text_cols.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // text_rows
            // 
            this.text_rows.Location = new System.Drawing.Point(64, 21);
            this.text_rows.Name = "text_rows";
            this.text_rows.Size = new System.Drawing.Size(55, 21);
            this.text_rows.TabIndex = 2;
            this.text_rows.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(136, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "列数";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "行数";
            // 
            // bt_creatematrix
            // 
            this.bt_creatematrix.Location = new System.Drawing.Point(713, 197);
            this.bt_creatematrix.Name = "bt_creatematrix";
            this.bt_creatematrix.Size = new System.Drawing.Size(72, 23);
            this.bt_creatematrix.TabIndex = 5;
            this.bt_creatematrix.Text = "生成矩阵";
            this.bt_creatematrix.UseVisualStyleBackColor = true;
            this.bt_creatematrix.Click += new System.EventHandler(this.bt_creatematrix_Click);
            // 
            // bt_creatematrix1
            // 
            this.bt_creatematrix1.Location = new System.Drawing.Point(713, 221);
            this.bt_creatematrix1.Name = "bt_creatematrix1";
            this.bt_creatematrix1.Size = new System.Drawing.Size(72, 23);
            this.bt_creatematrix1.TabIndex = 5;
            this.bt_creatematrix1.Text = "单位矩阵";
            this.bt_creatematrix1.UseVisualStyleBackColor = true;
            this.bt_creatematrix1.Click += new System.EventHandler(this.bt_creatematrix1_Click);
            // 
            // bt_Solve
            // 
            this.bt_Solve.Location = new System.Drawing.Point(12, 223);
            this.bt_Solve.Name = "bt_Solve";
            this.bt_Solve.Size = new System.Drawing.Size(155, 35);
            this.bt_Solve.TabIndex = 5;
            this.bt_Solve.Text = "解线性方程组";
            this.bt_Solve.UseVisualStyleBackColor = true;
            this.bt_Solve.Click += new System.EventHandler(this.bt_Solve_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.rb_nhle);
            this.panel2.Controls.Add(this.rb_hle);
            this.panel2.Location = new System.Drawing.Point(173, 222);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(155, 36);
            this.panel2.TabIndex = 8;
            // 
            // rb_nhle
            // 
            this.rb_nhle.AutoSize = true;
            this.rb_nhle.Location = new System.Drawing.Point(79, 8);
            this.rb_nhle.Name = "rb_nhle";
            this.rb_nhle.Size = new System.Drawing.Size(59, 16);
            this.rb_nhle.TabIndex = 0;
            this.rb_nhle.Text = "非齐次";
            this.rb_nhle.UseVisualStyleBackColor = true;
            // 
            // rb_hle
            // 
            this.rb_hle.AutoSize = true;
            this.rb_hle.Checked = true;
            this.rb_hle.Location = new System.Drawing.Point(20, 8);
            this.rb_hle.Name = "rb_hle";
            this.rb_hle.Size = new System.Drawing.Size(47, 16);
            this.rb_hle.TabIndex = 0;
            this.rb_hle.TabStop = true;
            this.rb_hle.Text = "齐次";
            this.rb_hle.UseVisualStyleBackColor = true;
            // 
            // bt_defaultmatrix
            // 
            this.bt_defaultmatrix.Location = new System.Drawing.Point(713, 173);
            this.bt_defaultmatrix.Name = "bt_defaultmatrix";
            this.bt_defaultmatrix.Size = new System.Drawing.Size(72, 23);
            this.bt_defaultmatrix.TabIndex = 9;
            this.bt_defaultmatrix.Text = "默认矩阵";
            this.bt_defaultmatrix.UseVisualStyleBackColor = true;
            this.bt_defaultmatrix.Click += new System.EventHandler(this.bt_defaultmatrix_Click);
            // 
            // Form_Matrix
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 485);
            this.Controls.Add(this.bt_defaultmatrix);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.bt_creatematrix1);
            this.Controls.Add(this.bt_creatematrix);
            this.Controls.Add(this.bt_Matrixtoedit);
            this.Controls.Add(this.bt_Solve);
            this.Controls.Add(this.bt_Resulttomatrix);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.axMSFlexGrid2);
            this.Controls.Add(this.axMSFlexGrid0);
            this.Controls.Add(this.axMSFlexGrid1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form_Matrix";
            this.Text = "矩阵运算";
            this.Load += new System.EventHandler(this.Form_Matrix_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axMSFlexGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axMSFlexGrid2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axMSFlexGrid0)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private AxMSFlexGridLib.AxMSFlexGrid axMSFlexGrid1;
        private AxMSFlexGridLib.AxMSFlexGrid axMSFlexGrid2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bt_mul;
        private System.Windows.Forms.Button bt_minus;
        private System.Windows.Forms.Button bt_plus;
        private AxMSFlexGridLib.AxMSFlexGrid axMSFlexGrid0;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rb_mat2;
        private System.Windows.Forms.RadioButton rb_mat1;
        private System.Windows.Forms.Button bt_Resulttomatrix;
        private System.Windows.Forms.Button bt_Matrixtoedit;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox text_cols;
        private System.Windows.Forms.TextBox text_rows;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_creatematrix;
        private System.Windows.Forms.Button bt_rowt;
        private System.Windows.Forms.TextBox text_det;
        private System.Windows.Forms.Button bt_det;
        private System.Windows.Forms.Button bt_creatematrix1;
        private System.Windows.Forms.Button bt_mat_unite;
        private System.Windows.Forms.Button bt_mat_contra;
        private System.Windows.Forms.TextBox text_rm;
        private System.Windows.Forms.Button bt_Solve;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rb_nhle;
        private System.Windows.Forms.RadioButton rb_hle;
        private System.Windows.Forms.Button bt_defaultmatrix;
    }
}