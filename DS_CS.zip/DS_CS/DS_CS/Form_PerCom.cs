﻿using System;  
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DS_CS
{
    public partial class Form_PerCom : Form
    {
        int[] m_percom_temp;
        int m_count;
        string m_strout;
        int m_rs1, m_rs2;
        int m_bjrssum;
        int m_bjs;
        int[] m_bjrs; 
        public string Getstr_percom_temp(int k)
        {
            m_count++;
            if (progressBar1.Maximum > 0)
                progressBar1.Value = m_count;
            string strout = " (  " + m_count + "   )\t【 ";
            for (int i = 1; i <= k; i++)
            {
                if (i < k)
                    strout += m_percom_temp[i] + ", ";
                else
                    strout += m_percom_temp[i];
            }
            strout += " 】\n";
            return strout;
        }
        public string Getstr_percom_tempbj(int k)
        {
            m_count++;
            if (progressBar1.Maximum > 0)
                progressBar1.Value = m_count;
            string strout = " (  " + m_count + "   )\t【 ";
            int sumk = 0;
            for (int i = 1; i <= k; i++)
            {
                sumk += Convert.ToInt16(m_bjrs[m_percom_temp[i]]);
                if (i < k)
                    strout += m_percom_temp[i] + ", ";
                else
                    strout += m_percom_temp[i];
            }
            strout += " 】（" + sumk + "," + (m_bjrssum - sumk) + "）\n";

            return strout;
        }
        public void Fun_Permute_Recursion(int n, int m, int k)
        {
            for (int i = 1; i <= n; i++)
            {
                bool tag = false;
                for (int j = 1; j <= k - 1; j++)
                {
                    if (i == m_percom_temp[j])
                    {
                        tag = true;
                        break;
                    }
                }
                if (tag == false)
                {
                    m_percom_temp[k] = i;
                    if (k < m)
                        Fun_Permute_Recursion(n, m, k + 1);
                    else
                    {
                        m_strout += Getstr_percom_temp(m);
                    }
                }
            }
        }
        
        public void Fun_Powerset_Recursion(int n, int k)
        {
            for (int i = m_percom_temp[k - 1] + 1; i <= n; i++)
            {
                m_percom_temp[k] = i;
                m_strout += Getstr_percom_temp(k);
                if (k < n)
                    Fun_Powerset_Recursion(n, k + 1);
            }
        }
        public void Fun_Combination_Recursion(int n, int m, int k)
        {
            for (int i = m_percom_temp[k - 1] + 1; i <= n; i++)
            {
                m_percom_temp[k] = i;
                if (k < m)
                    Fun_Combination_Recursion(n, m, k + 1);
                else
                {
                    m_strout += Getstr_percom_temp(m);
                }
            }
        }
        public void Fun_Arrange_Recursion(int n, int k)
        {
            for (int i = m_percom_temp[k - 1] + 1; i <= n; i++)
            {
                m_percom_temp[k] = i;
                int sumrs = 0;
                for (int j = 1; j <= k; j++)
                {
                    sumrs += m_bjrs[m_percom_temp[j]];
                }
                if (sumrs <= m_rs1 && m_bjrssum - sumrs <= m_rs2)
                    m_strout += Getstr_percom_tempbj(k);
                if (k < n)
                    Fun_Arrange_Recursion(n, k + 1);
            }
        }
        public void Fun_Permute_Stack(int n, int m,out int d)
        {
            //设置一个栈
            int[] s_no = new int[m + 1]; //存放栈顶次数的栈
            bool[] s_tag = new bool[n + 1]; //存放下标是否在栈中的标记
            int top = 0;
            //第一个进栈
            top++;
            m_percom_temp[top] = 1;
            s_no[top] = 1;
            s_tag[1] = true;//在栈中
            rTB_strout.Text = "";
            //栈不空时循环
            d = 0;
            while (top > 0)
            { 
                //查看栈顶标记
                if (s_no[top] == 1)
                {
                    //修改栈顶标记
                    s_no[top] = 2;
                    //继续进栈
                    if (top < m)
                    {
                        for (int i = 1; i <= n; i++)
                        {
                            if (s_tag[i] == false)
                            {
                                top++;
                                m_percom_temp[top] = i;
                                s_no[top] = 1;
                                s_tag[i] = true;//在栈中

                                break;
                            }
                        }
                    }
                    else
                    {
                        /*
                        for (int i = 1; i <= n; i++)
                        {
                            if (m_percom_temp[i] == i)
                            {
                                d++;
                                m_strout += "(*)";
                                break;
                            }
                        }
                        */
                        m_strout += Getstr_percom_temp(m);
                    }
                }
                else if (s_no[top] == 2)
                {
                    //出栈
                    s_tag[m_percom_temp[top]] = false;//不在栈中了
                    top--;
                    //下一个进栈
                    for (int i = m_percom_temp[top + 1]+1; i <= n; i++)
                    {
                        if (s_tag[i] == false)
                        {
                            top++;
                            m_percom_temp[top] = i;
                            s_no[top] = 1;
                            s_tag[i] = true;//在栈中
                            break;
                        }
                    }
                }
            }
        }
//------------------------------------------------------------------------------
        public Form_PerCom()
        {
            InitializeComponent();
        }

        private void bt_close_Click(object sender, EventArgs e)
        {
            this.Close();
            FormMain.myform_percom = null;
        }

        private void bt_permutation_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt16(tb_percom_n.Text);
            int m = Convert.ToInt16(tb_percom_m.Text);
            int dout = 0;
            int count = 1;
            for (int i = n; i >= n - m + 1; i--)
                count *= i;
            m_percom_temp = new int[m + 1];
            m_count = 0;
            progressBar1.Visible = true;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = count;
            progressBar1.Value = 0;
            m_strout = "";
            if (rb_sele1.Checked == true)
                Fun_Permute_Recursion(n, m, 1);
            else
                Fun_Permute_Stack(n, m,out dout);
            tb_stack_outdata.Text = "" + count;
            rTB_strout.Text = m_strout;
            progressBar1.Visible = false;
        }

        private void bt_combination_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt16(tb_percom_n.Text);
            int m = Convert.ToInt16(tb_percom_m.Text);
            long count = 1;
            for (int i = n; i >= n - m + 1; i--)
                count *= i;
            for (int i = m; i >= 1; i--)
                count /= i;
            m_percom_temp = new int[m + 1];
            m_count = 0;
            progressBar1.Visible = true;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = (int)count;
            progressBar1.Value = 0;
            m_strout = "";
            if (rb_sele1.Checked == true)
                Fun_Combination_Recursion(n, m, 1);
            else
                Fun_Combination_Recursion(n, m, 1);
            tb_stack_outdata.Text = "" + count;
            rTB_strout.Text = m_strout;
            progressBar1.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt16(tb_percom_n.Text);
            int m = Convert.ToInt16(tb_percom_m.Text);
            long count = 1;
            for (int i = n; i >= 1; i--)
                count *= 2;
            m_percom_temp = new int[n + 1];
            m_count = 0;
            progressBar1.Visible = true;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = (int)count;
            progressBar1.Value = 0;
            m_strout = Getstr_percom_temp(0);
            if (rb_sele1.Checked == true)
                Fun_Powerset_Recursion(n, 1);
            else
                Fun_Powerset_Recursion(n, 1);
            tb_stack_outdata.Text = "" + count;
            rTB_strout.Text = m_strout;
            progressBar1.Visible = false;
        }

        private void Form_PerCom_Load(object sender, EventArgs e)
        {
            m_bjs = 8;
            m_bjrs = new int[m_bjs + 1];
            m_bjrs[1] = 32; m_bjrs[2] = 30; m_bjrs[3] = 28; m_bjrs[4] = 25;
            m_bjrs[5] = 25; m_bjrs[6] = 20; m_bjrs[7] = 10; m_bjrs[8] = 10;
            m_bjrssum = 0;
            for(int i=1;i<=m_bjs;i++)
            {
                lB_brs.Items.Add(m_bjrs[i]);
                m_bjrssum += m_bjrs[i];
            }
            lb_allrs.Text = "各班级总人数为：" + m_bjrssum;
        }

        private void bt_arrange_Click(object sender, EventArgs e)
        {
            m_rs1 = Convert.ToInt16(tb_rs1.Text);
            m_rs2 = Convert.ToInt16(tb_rs2.Text);
            m_count = 0;
            progressBar1.Maximum = 0;
            m_strout = "";
            m_percom_temp = new int[m_bjs + 1];
            Fun_Arrange_Recursion(m_bjs, 1);
            rTB_strout.Text = m_strout;
        }
    }
}
