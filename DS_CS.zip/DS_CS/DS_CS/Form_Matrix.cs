﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DS_CS
{
    public partial class Form_Matrix : Form
    {
        matrix m_mat1,m_mat2,m_mat0; 
        public Form_Matrix()
        {
            InitializeComponent();
        }
        //---------------------------------------------------------------------------
        void defaultmatrix()
        {
            //初始化默认矩阵
            Rational[] t1 = new Rational[16];
            Rational[] t2 = new Rational[16];
            Rational[] t0 = new Rational[16];
            for (int i = 1; i <= 4; i++)
            {
                for (int j = 1; j <= 4; j++)
                {
                    t1[(i - 1) * 4 + (j - 1)] = new Rational(j, i);
                    t2[(i - 1) * 4 + (j - 1)] = new Rational(i, j);
                    t0[(i - 1) * 4 + (j - 1)] = new Rational();
                }
            }
            m_mat1 = new matrix(4, 4, t1);
            m_mat2 = new matrix(4, 4, t2);
            m_mat0 = new matrix(4, 4, t0);


            //初始化axMSFlexGrid
            axMSFlexGrid1.Cols = m_mat1.getcols() + 1;
            axMSFlexGrid1.Rows = m_mat1.getrows() + 1;
            axMSFlexGrid1.set_ColWidth(0, 600);
            axMSFlexGrid1.set_TextMatrix(0, 0, "矩阵1");
            axMSFlexGrid2.Cols = m_mat2.getcols() + 1;
            axMSFlexGrid2.Rows = m_mat2.getrows() + 1;
            axMSFlexGrid2.set_ColWidth(0, 600);
            axMSFlexGrid2.set_TextMatrix(0, 0, "矩阵2");
            axMSFlexGrid0.Cols = m_mat0.getcols() + 1;
            axMSFlexGrid0.Rows = m_mat0.getrows() + 1;
            axMSFlexGrid0.set_ColWidth(0, 600);
            axMSFlexGrid0.set_TextMatrix(0, 0, "结果");

            //显示矩阵
            DispMatrix(axMSFlexGrid1, m_mat1);
            DispMatrix(axMSFlexGrid2, m_mat2);
            DispMatrix(axMSFlexGrid0, m_mat0);
            settext();
        }
        private void Form_Matrix_Load(object sender, EventArgs e)
        {
            defaultmatrix();//初始化默认矩阵
        }
//---------------------------------------------------------------------------
        void settext()
        {
            matrix t_mat;
            if (rb_mat1.Checked == true)
		        t_mat=m_mat1;
            else
		        t_mat=m_mat2;
            text_rows.Text = "" + t_mat.getrows();
            text_cols.Text = "" + t_mat.getcols();
        }
        //将矩阵显示在MSFlexGrid中
        void DispMatrix(AxMSFlexGridLib.AxMSFlexGrid m_MSFlexGrid, matrix m_mat)
        {
	        int m=m_mat.getrows();
	        int n=m_mat.getcols();
            m_MSFlexGrid.Cols = m_mat.getcols() + 1;
            m_MSFlexGrid.Rows = m_mat.getrows() + 1;
            m_MSFlexGrid.set_ColWidth(0, 550);
            string str;
	        for(int i=1;i<=m;i++)
	        {
                str = "第" + i + "行";
                m_MSFlexGrid.set_TextMatrix(i, 0, str);
	        }
	        for(int j=1;j<=n;j++)
	        {
                str = "第" + j + "列";
                m_MSFlexGrid.set_TextMatrix(0, j, str);
            }
            
            Rational t;
	        for(int i=1;i<=m;i++)
	        {
    	        for(int j=1;j<=n;j++)
		        {
                    t = m_mat.getelems(i, j);
                    if (t != null)
                    {
                        if (t.Den == 1)
                            str = "" + t.Num;
                        else
                            str = "" + t.Num + "/" + t.Den;
                        m_MSFlexGrid.set_TextMatrix(i, j, str);
                    }
		        }
	        }
        }

        private void bt_plus_Click(object sender, EventArgs e)
        {
            m_mat0 = m_mat1 + m_mat2;
            DispMatrix(axMSFlexGrid0, m_mat0);
        }

        private void bt_minus_Click(object sender, EventArgs e)
        {
            m_mat0 = m_mat1 - m_mat2;
            DispMatrix(axMSFlexGrid0, m_mat0);
        }

        private void bt_mul_Click(object sender, EventArgs e)
        {
            m_mat0 = m_mat1 * m_mat2;
            DispMatrix(axMSFlexGrid0, m_mat0);
        }

        private void bt_Resulttomatrix_Click(object sender, EventArgs e)
        {
            if (rb_mat1.Checked == true)
            {
                m_mat1 = new matrix (m_mat0);
                DispMatrix(axMSFlexGrid1, m_mat1);
            }
            else
            {
                m_mat2 = new matrix(m_mat0);
                DispMatrix(axMSFlexGrid2, m_mat2);
            }

        }

        private void bt_Matrixtoedit_Click(object sender, EventArgs e)
        {
            matrix t_mat;
            if (rb_mat1.Checked == true)
		        t_mat=m_mat1;
            else
		        t_mat=m_mat2;
            richTextBox1.Text = t_mat.ToString();
        }

        private void bt_creatematrix_Click(object sender, EventArgs e)
        {
            if (rb_mat1.Checked == true)
            {
                m_mat1 = CreateMatrix();
                DispMatrix(axMSFlexGrid1, m_mat1);
            }
            else
            {
                m_mat2 = CreateMatrix();
                DispMatrix(axMSFlexGrid2, m_mat2);
            }
        }
        matrix ModifyMatrix(matrix m_mat)
        {
	        int i,j,ks=0;
	        int num=0,den=1;
            string m_input1 = richTextBox1.Text;
	        int len=richTextBox1.Text.Length;
            string str="";
            int m_rows = Convert.ToInt32(text_rows.Text);
            int m_cols = Convert.ToInt32(text_cols.Text);
            m_mat = new matrix(m_rows, m_cols);

	        for(i=1;i<=m_rows;i++)
	        {
		        if(ks>=len)
                    return m_mat;
	            for(j=1;j<=m_cols;j++)
		        {
                    str = "";
			        while((ks<len)&&((m_input1[ks]<'0')||(m_input1[ks]>'9'))&&m_input1[ks]!='-')
				        ks++;
		            while((ks<len)&&((m_input1[ks]>='0')&&(m_input1[ks]<='9')||(m_input1[ks]=='-')))    
    	                str=str+m_input1[ks++];
			        if(str!="")
				        num=Convert.ToInt32(str);
			        else 
				        num=0;
			        while((ks<len)&&(m_input1[ks]==' '))
				        ks++;
			        if((ks<len)&&(m_input1[ks]=='/'))
			        {
				        str="";ks++;
				        while((ks<len)&&(m_input1[ks]==' '))
					        ks++;
				        while((ks<len)&&(m_input1[ks]>='0')&&(m_input1[ks]<='9'))
                            str = str + m_input1[ks++];
                        if (str != "")
                            den = Convert.ToInt32(str);
                        else
                            den = 1;
				        while((ks<len)&&(m_input1[ks]==' '))
					        ks++;
			        }
			        else
			        {
				        den=1;
			        }
                    Rational rat = new Rational(num,den);
                    m_mat.setelems(i, j, rat);
			        if((ks<len)&&((m_input1[ks]=='\r')||(m_input1[ks]=='\n')))
			        {
				        break;
			        }
			        else if(ks>=len)
                        return m_mat;
		        }
	        }
            return m_mat;
        }
        matrix CreateMatrix()
        {
            string m_input = richTextBox1.Text;
            int m_rows = Convert.ToInt32(text_rows.Text);
            int m_cols = Convert.ToInt32(text_cols.Text);
            matrix m_mat = new matrix(m_rows, m_cols, m_input);
            return m_mat;
        }

        private void bt_rowt_Click(object sender, EventArgs e)
        {
            int rm;
            string strout;
            if (rb_mat1.Checked == true)
                m_mat0 = m_mat1.rowt(out rm, out strout);
            else
                m_mat0 = m_mat2.rowt(out rm, out strout);
            DispMatrix(axMSFlexGrid0, m_mat0);
            text_rm.Text = rm.ToString();
            richTextBox1.Text = strout;
        }

        private void bt_det_Click(object sender, EventArgs e)
        {
            Rational det;
            if (rb_mat1.Checked == true)
                det = m_mat1.det();
            else
                det = m_mat2.det();
            text_det.Text=det.ToString();
        }

        private void bt_creatematrix1_Click(object sender, EventArgs e)
        {
            int m_rows = Convert.ToInt32(text_rows.Text);
            int m_cols = Convert.ToInt32(text_cols.Text);
            if (rb_mat1.Checked == true)
            {
                m_mat1 = new matrix(m_rows, m_rows);
                DispMatrix(axMSFlexGrid1, m_mat1);
            }
            else
            {
                m_mat2 = new matrix(m_rows, m_rows);
                DispMatrix(axMSFlexGrid2, m_mat2);
            }
        }

        private void bt_mat_unite_Click(object sender, EventArgs e)
        {
            m_mat0 = m_mat0.mat_unite(m_mat1, m_mat2);
            DispMatrix(axMSFlexGrid0, m_mat0);
        }

        private void bt_mat_contra_Click(object sender, EventArgs e)
        {
            string strout;
            if (rb_mat1.Checked == true)
                m_mat0 = m_mat1.mat_inv(out strout);
            else
                m_mat0 = m_mat2.mat_inv(out strout);
            DispMatrix(axMSFlexGrid0, m_mat0);
            richTextBox1.Text = strout;
        }

        private void bt_Solve_Click(object sender, EventArgs e)
        {
            string strout;
            if (rb_mat1.Checked == true)
                m_mat0 = m_mat1.mat_solve(rb_hle.Checked,out strout);
            else
                m_mat0 = m_mat2.mat_solve(rb_hle.Checked,out strout);
            DispMatrix(axMSFlexGrid0, m_mat0);
            richTextBox1.Text = strout;
        }

        private void bt_defaultmatrix_Click(object sender, EventArgs e)
        {
            defaultmatrix();//初始化默认矩阵
        }

    }
}