﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DS_CS
{
    public partial class FormMain : Form
    {
        public static Form_Rational myform_rational=null;
        //public static Form_Matrix myform_matrix = null;
        public static Form_SeqList myform_seqlist = null;
        public static Form_SList myform_slist = null;
        public static Form_MazeN myform_maze = null;
        public static Form_Calculator myform_calculator = null;
        public static Form_Queens myform_queens = null;
        public static Form_Progrom myform_progrom = null;
        public static Form_PerCom myform_percom = null;
        public static Form_GenList myform_genlist = null;
        public static Form_BinTree myform_bintree = null;

        public FormMain()
        {
            InitializeComponent();
        }

        private void MenuItem11_Click(object sender, EventArgs e)
        {
            if (myform_rational == null)
            {
                myform_rational = new Form_Rational();
                myform_rational.MdiParent = this;
                myform_rational.Show();
            }
        }

        private void MenuItem12_Click(object sender, EventArgs e)
        {
            /*
            if (myform_matrix == null)
            {
                myform_matrix = new Form_Matrix();
                myform_matrix.MdiParent = this;
                myform_matrix.Show();
            }
            */
        }


        private void MenuItem_Maze_Click(object sender, EventArgs e)
        {
            if (myform_maze == null)
            {
                myform_maze = new Form_MazeN();
                myform_maze.MdiParent = this;
                myform_maze.Show();
            }
        }

        private void MenuItem_SList_Click(object sender, EventArgs e)
        {
            if (myform_slist == null)
            {
                myform_slist = new Form_SList();
                myform_slist.MdiParent = this;
                myform_slist.Show();
            }
        }

        private void MenuItem_express_Click(object sender, EventArgs e)
        {
            if (myform_calculator == null)
            {
                myform_calculator = new Form_Calculator();
                myform_calculator.MdiParent = this;
                myform_calculator.Show();
            }
        }

        private void MenuItem_Queens_Click(object sender, EventArgs e)
        {
            if (myform_queens == null)
            {
                myform_queens = new Form_Queens();
                myform_queens.MdiParent = this;
                myform_queens.Show();
            }
        }

        private void MenuItem_Form_Progrom_Click(object sender, EventArgs e)
        {
            myform_progrom = new Form_Progrom();
            myform_progrom.MdiParent = this;
            myform_progrom.Show();
        }

        private void MenuItem_SeqList_Click(object sender, EventArgs e)
        {
            if (myform_seqlist == null)
            {
                myform_seqlist = new Form_SeqList();
                myform_seqlist.MdiParent = this;
                myform_seqlist.Show();
            }
        }

        private void MenuItem_PerCom_Click(object sender, EventArgs e)
        {
            if (myform_percom == null)
            {
                myform_percom = new Form_PerCom();
                myform_percom.MdiParent = this;
                myform_percom.Show();
            }
        }

        private void MenuItem_GenList_Click(object sender, EventArgs e)
        {
            if (myform_genlist == null)
            {
                myform_genlist = new Form_GenList();
                myform_genlist.MdiParent = this;
                myform_genlist.Show();
            }
        }

        private void MenuItem_BinTree_Click(object sender, EventArgs e)
        {
            if (myform_bintree == null)
            {
                myform_bintree = new Form_BinTree();
                myform_bintree.MdiParent = this;
                myform_bintree.Show();
            }
        }





    }
}