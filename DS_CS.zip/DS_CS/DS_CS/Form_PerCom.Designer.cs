﻿namespace DS_CS
{
    partial class Form_PerCom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lb_allrs = new System.Windows.Forms.Label();
            this.lB_brs = new System.Windows.Forms.ListBox();
            this.tb_rs2 = new System.Windows.Forms.TextBox();
            this.tb_rs1 = new System.Windows.Forms.TextBox();
            this.bt_arrange = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bt_close = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bt_powerset = new System.Windows.Forms.Button();
            this.rb_sele2 = new System.Windows.Forms.RadioButton();
            this.rb_sele1 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_stack_outdata = new System.Windows.Forms.TextBox();
            this.tb_percom_m = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_percom_n = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_permutation = new System.Windows.Forms.Button();
            this.bt_combination = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.rTB_strout = new System.Windows.Forms.RichTextBox();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.bt_close);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(936, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(248, 789);
            this.panel1.TabIndex = 1;
            // 
            // progressBar1
            // 
            this.progressBar1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.progressBar1.Location = new System.Drawing.Point(0, 765);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(4);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(244, 20);
            this.progressBar1.TabIndex = 13;
            this.progressBar1.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lb_allrs);
            this.groupBox3.Controls.Add(this.lB_brs);
            this.groupBox3.Controls.Add(this.tb_rs2);
            this.groupBox3.Controls.Add(this.tb_rs1);
            this.groupBox3.Controls.Add(this.bt_arrange);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 316);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(244, 375);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "教室安排";
            // 
            // lb_allrs
            // 
            this.lb_allrs.AutoSize = true;
            this.lb_allrs.Location = new System.Drawing.Point(45, 277);
            this.lb_allrs.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_allrs.Name = "lb_allrs";
            this.lb_allrs.Size = new System.Drawing.Size(152, 18);
            this.lb_allrs.TabIndex = 8;
            this.lb_allrs.Text = "各班级总人数为：";
            // 
            // lB_brs
            // 
            this.lB_brs.FormattingEnabled = true;
            this.lB_brs.ItemHeight = 18;
            this.lB_brs.Location = new System.Drawing.Point(106, 102);
            this.lB_brs.Margin = new System.Windows.Forms.Padding(4);
            this.lB_brs.Name = "lB_brs";
            this.lB_brs.Size = new System.Drawing.Size(103, 148);
            this.lB_brs.TabIndex = 7;
            // 
            // tb_rs2
            // 
            this.tb_rs2.Location = new System.Drawing.Point(134, 66);
            this.tb_rs2.Margin = new System.Windows.Forms.Padding(4);
            this.tb_rs2.Name = "tb_rs2";
            this.tb_rs2.Size = new System.Drawing.Size(76, 28);
            this.tb_rs2.TabIndex = 6;
            this.tb_rs2.Text = "110";
            this.tb_rs2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_rs1
            // 
            this.tb_rs1.Location = new System.Drawing.Point(134, 28);
            this.tb_rs1.Margin = new System.Windows.Forms.Padding(4);
            this.tb_rs1.Name = "tb_rs1";
            this.tb_rs1.Size = new System.Drawing.Size(76, 28);
            this.tb_rs1.TabIndex = 5;
            this.tb_rs1.Text = "80";
            this.tb_rs1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bt_arrange
            // 
            this.bt_arrange.Location = new System.Drawing.Point(23, 312);
            this.bt_arrange.Margin = new System.Windows.Forms.Padding(4);
            this.bt_arrange.Name = "bt_arrange";
            this.bt_arrange.Size = new System.Drawing.Size(208, 45);
            this.bt_arrange.TabIndex = 0;
            this.bt_arrange.Text = "安排教室";
            this.bt_arrange.UseVisualStyleBackColor = true;
            this.bt_arrange.Click += new System.EventHandler(this.bt_arrange_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 70);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 18);
            this.label6.TabIndex = 3;
            this.label6.Text = "教室2人数";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(69, 122);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 112);
            this.label7.TabIndex = 3;
            this.label7.Text = "各班级人数";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 34);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 18);
            this.label5.TabIndex = 3;
            this.label5.Text = "教室1人数";
            // 
            // bt_close
            // 
            this.bt_close.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_close.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_close.Location = new System.Drawing.Point(23, 699);
            this.bt_close.Margin = new System.Windows.Forms.Padding(4);
            this.bt_close.Name = "bt_close";
            this.bt_close.Size = new System.Drawing.Size(201, 47);
            this.bt_close.TabIndex = 9;
            this.bt_close.Text = "退出";
            this.bt_close.UseVisualStyleBackColor = true;
            this.bt_close.Click += new System.EventHandler(this.bt_close_Click);
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 304);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(244, 12);
            this.panel3.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bt_powerset);
            this.groupBox1.Controls.Add(this.rb_sele2);
            this.groupBox1.Controls.Add(this.rb_sele1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tb_stack_outdata);
            this.groupBox1.Controls.Add(this.tb_percom_m);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tb_percom_n);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.bt_permutation);
            this.groupBox1.Controls.Add(this.bt_combination);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(0, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(244, 292);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "排列组合";
            // 
            // bt_powerset
            // 
            this.bt_powerset.Location = new System.Drawing.Point(132, 222);
            this.bt_powerset.Margin = new System.Windows.Forms.Padding(4);
            this.bt_powerset.Name = "bt_powerset";
            this.bt_powerset.Size = new System.Drawing.Size(98, 45);
            this.bt_powerset.TabIndex = 11;
            this.bt_powerset.Text = "幂集";
            this.bt_powerset.UseVisualStyleBackColor = true;
            this.bt_powerset.Click += new System.EventHandler(this.button1_Click);
            // 
            // rb_sele2
            // 
            this.rb_sele2.AutoSize = true;
            this.rb_sele2.Location = new System.Drawing.Point(134, 122);
            this.rb_sele2.Margin = new System.Windows.Forms.Padding(4);
            this.rb_sele2.Name = "rb_sele2";
            this.rb_sele2.Size = new System.Drawing.Size(69, 22);
            this.rb_sele2.TabIndex = 10;
            this.rb_sele2.Text = "栈法";
            this.rb_sele2.UseVisualStyleBackColor = true;
            // 
            // rb_sele1
            // 
            this.rb_sele1.AutoSize = true;
            this.rb_sele1.Checked = true;
            this.rb_sele1.Location = new System.Drawing.Point(21, 122);
            this.rb_sele1.Margin = new System.Windows.Forms.Padding(4);
            this.rb_sele1.Name = "rb_sele1";
            this.rb_sele1.Size = new System.Drawing.Size(87, 22);
            this.rb_sele1.TabIndex = 9;
            this.rb_sele1.TabStop = true;
            this.rb_sele1.Text = "递归法";
            this.rb_sele1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(160, 76);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 18);
            this.label3.TabIndex = 8;
            this.label3.Text = "(1～n)";
            // 
            // tb_stack_outdata
            // 
            this.tb_stack_outdata.Location = new System.Drawing.Point(26, 231);
            this.tb_stack_outdata.Margin = new System.Windows.Forms.Padding(4);
            this.tb_stack_outdata.Name = "tb_stack_outdata";
            this.tb_stack_outdata.Size = new System.Drawing.Size(82, 28);
            this.tb_stack_outdata.TabIndex = 7;
            this.tb_stack_outdata.Text = "4";
            this.tb_stack_outdata.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_percom_m
            // 
            this.tb_percom_m.Location = new System.Drawing.Point(99, 70);
            this.tb_percom_m.Margin = new System.Windows.Forms.Padding(4);
            this.tb_percom_m.Name = "tb_percom_m";
            this.tb_percom_m.Size = new System.Drawing.Size(58, 28);
            this.tb_percom_m.TabIndex = 7;
            this.tb_percom_m.Text = "4";
            this.tb_percom_m.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 76);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "选个数 m";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(160, 36);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 18);
            this.label2.TabIndex = 5;
            this.label2.Text = "(1～10)";
            // 
            // tb_percom_n
            // 
            this.tb_percom_n.Location = new System.Drawing.Point(99, 30);
            this.tb_percom_n.Margin = new System.Windows.Forms.Padding(4);
            this.tb_percom_n.Name = "tb_percom_n";
            this.tb_percom_n.Size = new System.Drawing.Size(58, 28);
            this.tb_percom_n.TabIndex = 4;
            this.tb_percom_n.Text = "4";
            this.tb_percom_n.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 36);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "总个数 n";
            // 
            // bt_permutation
            // 
            this.bt_permutation.Location = new System.Drawing.Point(21, 168);
            this.bt_permutation.Margin = new System.Windows.Forms.Padding(4);
            this.bt_permutation.Name = "bt_permutation";
            this.bt_permutation.Size = new System.Drawing.Size(98, 45);
            this.bt_permutation.TabIndex = 0;
            this.bt_permutation.Text = "排列";
            this.bt_permutation.UseVisualStyleBackColor = true;
            this.bt_permutation.Click += new System.EventHandler(this.bt_permutation_Click);
            // 
            // bt_combination
            // 
            this.bt_combination.Location = new System.Drawing.Point(132, 168);
            this.bt_combination.Margin = new System.Windows.Forms.Padding(4);
            this.bt_combination.Name = "bt_combination";
            this.bt_combination.Size = new System.Drawing.Size(98, 45);
            this.bt_combination.TabIndex = 0;
            this.bt_combination.Text = "组合";
            this.bt_combination.UseVisualStyleBackColor = true;
            this.bt_combination.Click += new System.EventHandler(this.bt_combination_Click);
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(244, 12);
            this.panel2.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.rTB_strout);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(936, 789);
            this.panel6.TabIndex = 3;
            // 
            // rTB_strout
            // 
            this.rTB_strout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rTB_strout.Location = new System.Drawing.Point(0, 0);
            this.rTB_strout.Margin = new System.Windows.Forms.Padding(4);
            this.rTB_strout.Name = "rTB_strout";
            this.rTB_strout.Size = new System.Drawing.Size(936, 789);
            this.rTB_strout.TabIndex = 0;
            this.rTB_strout.Text = "";
            // 
            // Form_PerCom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1184, 789);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form_PerCom";
            this.Text = "排列组合演示";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form_PerCom_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox tb_rs1;
        private System.Windows.Forms.Button bt_arrange;
        private System.Windows.Forms.Button bt_close;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_percom_n;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_permutation;
        private System.Windows.Forms.Button bt_combination;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_percom_m;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RichTextBox rTB_strout;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.RadioButton rb_sele2;
        private System.Windows.Forms.RadioButton rb_sele1;
        private System.Windows.Forms.Button bt_powerset;
        private System.Windows.Forms.ListBox lB_brs;
        private System.Windows.Forms.TextBox tb_rs2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_stack_outdata;
        private System.Windows.Forms.Label lb_allrs;
    }
}