﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DS_CS
{
    public partial class Form_BinTree : Form
    {
        private CBinaryTree m_slist;

        public double PI = 3.1415926 / 180;
        int m_level;
        double m_llen;
        double m_rlen;
        double m_angle;
        double m_langle;
        double m_rangle;
        double m_length;
        int m_zby;
        int m_penwidth;
        Graphics myg = null;


        public Form_BinTree()
        {
            InitializeComponent();
        }
        private void DrawTree2(int n,double L,double A,int x,int y)
        {
            Pen pen1 = null;
            Point p1 ;
            Point p2 ;
            if (n / 2.0 == n / 2)
                pen1 = new Pen(Color.FromArgb(255, 255, 0, 0), m_penwidth);
            else
                pen1 = new Pen(Color.FromArgb(255, 0, 255, 0), m_penwidth);

	        double B,C,s2,s3;
            B = 50;
            C = 12;
            s2 = 3;
            s3 = 1.3;
            int x1, y1, x1L, y1L, x1R, y1R, x2, y2, x2R, y2R, x2L, y2L;
            x2 = (int)(x + L * Math.Cos(A * PI));
            y2 = (int)(y + L * Math.Sin(A * PI));
            x2R = (int)(x2 + L / s2 * Math.Cos((A - B) * PI));
            y2R = (int)(y2 + L / s2 * Math.Sin((A - B) * PI));
            x2L = (int)(x2 + L / s2 * Math.Cos((A + B) * PI));
            y2L = (int)(y2 + L / s2 * Math.Sin((A + B) * PI));
          
            x1 = (int)(x + L / s2 * Math.Cos(A * PI));
            y1 = (int)(y + L / s2 * Math.Sin(A * PI));
            x1L = (int)(x1 + L / s2 * Math.Cos((A + B) * PI));
            y1L = (int)(y1 + L / s2 * Math.Sin((A + B) * PI));
            x1R = (int)(x1 + L / s2 * Math.Cos((A - B) * PI));
            y1R = (int)(y1 + L / s2 * Math.Sin((A - B) * PI));


            p1 = new Point(x, pictureBox1.Height - y);
            p2 = new Point(x2, pictureBox1.Height - y2);
            myg.DrawLine(pen1, p1, p2);
            p1 = p2;
            p2 = new Point(x2R, pictureBox1.Height - y2R);
            myg.DrawLine(pen1, p1, p2);
            p1 = new Point(x2, pictureBox1.Height - y2);
            p2 = new Point(x2L, pictureBox1.Height - y2L);
            myg.DrawLine(pen1, p1, p2);
            p1 = new Point(x1, pictureBox1.Height - y1);
            p2 = new Point(x1L, pictureBox1.Height - y1L);
            myg.DrawLine(pen1, p1, p2);
            p1 = new Point(x1, pictureBox1.Height - y1);
            p2 = new Point(x1R, pictureBox1.Height - y1R);
            myg.DrawLine(pen1, p1, p2);



	        if((n<m_level)&&(L>2))
	        {
                DrawTree2(n + 1, L / s3, A - C, x2, y2);
                DrawTree2(n + 1, L / s2, A + B, x2L, y2L);
                DrawTree2(n + 1, L / s2, A - B, x2R, y2R);
                DrawTree2(n + 1, L / s2, A + B, x1L, y1L);
                DrawTree2(n + 1, L / s2, A - B, x1R, y1R);
	        }
        }
        private void DrawTree1(int n,double len,double arg,int x,int y)
        {
            Pen pen1 = null;
            if (n / 2.0 == n / 2)
                pen1 = new Pen(Color.FromArgb(255, 255, 0, 0), m_penwidth);
            else
                pen1 = new Pen(Color.FromArgb(255, 0, 255, 0), m_penwidth);
	        int xx,yy;
            xx = (int)(len * Math.Cos(arg));
            yy = (int)(len * Math.Sin(arg));
            if (x < 1)
                x = 1;
            if (x > pictureBox1.Width - 1)
                x = pictureBox1.Width - 1;
            if (y < 1)
                y = 1;
            if (y > pictureBox1.Height - 1)
                y = pictureBox1.Height - 1;
            Point p1 = new Point(x, pictureBox1.Height - y);
            if (x + xx < 1)
                xx = 1 - x;
            if (x + xx > pictureBox1.Width - 1)
                xx = pictureBox1.Width - 1 - x;
            if (y + yy < 1)
                yy = 1 - y;
            if (y + yy > pictureBox1.Height - 1)
                yy = pictureBox1.Height - 1 - y;
            Point p2 = new Point(x + xx, pictureBox1.Height - (y + yy));
            myg.DrawLine(pen1, p1, p2);

            double lt = m_langle * PI;
            double rt = m_rangle * PI;
	        if((n<m_level)&&(len>=1))
	        {
                DrawTree1(n + 1, len * m_llen, arg + lt, x + xx, y + yy);
                DrawTree1(n + 1, len * m_rlen, arg - rt, x + xx, y + yy);
	        }
        }


        private void bt_drawf1_Click(object sender, EventArgs e)
        {
            m_penwidth = Convert.ToInt16(tb_penwidth.Text);
            m_level = Convert.ToInt16(tb_level.Text);
            m_length = Convert.ToDouble(tb_length.Text);
            m_angle = Convert.ToDouble(tb_angle.Text);
            m_zby = Convert.ToInt16(tb_zby.Text);
            m_llen = Convert.ToDouble(tb_llen.Text);
            m_rlen = Convert.ToDouble(tb_rlen.Text);
            m_langle = Convert.ToDouble(tb_langle.Text);
            m_rangle = Convert.ToDouble(tb_rangle.Text);

            myg.Clear(Color.FromArgb(255, 255, 255, 255));
            DrawTree1(1, m_length, m_angle * 3.14 / 180.0, pictureBox1.Width / 2, m_zby);	

        }

        void SetInit()
        {
            m_penwidth = 2;
            m_level = 12;
            m_length = 150;
            m_angle = 90;
            m_llen = 0.66;
            m_rlen = 0.66;
            m_langle = 45;
            m_rangle = 45;
            m_zby = 50;

            tb_penwidth.Text = Convert.ToString(m_penwidth);
            tb_level.Text = Convert.ToString(m_level);
            tb_length.Text = Convert.ToString(m_length);
            tb_angle.Text = Convert.ToString(m_angle);
            tb_zby.Text = Convert.ToString(m_zby);
            tb_llen.Text = Convert.ToString(m_llen);
            tb_rlen.Text = Convert.ToString(m_rlen);
            tb_langle.Text = Convert.ToString(m_langle);
            tb_rangle.Text = Convert.ToString(m_rangle);
        }
        private void bt_mr_Click(object sender, EventArgs e)
        {
            SetInit();
        }

        private void bt_drawf2_Click(object sender, EventArgs e)
        {
            m_penwidth = Convert.ToInt16(tb_penwidth.Text);
            m_level = Convert.ToInt16(tb_level.Text);
            m_length = Convert.ToDouble(tb_length.Text);
            m_angle = Convert.ToDouble(tb_angle.Text);

            myg.Clear(Color.FromArgb(255, 255, 255, 255));
            DrawTree2(1, m_length, m_angle, pictureBox1.Width / 2, 50);	
        }

        private void Form_BinTree_Load(object sender, EventArgs e)
        {
            myg = pictureBox1.CreateGraphics();
            myg.Clear(Color.FromArgb(255, 255, 255, 255));
            SetInit();
        }

        private void bt_create_Click(object sender, EventArgs e)
        {
            m_slist = new CBinaryTree();
            m_slist.CreateBinTreestr(tb_strin1.Text);
            m_slist.DrawBTree(pictureBox1);
        }

        private void tb_Traversal_Click(object sender, EventArgs e)
        {
            string strout = "";
            if (m_slist==null)
                m_slist = new CBinaryTree();
            if (rb_tr0.Checked)
                m_slist.Traversal(0, out strout);
            else if (rb_tr1.Checked)
                m_slist.Traversal(1, out strout);
            else if (rb_tr2.Checked)
                m_slist.Traversal(2, out strout);
            else if (rb_tr3.Checked)
                m_slist.Traversal(3, out strout);

            Brush bkbrush = new SolidBrush(Color.White);//背景色
            myg.FillRectangle(bkbrush, 0, 0, (int)(pictureBox1.Width), 35);
            Font font = new Font("Arial", 15);
            SolidBrush b1 = new SolidBrush(Color.Red);
            StringFormat sf1 = new StringFormat();
            myg.DrawString(strout, font, b1, 5, 10, sf1);

        }

        private void bt_create2_Click(object sender, EventArgs e)
        {
            if (tb_strin1.Text.Length != tb_strin2.Text.Length)
            {
                tb_strin1.Text = "ABHFDECKG";
                tb_strin2.Text = "HBDFAEKCG";
            }
            m_slist = new CBinaryTree();
            m_slist.StoBT(tb_strin1.Text, tb_strin2.Text);
            m_slist.DrawBTree(pictureBox1);
        }

        private void tb_Traversalpp_Click(object sender, EventArgs e)
        {
            string strout = "";
            if (m_slist == null)
                m_slist = new CBinaryTree();
            if (rb_tr0.Checked)
                m_slist.Traversalpp(0, out strout);
            else if (rb_tr1.Checked)
                m_slist.Traversalpp(1, out strout);
            else if (rb_tr2.Checked)
                m_slist.Traversalpp(2, out strout);
            else if (rb_tr3.Checked)
                m_slist.Traversalpp(3, out strout);

            Brush bkbrush = new SolidBrush(Color.White);//背景色
            myg.FillRectangle(bkbrush, 0, 0, (int)(pictureBox1.Width), 35);
            Font font = new Font("Arial", 15);
            SolidBrush b1 = new SolidBrush(Color.Red);
            StringFormat sf1 = new StringFormat();
            myg.DrawString(strout, font, b1, 5, 10, sf1);
        }

        private void tb_T0_Draw_Click(object sender, EventArgs e)
        {
            if(m_slist!=null)
                m_slist.DrawBTree_T0(pictureBox1);

        }
    }
}