﻿namespace DS_CS
{
    partial class Form_Queens
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Queens));
            this.bt_close = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bt_create = new System.Windows.Forms.Button();
            this.pb_HH = new System.Windows.Forms.PictureBox();
            this.tb_n = new System.Windows.Forms.TextBox();
            this.pb_queens = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_HH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_queens)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_close
            // 
            this.bt_close.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_close.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_close.Location = new System.Drawing.Point(12, 370);
            this.bt_close.Name = "bt_close";
            this.bt_close.Size = new System.Drawing.Size(134, 40);
            this.bt_close.TabIndex = 11;
            this.bt_close.Text = "退出";
            this.bt_close.UseVisualStyleBackColor = true;
            this.bt_close.Click += new System.EventHandler(this.bt_close_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bt_create);
            this.panel1.Controls.Add(this.pb_HH);
            this.panel1.Controls.Add(this.tb_n);
            this.panel1.Controls.Add(this.bt_close);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(416, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(159, 422);
            this.panel1.TabIndex = 12;
            // 
            // bt_create
            // 
            this.bt_create.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_create.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_create.Location = new System.Drawing.Point(29, 41);
            this.bt_create.Name = "bt_create";
            this.bt_create.Size = new System.Drawing.Size(100, 323);
            this.bt_create.TabIndex = 11;
            this.bt_create.Text = "创建并求解皇后问题";
            this.bt_create.UseVisualStyleBackColor = true;
            this.bt_create.Click += new System.EventHandler(this.bt_create_Click);
            // 
            // pb_HH
            // 
            this.pb_HH.Image = ((System.Drawing.Image)(resources.GetObject("pb_HH.Image")));
            this.pb_HH.Location = new System.Drawing.Point(41, 158);
            this.pb_HH.Name = "pb_HH";
            this.pb_HH.Size = new System.Drawing.Size(69, 84);
            this.pb_HH.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_HH.TabIndex = 13;
            this.pb_HH.TabStop = false;
            // 
            // tb_n
            // 
            this.tb_n.Location = new System.Drawing.Point(29, 14);
            this.tb_n.Name = "tb_n";
            this.tb_n.Size = new System.Drawing.Size(100, 21);
            this.tb_n.TabIndex = 12;
            this.tb_n.Text = "8";
            this.tb_n.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pb_queens
            // 
            this.pb_queens.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_queens.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pb_queens.Location = new System.Drawing.Point(0, 0);
            this.pb_queens.Name = "pb_queens";
            this.pb_queens.Size = new System.Drawing.Size(416, 422);
            this.pb_queens.TabIndex = 13;
            this.pb_queens.TabStop = false;
            // 
            // Form_Queens
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(575, 422);
            this.Controls.Add(this.pb_queens);
            this.Controls.Add(this.panel1);
            this.Name = "Form_Queens";
            this.Text = "N皇后问题";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_HH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_queens)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_close;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pb_queens;
        private System.Windows.Forms.TextBox tb_n;
        private System.Windows.Forms.Button bt_create;
        private System.Windows.Forms.PictureBox pb_HH;
    }
}