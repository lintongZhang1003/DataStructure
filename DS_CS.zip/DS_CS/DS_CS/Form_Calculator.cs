﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DS_CS
{
    public partial class Form_Calculator : Form
    {
        public Form_Calculator()
        {
            InitializeComponent();
        }

        private void bt_calculat_Click(object sender, EventArgs e)
        {
            string m_result,m_strout;
            Calculator m_cal=new Calculator(50);
	        Rational m_rat=new Rational();
            if (tb_express.Text == "")
            {
                tb_result.Text = "null";
                return;
            }
            m_rat = m_cal.Run(tb_express.Text,out m_strout);
            long num = m_rat.Num;
            long den = m_rat.Den;
            if (den == 1)
                m_result = "" + num;
            else
                m_result = "" + num + "/" + den;
            tb_result.Text = m_result;
            tb_strout.Text = m_strout;
        }

        private void bt_close_Click(object sender, EventArgs e)
        {
            this.Close();
            FormMain.myform_calculator = null;
        }

        private void Form_Calculator_FormClosed(object sender, FormClosedEventArgs e)
        {
            FormMain.myform_calculator = null;
        }

    }
}