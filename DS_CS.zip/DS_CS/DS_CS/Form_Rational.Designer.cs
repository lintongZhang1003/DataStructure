﻿namespace DS_CS
{
    partial class Form_Rational
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_close = new System.Windows.Forms.Button();
            this.rat1_num = new System.Windows.Forms.TextBox();
            this.rat1_den = new System.Windows.Forms.TextBox();
            this.rat2_den = new System.Windows.Forms.TextBox();
            this.rat2_num = new System.Windows.Forms.TextBox();
            this.rat0_den = new System.Windows.Forms.TextBox();
            this.rat0_num = new System.Windows.Forms.TextBox();
            this.bt_run = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rb5 = new System.Windows.Forms.RadioButton();
            this.rb4 = new System.Windows.Forms.RadioButton();
            this.rb3 = new System.Windows.Forms.RadioButton();
            this.rb2 = new System.Windows.Forms.RadioButton();
            this.rb1 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.rb6 = new System.Windows.Forms.RadioButton();
            this.rb7 = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bt_close
            // 
            this.bt_close.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_close.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_close.Location = new System.Drawing.Point(339, 232);
            this.bt_close.Name = "bt_close";
            this.bt_close.Size = new System.Drawing.Size(87, 47);
            this.bt_close.TabIndex = 0;
            this.bt_close.Text = "退出";
            this.bt_close.UseVisualStyleBackColor = true;
            this.bt_close.Click += new System.EventHandler(this.bt_close_Click);
            // 
            // rat1_num
            // 
            this.rat1_num.Location = new System.Drawing.Point(34, 51);
            this.rat1_num.Name = "rat1_num";
            this.rat1_num.Size = new System.Drawing.Size(99, 21);
            this.rat1_num.TabIndex = 1;
            this.rat1_num.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rat1_den
            // 
            this.rat1_den.Location = new System.Drawing.Point(34, 75);
            this.rat1_den.Name = "rat1_den";
            this.rat1_den.Size = new System.Drawing.Size(99, 21);
            this.rat1_den.TabIndex = 2;
            this.rat1_den.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rat2_den
            // 
            this.rat2_den.Location = new System.Drawing.Point(201, 75);
            this.rat2_den.Name = "rat2_den";
            this.rat2_den.Size = new System.Drawing.Size(99, 21);
            this.rat2_den.TabIndex = 4;
            this.rat2_den.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rat2_num
            // 
            this.rat2_num.Location = new System.Drawing.Point(201, 51);
            this.rat2_num.Name = "rat2_num";
            this.rat2_num.Size = new System.Drawing.Size(99, 21);
            this.rat2_num.TabIndex = 3;
            this.rat2_num.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rat0_den
            // 
            this.rat0_den.Location = new System.Drawing.Point(339, 75);
            this.rat0_den.Name = "rat0_den";
            this.rat0_den.Size = new System.Drawing.Size(99, 21);
            this.rat0_den.TabIndex = 6;
            this.rat0_den.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rat0_num
            // 
            this.rat0_num.Location = new System.Drawing.Point(339, 51);
            this.rat0_num.Name = "rat0_num";
            this.rat0_num.Size = new System.Drawing.Size(99, 21);
            this.rat0_num.TabIndex = 5;
            this.rat0_num.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bt_run
            // 
            this.bt_run.Location = new System.Drawing.Point(214, 232);
            this.bt_run.Name = "bt_run";
            this.bt_run.Size = new System.Drawing.Size(99, 48);
            this.bt_run.TabIndex = 7;
            this.bt_run.Text = "运算";
            this.bt_run.UseVisualStyleBackColor = true;
            this.bt_run.Click += new System.EventHandler(this.bt_run_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rb7);
            this.groupBox1.Controls.Add(this.rb6);
            this.groupBox1.Controls.Add(this.rb5);
            this.groupBox1.Controls.Add(this.rb4);
            this.groupBox1.Controls.Add(this.rb3);
            this.groupBox1.Controls.Add(this.rb2);
            this.groupBox1.Controls.Add(this.rb1);
            this.groupBox1.Location = new System.Drawing.Point(140, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(55, 202);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            // 
            // rb5
            // 
            this.rb5.AutoSize = true;
            this.rb5.Location = new System.Drawing.Point(12, 111);
            this.rb5.Name = "rb5";
            this.rb5.Size = new System.Drawing.Size(29, 16);
            this.rb5.TabIndex = 3;
            this.rb5.Text = "^";
            this.rb5.UseVisualStyleBackColor = true;
            // 
            // rb4
            // 
            this.rb4.AutoSize = true;
            this.rb4.Location = new System.Drawing.Point(12, 89);
            this.rb4.Name = "rb4";
            this.rb4.Size = new System.Drawing.Size(29, 16);
            this.rb4.TabIndex = 3;
            this.rb4.Text = "/";
            this.rb4.UseVisualStyleBackColor = true;
            // 
            // rb3
            // 
            this.rb3.AutoSize = true;
            this.rb3.Location = new System.Drawing.Point(12, 66);
            this.rb3.Name = "rb3";
            this.rb3.Size = new System.Drawing.Size(29, 16);
            this.rb3.TabIndex = 2;
            this.rb3.Text = "*";
            this.rb3.UseVisualStyleBackColor = true;
            // 
            // rb2
            // 
            this.rb2.AutoSize = true;
            this.rb2.Location = new System.Drawing.Point(12, 43);
            this.rb2.Name = "rb2";
            this.rb2.Size = new System.Drawing.Size(29, 16);
            this.rb2.TabIndex = 1;
            this.rb2.Text = "-";
            this.rb2.UseVisualStyleBackColor = true;
            // 
            // rb1
            // 
            this.rb1.AutoSize = true;
            this.rb1.Checked = true;
            this.rb1.Location = new System.Drawing.Point(12, 20);
            this.rb1.Name = "rb1";
            this.rb1.Size = new System.Drawing.Size(29, 16);
            this.rb1.TabIndex = 0;
            this.rb1.TabStop = true;
            this.rb1.Text = "+";
            this.rb1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(312, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "=";
            // 
            // rb6
            // 
            this.rb6.AutoSize = true;
            this.rb6.Location = new System.Drawing.Point(12, 150);
            this.rb6.Name = "rb6";
            this.rb6.Size = new System.Drawing.Size(35, 16);
            this.rb6.TabIndex = 4;
            this.rb6.Text = "++";
            this.rb6.UseVisualStyleBackColor = true;
            // 
            // rb7
            // 
            this.rb7.AutoSize = true;
            this.rb7.Location = new System.Drawing.Point(12, 172);
            this.rb7.Name = "rb7";
            this.rb7.Size = new System.Drawing.Size(35, 16);
            this.rb7.TabIndex = 4;
            this.rb7.Text = "--";
            this.rb7.UseVisualStyleBackColor = true;
            // 
            // Form_Rational
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 313);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.bt_run);
            this.Controls.Add(this.rat0_den);
            this.Controls.Add(this.rat0_num);
            this.Controls.Add(this.rat2_den);
            this.Controls.Add(this.rat2_num);
            this.Controls.Add(this.rat1_den);
            this.Controls.Add(this.rat1_num);
            this.Controls.Add(this.bt_close);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form_Rational";
            this.Text = "有理数的运算";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_close;
        private System.Windows.Forms.TextBox rat1_num;
        private System.Windows.Forms.TextBox rat1_den;
        private System.Windows.Forms.TextBox rat2_den;
        private System.Windows.Forms.TextBox rat2_num;
        private System.Windows.Forms.TextBox rat0_den;
        private System.Windows.Forms.TextBox rat0_num;
        private System.Windows.Forms.Button bt_run;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rb2;
        private System.Windows.Forms.RadioButton rb1;
        private System.Windows.Forms.RadioButton rb4;
        private System.Windows.Forms.RadioButton rb3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rb5;
        private System.Windows.Forms.RadioButton rb7;
        private System.Windows.Forms.RadioButton rb6;
    }
}