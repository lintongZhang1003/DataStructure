﻿namespace DS_CS
{
    partial class Form_Graph
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_graph_matrix = new System.Windows.Forms.TextBox();
            this.bt_createmaze = new System.Windows.Forms.Button();
            this.bt_creategraph = new System.Windows.Forms.Button();
            this.bt_openfile = new System.Windows.Forms.Button();
            this.tb_fname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pb_graph = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_graph)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.tb_graph_matrix);
            this.panel1.Controls.Add(this.bt_createmaze);
            this.panel1.Controls.Add(this.bt_creategraph);
            this.panel1.Controls.Add(this.bt_openfile);
            this.panel1.Controls.Add(this.tb_fname);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(760, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(386, 652);
            this.panel1.TabIndex = 0;
            // 
            // tb_graph_matrix
            // 
            this.tb_graph_matrix.Location = new System.Drawing.Point(6, 96);
            this.tb_graph_matrix.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_graph_matrix.Multiline = true;
            this.tb_graph_matrix.Name = "tb_graph_matrix";
            this.tb_graph_matrix.Size = new System.Drawing.Size(372, 256);
            this.tb_graph_matrix.TabIndex = 16;
            // 
            // bt_createmaze
            // 
            this.bt_createmaze.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_createmaze.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_createmaze.Location = new System.Drawing.Point(8, 436);
            this.bt_createmaze.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bt_createmaze.Name = "bt_createmaze";
            this.bt_createmaze.Size = new System.Drawing.Size(375, 93);
            this.bt_createmaze.TabIndex = 15;
            this.bt_createmaze.Text = "生成迷宫矩阵并显示迷宫及最短路径";
            this.bt_createmaze.UseVisualStyleBackColor = true;
            this.bt_createmaze.Click += new System.EventHandler(this.bt_createmaze_Click);
            // 
            // bt_creategraph
            // 
            this.bt_creategraph.Location = new System.Drawing.Point(165, 9);
            this.bt_creategraph.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bt_creategraph.Name = "bt_creategraph";
            this.bt_creategraph.Size = new System.Drawing.Size(214, 39);
            this.bt_creategraph.TabIndex = 14;
            this.bt_creategraph.Text = "生成图";
            this.bt_creategraph.UseVisualStyleBackColor = true;
            this.bt_creategraph.Click += new System.EventHandler(this.bt_creategraph_Click);
            // 
            // bt_openfile
            // 
            this.bt_openfile.Location = new System.Drawing.Point(336, 51);
            this.bt_openfile.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bt_openfile.Name = "bt_openfile";
            this.bt_openfile.Size = new System.Drawing.Size(48, 40);
            this.bt_openfile.TabIndex = 13;
            this.bt_openfile.Text = "...";
            this.bt_openfile.UseVisualStyleBackColor = true;
            this.bt_openfile.Click += new System.EventHandler(this.bt_openfile_Click);
            // 
            // tb_fname
            // 
            this.tb_fname.Location = new System.Drawing.Point(4, 57);
            this.tb_fname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tb_fname.Name = "tb_fname";
            this.tb_fname.Size = new System.Drawing.Size(328, 28);
            this.tb_fname.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 18);
            this.label1.TabIndex = 11;
            this.label1.Text = "打开图矩阵文件";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pb_graph);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(760, 652);
            this.panel2.TabIndex = 1;
            // 
            // pb_graph
            // 
            this.pb_graph.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pb_graph.Location = new System.Drawing.Point(0, 0);
            this.pb_graph.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pb_graph.Name = "pb_graph";
            this.pb_graph.Size = new System.Drawing.Size(760, 652);
            this.pb_graph.TabIndex = 0;
            this.pb_graph.TabStop = false;
            // 
            // Form_Graph
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1146, 652);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form_Graph";
            this.Text = "Form_Graph";
            this.Load += new System.EventHandler(this.Form_Graph_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_graph)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bt_createmaze;
        private System.Windows.Forms.Button bt_creategraph;
        private System.Windows.Forms.Button bt_openfile;
        private System.Windows.Forms.TextBox tb_fname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_graph_matrix;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pb_graph;
    }
}