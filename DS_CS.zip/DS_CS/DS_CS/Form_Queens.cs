﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DS_CS
{

    public partial class Form_Queens : Form
    {
        CQueens m_queens;
        Image image0;


        public Form_Queens()
        {
            InitializeComponent();
        }

        private void bt_close_Click(object sender, EventArgs e)
        {
            this.Close();
            FormMain.myform_queens = null;
        }
        void DrawQueens(CQueens m_queens)
        {
            //读取照片
            image0 = pb_HH.Image;
            //image0 = System.Drawing.Image.FromFile("..\\..\\picture.bmp");

            Graphics myg;
            int xmin = 0;
            int ymin = 0;
            int xmax, ymax;

            int n = m_queens.Getrows();
            if (n == 0)
                return;
            myg = pb_queens.CreateGraphics();
            xmax = pb_queens.Width;
            ymax = pb_queens.Height;
            //设置显示颜色
            Color bkColor0, bkColor1, bkColor2;
            Brush bkBrushnow, bkBrush0, bkBrush1, bkBrush2;
            Brush bkbrush = new SolidBrush(Color.White);//背景色
            bkColor0 = Color.FromArgb(255, 255, 255, 0);//能通行的节点颜色
            bkBrush0 = new SolidBrush(bkColor0);
            bkColor1 = Color.FromArgb(255, 125, 125, 125);//不能通行的节点颜色
            bkBrush1 = new SolidBrush(bkColor1);
            bkColor2 = Color.FromArgb(255, 255, 0, 255);//最短路径的节点颜色
            bkBrush2 = new SolidBrush(bkColor2);
            //画背景
            myg.FillRectangle(bkbrush, xmin, ymin, xmax - xmin, ymax - ymin);
            int cw, ch;
            int px, py, i, j;
            cw = (xmax - 40) / n;
            ch = (ymax - 40) / n;
            for (i = 0; i < n; i++)
            {
                py = 20 + ch * i;
                for (j = 0; j < n; j++)
                {
                    px = 20 + cw * j;
                    bkBrushnow = bkBrush0;
                    if (m_queens.Getelems(i, j) != -2)
                    {
                        if (((i % 2 == 0) && (j % 2 == 0)) || ((i % 2 == 1) && (j % 2 == 1)))
                            bkBrushnow = bkBrush0;
                        else
                            bkBrushnow = bkBrush1;
                    }
                    else if (m_queens.Getelems(i, j) == -2)
                    {
                        bkBrushnow = bkBrush2;
                    }
                    Rectangle rc = new Rectangle(px, py, cw, ch);
                    myg.FillRectangle(bkBrushnow, rc);
                    Pen pen1 = new Pen(Color.Red, 1);
                    myg.DrawRectangle(pen1, rc);

                    if (m_queens.Getelems(i, j) == -1)
                    {
                        Rectangle sr0 = new Rectangle(0, 0, image0.Width, image0.Height); //要显示的图像区域 
                        Rectangle srd = new Rectangle(px + cw / 6, py + ch / 6, cw *44/ 60, ch *44/ 60);
                        myg.DrawImage(image0, srd, sr0, GraphicsUnit.Pixel);
                    }
                
                }
            }
        }


        private void bt_create_Click(object sender, EventArgs e)
        {
            m_queens = new CQueens(Convert.ToInt16(tb_n.Text));
            m_queens.ClearQueens();
            m_queens.CreateRandoms();
            m_queens.Queens_Solve(0);

            DrawQueens(m_queens);
        }
    }

    public class CQueens
    {
        private int rows;
        Random myr;
        private int[,] elems;
        int[] data;
        //--------------------------------------------------------------------------------
        public int Getrows() { return rows; }
        public int Getelems(int row, int col)
        {
            return elems[row, col];
        }
        public void Setelems(int row, int col, int value)
        {
            elems[row, col] = value;
        }

        public CQueens(int n)
        {
            rows = n;
            elems = new int[rows, rows];
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < rows; j++)
                {
                    elems[i, j] = 0;
                }
            }
            myr = new Random();
            data = new int[rows];
        }
        public void ClearQueens()
        {
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < rows; j++)
                {
                    elems[i, j] = 0;
                }
            }
        }
        public void CreateRandoms()
        {
            //产生随机数
            bool h = false;
            int n = 0;
            while (true)
            {
                if (n == rows)
                    break;
                int k0 = myr.Next(0, rows);
                h = false;
                for (int i = 0; i < n; i++)
                {
                    if (data[i] == k0)
                        h = true;
                }
                if (h == true)
                {
                    n--;
                    continue;
                }
                data[n] = k0;
                n++;
            }
        }


        public bool Queens_Solve(int kk)
        {



            for (int j0 = 0; j0 < rows; j0++)
            {
                int j=data[j0];
                j = j0;
                //跳过已经做过标记的
                if (elems[kk, j] != 0)
                    continue;
                //结束标志
                if ((kk == rows - 1) && (elems[kk, j] == 0))
                {
                    elems[kk, j] = -1;
                    return true;
                }


                //下面进行标记“加一”
                //当前标记为-1
                elems[kk, j] = -1; 
                //垂直向下的标记
                for (int i1 = kk + 1; i1 < rows; i1++)
                    elems[i1, j] ++;
                //右向下的标记
                for (int i1 = kk + 1, j1 = j + 1; (i1 < rows) && (j1 < rows); i1++, j1++)
                    elems[i1, j1]++;
                //左向下的标记
                for (int i1 = kk + 1, j1 = j - 1; (i1 < rows) && (j1 >= 0); i1++, j1--)
                    elems[i1, j1]++;
                //递归调用
                if (Queens_Solve(kk + 1) == true)
                    return true;
                //下面进行标记“减一”
                //当前标记为0
                elems[kk, j] = 0;
                //垂直向下的标记
                for (int i1 = kk + 1; i1 < rows; i1++)
                    elems[i1, j]--;
                //右向下的标记
                for (int i1 = kk + 1, j1 = j + 1; (i1 < rows) && (j1 < rows); i1++, j1++)
                    elems[i1, j1]--;
                //左向下的标记
                for (int i1 = kk + 1, j1 = j - 1; (i1 < rows) && (j1 >= 0); i1++, j1--)
                    elems[i1, j1]--;

            }
            return false;
        }

    }
}