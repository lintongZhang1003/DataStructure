﻿namespace DS_CS
{
    partial class Form_GenList
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_strin = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tb_strprint = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tb_strout = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bt_Traversal = new System.Windows.Forms.Button();
            this.rb_gl2 = new System.Windows.Forms.RadioButton();
            this.rb_gl1 = new System.Windows.Forms.RadioButton();
            this.bt_copyt = new System.Windows.Forms.Button();
            this.bt_print = new System.Windows.Forms.Button();
            this.bt_create = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tb_strin);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1100, 36);
            this.panel1.TabIndex = 0;
            // 
            // tb_strin
            // 
            this.tb_strin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_strin.Location = new System.Drawing.Point(0, 0);
            this.tb_strin.Margin = new System.Windows.Forms.Padding(4);
            this.tb_strin.Name = "tb_strin";
            this.tb_strin.Size = new System.Drawing.Size(1100, 28);
            this.tb_strin.TabIndex = 0;
            this.tb_strin.Text = "((2.345,(\'B\',7/3,(),((),\"到此一游\"))),(\"ASD\"),(\'A\',2/4,3,1.23))";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tb_strprint);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 732);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1100, 38);
            this.panel2.TabIndex = 1;
            // 
            // tb_strprint
            // 
            this.tb_strprint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_strprint.Location = new System.Drawing.Point(0, 0);
            this.tb_strprint.Margin = new System.Windows.Forms.Padding(4);
            this.tb_strprint.Name = "tb_strprint";
            this.tb_strprint.Size = new System.Drawing.Size(1100, 28);
            this.tb_strprint.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.groupBox2);
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 36);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1100, 696);
            this.panel3.TabIndex = 2;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tb_strout);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(800, 696);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "操作过程显示";
            // 
            // tb_strout
            // 
            this.tb_strout.BackColor = System.Drawing.SystemColors.Window;
            this.tb_strout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_strout.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tb_strout.Location = new System.Drawing.Point(4, 25);
            this.tb_strout.Margin = new System.Windows.Forms.Padding(4);
            this.tb_strout.Multiline = true;
            this.tb_strout.Name = "tb_strout";
            this.tb_strout.ReadOnly = true;
            this.tb_strout.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tb_strout.Size = new System.Drawing.Size(792, 667);
            this.tb_strout.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bt_Traversal);
            this.groupBox1.Controls.Add(this.rb_gl2);
            this.groupBox1.Controls.Add(this.rb_gl1);
            this.groupBox1.Controls.Add(this.bt_copyt);
            this.groupBox1.Controls.Add(this.bt_print);
            this.groupBox1.Controls.Add(this.bt_create);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox1.Location = new System.Drawing.Point(800, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(300, 696);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "操作";
            // 
            // bt_Traversal
            // 
            this.bt_Traversal.Location = new System.Drawing.Point(33, 438);
            this.bt_Traversal.Margin = new System.Windows.Forms.Padding(4);
            this.bt_Traversal.Name = "bt_Traversal";
            this.bt_Traversal.Size = new System.Drawing.Size(240, 75);
            this.bt_Traversal.TabIndex = 2;
            this.bt_Traversal.Text = "广义表的原子元素";
            this.bt_Traversal.UseVisualStyleBackColor = true;
            this.bt_Traversal.Click += new System.EventHandler(this.bt_Traversal_Click);
            // 
            // rb_gl2
            // 
            this.rb_gl2.AutoSize = true;
            this.rb_gl2.Location = new System.Drawing.Point(74, 288);
            this.rb_gl2.Margin = new System.Windows.Forms.Padding(4);
            this.rb_gl2.Name = "rb_gl2";
            this.rb_gl2.Size = new System.Drawing.Size(141, 22);
            this.rb_gl2.TabIndex = 2;
            this.rb_gl2.Text = "转换后广义表";
            this.rb_gl2.UseVisualStyleBackColor = true;
            // 
            // rb_gl1
            // 
            this.rb_gl1.AutoSize = true;
            this.rb_gl1.Checked = true;
            this.rb_gl1.Location = new System.Drawing.Point(74, 240);
            this.rb_gl1.Margin = new System.Windows.Forms.Padding(4);
            this.rb_gl1.Name = "rb_gl1";
            this.rb_gl1.Size = new System.Drawing.Size(123, 22);
            this.rb_gl1.TabIndex = 2;
            this.rb_gl1.TabStop = true;
            this.rb_gl1.Text = "原始广义表";
            this.rb_gl1.UseVisualStyleBackColor = true;
            // 
            // bt_copyt
            // 
            this.bt_copyt.Location = new System.Drawing.Point(33, 128);
            this.bt_copyt.Margin = new System.Windows.Forms.Padding(4);
            this.bt_copyt.Name = "bt_copyt";
            this.bt_copyt.Size = new System.Drawing.Size(240, 75);
            this.bt_copyt.TabIndex = 1;
            this.bt_copyt.Text = "将广义表倒置转换";
            this.bt_copyt.UseVisualStyleBackColor = true;
            this.bt_copyt.Click += new System.EventHandler(this.bt_copyt_Click);
            // 
            // bt_print
            // 
            this.bt_print.Location = new System.Drawing.Point(33, 339);
            this.bt_print.Margin = new System.Windows.Forms.Padding(4);
            this.bt_print.Name = "bt_print";
            this.bt_print.Size = new System.Drawing.Size(240, 75);
            this.bt_print.TabIndex = 1;
            this.bt_print.Text = "打印广义表";
            this.bt_print.UseVisualStyleBackColor = true;
            this.bt_print.Click += new System.EventHandler(this.bt_print_Click);
            // 
            // bt_create
            // 
            this.bt_create.Location = new System.Drawing.Point(33, 44);
            this.bt_create.Margin = new System.Windows.Forms.Padding(4);
            this.bt_create.Name = "bt_create";
            this.bt_create.Size = new System.Drawing.Size(240, 75);
            this.bt_create.TabIndex = 1;
            this.bt_create.Text = "创建广义表";
            this.bt_create.UseVisualStyleBackColor = true;
            this.bt_create.Click += new System.EventHandler(this.bt_create_Click);
            // 
            // Form_GenList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 770);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form_GenList";
            this.Text = "广义表的运算演示";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tb_strin;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bt_create;
        private System.Windows.Forms.TextBox tb_strout;
        private System.Windows.Forms.TextBox tb_strprint;
        private System.Windows.Forms.Button bt_print;
        private System.Windows.Forms.Button bt_copyt;
        private System.Windows.Forms.RadioButton rb_gl2;
        private System.Windows.Forms.RadioButton rb_gl1;
        private System.Windows.Forms.Button bt_Traversal;
    }
}