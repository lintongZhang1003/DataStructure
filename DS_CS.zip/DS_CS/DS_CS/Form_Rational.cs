﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DS_CS
{
    public partial class Form_Rational : Form
    {
        Rational rat1, rat2, rat0;
        public Form_Rational()
        {
            InitializeComponent();
            rat1 = new Rational(12,18);
            rat2 = new Rational(5,9);
            rat0 = rat1+rat2;
            rat1_num.Text = Convert.ToString(rat1.Num);
            rat1_den.Text = Convert.ToString(rat1.Den);
            rat2_num.Text = Convert.ToString(rat2.Num);
            rat2_den.Text = Convert.ToString(rat2.Den);
            rat0_num.Text = "" + rat0.Num;
            rat0_den.Text = Convert.ToString(rat0.Den);
        }

        private void bt_close_Click(object sender, EventArgs e)
        {
            this.Close();
            FormMain.myform_rational = null;
        }

        private void bt_run_Click(object sender, EventArgs e)
        {
            //            rat1=new Rational(Convert.ToInt16(rat1_num.Text),Convert.ToInt16(rat1_den.Text))
            //            rat2=new Rational(Convert.ToInt16(rat2_num.Text),Convert.ToInt16(rat2_den.Text))
            rat1.Num = Convert.ToInt16(rat1_num.Text);
            rat1.Den = Convert.ToInt16(rat1_den.Text);
            rat2.Num = Convert.ToInt16(rat2_num.Text);
            rat2.Den = Convert.ToInt16(rat2_den.Text);
            if(rb1.Checked)
                rat0 = rat1 + rat2;
            else if(rb2.Checked)
                rat0 = rat1 - rat2;
            else if (rb3.Checked)
                rat0 = rat1 * rat2;
            else if (rb4.Checked)
                rat0 = rat1 / rat2;
            else if (rb5.Checked)
                rat0 = rat1 ^ rat2.Num;
            else if (rb6.Checked)
            {
                rat1++;
                rat1_num.Text = Convert.ToString(rat1.Num);
                rat1_den.Text = Convert.ToString(rat1.Den);
            }
            else if (rb7.Checked)
            {
                rat1--;
                rat1_num.Text = Convert.ToString(rat1.Num);
                rat1_den.Text = Convert.ToString(rat1.Den);
            }
            rat0_num.Text = Convert.ToString(rat0.Num);
            rat0_den.Text = Convert.ToString(rat0.Den);
        }
    }
}