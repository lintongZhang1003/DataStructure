﻿namespace DS_CS
{
    partial class Form_Maze
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Maze));
            this.panel1 = new System.Windows.Forms.Panel();
            this.bt_close = new System.Windows.Forms.Button();
            this.axMSFlexGrid1c = new AxMSFlexGridLib.AxMSFlexGrid();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bt_createmaze1 = new System.Windows.Forms.Button();
            this.bt_savefile1 = new System.Windows.Forms.Button();
            this.bt_openfile1 = new System.Windows.Forms.Button();
            this.tb_fname1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_maze_matrix1 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pb_mazepathc = new System.Windows.Forms.PictureBox();
            this.pb_mazec = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tB_MazeQueue = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.bt_closea = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pb_mazepath = new System.Windows.Forms.PictureBox();
            this.pb_maze = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.bt_next = new System.Windows.Forms.Button();
            this.tB_Length = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_fname = new System.Windows.Forms.TextBox();
            this.tb_maze_matrix = new System.Windows.Forms.TextBox();
            this.bt_savefile = new System.Windows.Forms.Button();
            this.bt_createmaze = new System.Windows.Forms.Button();
            this.bt_openfile = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axMSFlexGrid1c)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mazepathc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mazec)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mazepath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_maze)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.bt_close);
            this.panel1.Controls.Add(this.axMSFlexGrid1c);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(622, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(182, 509);
            this.panel1.TabIndex = 0;
            // 
            // bt_close
            // 
            this.bt_close.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_close.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_close.Location = new System.Drawing.Point(26, 463);
            this.bt_close.Name = "bt_close";
            this.bt_close.Size = new System.Drawing.Size(134, 40);
            this.bt_close.TabIndex = 10;
            this.bt_close.Text = "退出";
            this.bt_close.UseVisualStyleBackColor = true;
            // 
            // axMSFlexGrid1c
            // 
            this.axMSFlexGrid1c.Dock = System.Windows.Forms.DockStyle.Top;
            this.axMSFlexGrid1c.Location = new System.Drawing.Point(0, 0);
            this.axMSFlexGrid1c.Name = "axMSFlexGrid1c";
            this.axMSFlexGrid1c.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMSFlexGrid1c.OcxState")));
            this.axMSFlexGrid1c.Size = new System.Drawing.Size(180, 457);
            this.axMSFlexGrid1c.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.tb_maze_matrix1);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(622, 509);
            this.panel2.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.bt_createmaze1);
            this.panel4.Controls.Add(this.bt_savefile1);
            this.panel4.Controls.Add(this.bt_openfile1);
            this.panel4.Controls.Add(this.tb_fname1);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 310);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(622, 199);
            this.panel4.TabIndex = 6;
            // 
            // bt_createmaze1
            // 
            this.bt_createmaze1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_createmaze1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt_createmaze1.Location = new System.Drawing.Point(19, 116);
            this.bt_createmaze1.Name = "bt_createmaze1";
            this.bt_createmaze1.Size = new System.Drawing.Size(250, 62);
            this.bt_createmaze1.TabIndex = 10;
            this.bt_createmaze1.Text = "生成迷宫矩阵并显示迷宫及最短路径";
            this.bt_createmaze1.UseVisualStyleBackColor = true;
            // 
            // bt_savefile1
            // 
            this.bt_savefile1.Enabled = false;
            this.bt_savefile1.Location = new System.Drawing.Point(149, 70);
            this.bt_savefile1.Name = "bt_savefile1";
            this.bt_savefile1.Size = new System.Drawing.Size(119, 40);
            this.bt_savefile1.TabIndex = 9;
            this.bt_savefile1.Text = "保存迷宫矩阵文件";
            this.bt_savefile1.UseVisualStyleBackColor = true;
            // 
            // bt_openfile1
            // 
            this.bt_openfile1.Location = new System.Drawing.Point(19, 70);
            this.bt_openfile1.Name = "bt_openfile1";
            this.bt_openfile1.Size = new System.Drawing.Size(119, 40);
            this.bt_openfile1.TabIndex = 8;
            this.bt_openfile1.Text = "选择迷宫矩阵文件";
            this.bt_openfile1.UseVisualStyleBackColor = true;
            // 
            // tb_fname1
            // 
            this.tb_fname1.Location = new System.Drawing.Point(19, 43);
            this.tb_fname1.Name = "tb_fname1";
            this.tb_fname1.Size = new System.Drawing.Size(251, 21);
            this.tb_fname1.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "打开迷宫矩阵文件";
            // 
            // tb_maze_matrix1
            // 
            this.tb_maze_matrix1.Location = new System.Drawing.Point(0, 310);
            this.tb_maze_matrix1.Multiline = true;
            this.tb_maze_matrix1.Name = "tb_maze_matrix1";
            this.tb_maze_matrix1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tb_maze_matrix1.Size = new System.Drawing.Size(311, 199);
            this.tb_maze_matrix1.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.pb_mazepathc);
            this.panel3.Controls.Add(this.pb_mazec);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(622, 310);
            this.panel3.TabIndex = 0;
            // 
            // pb_mazepathc
            // 
            this.pb_mazepathc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_mazepathc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pb_mazepathc.Location = new System.Drawing.Point(311, 0);
            this.pb_mazepathc.Name = "pb_mazepathc";
            this.pb_mazepathc.Size = new System.Drawing.Size(311, 310);
            this.pb_mazepathc.TabIndex = 1;
            this.pb_mazepathc.TabStop = false;
            // 
            // pb_mazec
            // 
            this.pb_mazec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_mazec.Dock = System.Windows.Forms.DockStyle.Left;
            this.pb_mazec.Location = new System.Drawing.Point(0, 0);
            this.pb_mazec.Name = "pb_mazec";
            this.pb_mazec.Size = new System.Drawing.Size(311, 310);
            this.pb_mazec.TabIndex = 0;
            this.pb_mazec.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.tB_MazeQueue);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(571, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 525);
            this.panel5.TabIndex = 0;
            // 
            // tB_MazeQueue
            // 
            this.tB_MazeQueue.BackColor = System.Drawing.SystemColors.Window;
            this.tB_MazeQueue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tB_MazeQueue.Location = new System.Drawing.Point(0, 0);
            this.tB_MazeQueue.Multiline = true;
            this.tB_MazeQueue.Name = "tB_MazeQueue";
            this.tB_MazeQueue.ReadOnly = true;
            this.tB_MazeQueue.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tB_MazeQueue.Size = new System.Drawing.Size(198, 445);
            this.tB_MazeQueue.TabIndex = 3;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.bt_closea);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(0, 445);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(198, 78);
            this.panel6.TabIndex = 1;
            // 
            // bt_closea
            // 
            this.bt_closea.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_closea.Location = new System.Drawing.Point(47, 8);
            this.bt_closea.Name = "bt_closea";
            this.bt_closea.Size = new System.Drawing.Size(120, 57);
            this.bt_closea.TabIndex = 0;
            this.bt_closea.Text = "退出";
            this.bt_closea.UseVisualStyleBackColor = true;
            this.bt_closea.Click += new System.EventHandler(this.bt_close_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel9);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(571, 525);
            this.panel7.TabIndex = 1;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.pb_mazepath);
            this.panel9.Controls.Add(this.pb_maze);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(571, 289);
            this.panel9.TabIndex = 1;
            // 
            // pb_mazepath
            // 
            this.pb_mazepath.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_mazepath.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pb_mazepath.Location = new System.Drawing.Point(280, 0);
            this.pb_mazepath.Name = "pb_mazepath";
            this.pb_mazepath.Size = new System.Drawing.Size(291, 289);
            this.pb_mazepath.TabIndex = 1;
            this.pb_mazepath.TabStop = false;
            // 
            // pb_maze
            // 
            this.pb_maze.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_maze.Dock = System.Windows.Forms.DockStyle.Left;
            this.pb_maze.Location = new System.Drawing.Point(0, 0);
            this.pb_maze.Name = "pb_maze";
            this.pb_maze.Size = new System.Drawing.Size(280, 289);
            this.pb_maze.TabIndex = 0;
            this.pb_maze.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.panel10);
            this.panel8.Controls.Add(this.tb_fname);
            this.panel8.Controls.Add(this.tb_maze_matrix);
            this.panel8.Controls.Add(this.bt_savefile);
            this.panel8.Controls.Add(this.bt_createmaze);
            this.panel8.Controls.Add(this.bt_openfile);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel8.Location = new System.Drawing.Point(0, 289);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(571, 236);
            this.panel8.TabIndex = 0;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.bt_next);
            this.panel10.Controls.Add(this.tB_Length);
            this.panel10.Controls.Add(this.label2);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(287, 185);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(284, 51);
            this.panel10.TabIndex = 4;
            this.panel10.Visible = false;
            // 
            // bt_next
            // 
            this.bt_next.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_next.Location = new System.Drawing.Point(174, 2);
            this.bt_next.Name = "bt_next";
            this.bt_next.Size = new System.Drawing.Size(91, 44);
            this.bt_next.TabIndex = 8;
            this.bt_next.Text = "下一条路径";
            this.bt_next.UseVisualStyleBackColor = true;
            this.bt_next.Click += new System.EventHandler(this.bt_next_Click);
            // 
            // tB_Length
            // 
            this.tB_Length.Location = new System.Drawing.Point(83, 14);
            this.tB_Length.Name = "tB_Length";
            this.tB_Length.Size = new System.Drawing.Size(60, 21);
            this.tB_Length.TabIndex = 7;
            this.tB_Length.Text = "0";
            this.tB_Length.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "路径长度";
            // 
            // tb_fname
            // 
            this.tb_fname.Location = new System.Drawing.Point(306, 56);
            this.tb_fname.Name = "tb_fname";
            this.tb_fname.Size = new System.Drawing.Size(246, 21);
            this.tb_fname.TabIndex = 3;
            // 
            // tb_maze_matrix
            // 
            this.tb_maze_matrix.Dock = System.Windows.Forms.DockStyle.Left;
            this.tb_maze_matrix.Location = new System.Drawing.Point(0, 0);
            this.tb_maze_matrix.Multiline = true;
            this.tb_maze_matrix.Name = "tb_maze_matrix";
            this.tb_maze_matrix.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tb_maze_matrix.Size = new System.Drawing.Size(287, 236);
            this.tb_maze_matrix.TabIndex = 2;
            // 
            // bt_savefile
            // 
            this.bt_savefile.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_savefile.Location = new System.Drawing.Point(306, 135);
            this.bt_savefile.Name = "bt_savefile";
            this.bt_savefile.Size = new System.Drawing.Size(246, 44);
            this.bt_savefile.TabIndex = 1;
            this.bt_savefile.Text = "保存迷宫矩阵文件";
            this.bt_savefile.UseVisualStyleBackColor = true;
            this.bt_savefile.Click += new System.EventHandler(this.bt_savefile_Click);
            // 
            // bt_createmaze
            // 
            this.bt_createmaze.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_createmaze.Location = new System.Drawing.Point(306, 85);
            this.bt_createmaze.Name = "bt_createmaze";
            this.bt_createmaze.Size = new System.Drawing.Size(246, 44);
            this.bt_createmaze.TabIndex = 1;
            this.bt_createmaze.Text = "生成迷宫矩阵并显示迷宫及最短路径";
            this.bt_createmaze.UseVisualStyleBackColor = true;
            this.bt_createmaze.Click += new System.EventHandler(this.bt_createmaze_Click);
            // 
            // bt_openfile
            // 
            this.bt_openfile.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_openfile.Location = new System.Drawing.Point(306, 6);
            this.bt_openfile.Name = "bt_openfile";
            this.bt_openfile.Size = new System.Drawing.Size(246, 44);
            this.bt_openfile.TabIndex = 1;
            this.bt_openfile.Text = "选择迷宫矩阵文件";
            this.bt_openfile.UseVisualStyleBackColor = true;
            this.bt_openfile.Click += new System.EventHandler(this.bt_openfile_Click);
            // 
            // Form_Maze
            // 
            this.ClientSize = new System.Drawing.Size(771, 525);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel5);
            this.Name = "Form_Maze";
            this.Text = "迷宫的演示";
            this.Load += new System.EventHandler(this.Form_Maze_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axMSFlexGrid1c)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_mazepathc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mazec)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_mazepath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_maze)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pb_mazepathc;
        private System.Windows.Forms.PictureBox pb_mazec;
        private System.Windows.Forms.TextBox tb_maze_matrix1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button bt_createmaze1;
        private System.Windows.Forms.Button bt_savefile1;
        private System.Windows.Forms.Button bt_openfile1;
        private System.Windows.Forms.TextBox tb_fname1;
        private System.Windows.Forms.Label label1;
        private AxMSFlexGridLib.AxMSFlexGrid axMSFlexGrid1c;
        private System.Windows.Forms.Button bt_close;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button bt_closea;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.PictureBox pb_mazepath;
        private System.Windows.Forms.PictureBox pb_maze;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button bt_openfile;
        private System.Windows.Forms.TextBox tb_maze_matrix;
        private System.Windows.Forms.TextBox tb_fname;
        private System.Windows.Forms.Button bt_savefile;
        private System.Windows.Forms.Button bt_createmaze;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox tB_Length;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bt_next;
        private System.Windows.Forms.TextBox tB_MazeQueue;
    }
}